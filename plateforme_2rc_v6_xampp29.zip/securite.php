<?php session_start();
if (empty($_SESSION['user'])) {
    header('Location:login.php');
    exit;
} ?><!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Sécurité du compte</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt"
            onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Question clé</h1>
                    <div class="sub">Créez ou modifiez la question et la réponse utilisées pour récupérer votre compte.</div>
                </div>
            </div>
            <div class="card">
                <form id="f" class="form">
                    <div class="field full"><label>Question clé</label><input name="question" maxlength="255" required>
                    </div>
                    <div class="field full"><label>Réponse</label><input name="reponse" type="password" minlength="4"
                            maxlength="255" required></div>
                    <div class="field full"><button class="btn">Enregistrer</button></div>
                </form>
                <div id="msg" class="notice" style="margin-top:12px">La réponse est stockée sous forme de hash.</div>
            </div>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>const f = document.getElementById('f'); f.onsubmit = async e => { e.preventDefault(); const r = await api('save_recovery_question', new FormData(f), 'POST'); document.getElementById('msg').textContent = r.ok ? 'Question clé enregistrée.' : (r.message || 'Erreur'); if (r.ok) f.reset() }; guard(<?= json_encode($_SESSION['user']['role']) ?>)</script>
</body>

</html>