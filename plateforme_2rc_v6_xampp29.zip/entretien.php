<?php session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'AGENT') {
    header('Location:login.php');
    exit;
} ?><!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Entretien</title>
    <link rel="stylesheet" href="assets/app.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt"
            onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Mon unité d’entretien</h1>
                    <div class="sub">Opérations autorisées, drains affectés et transmission des rapports.</div>
                </div>
            </div>
            <div class="card reveal" style="margin-bottom:16px">
                <h3>Carte SIG de l’unité</h3>
                <div class="map-shell">
                    <div id="map" style="height:430px;min-height:430px"></div>
                    <div id="mapLoading" class="map-loading">
                        <div class="map-loading-box"><b>Chargement de la carte SIG…</b>
                            <div class="map-loading-bar"><span id="mapLoadingBar"></span></div><small
                                id="mapLoadingText">10 secondes</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="grid three">
                <div class="card kpi">
                    <div class="label">MEMBRES DE L’UNITÉ</div>
                    <div class="value" id="membersCount">0</div>
                    <div id="memberNames" class="sub">—</div>
                </div>
                <div class="card kpi">
                    <div class="label">INTERVENTIONS À EFFECTUER</div>
                    <div class="value" id="todo">0</div>
                </div>
                <div class="card kpi">
                    <div class="label">INTERVENTIONS EFFECTUÉES</div>
                    <div class="value" id="done">0</div>
                </div>
            </div>
            <div class="card" style="margin-top:16px">
                <h3>Drains affectés à l’unité</h3>
                <div id="drains" class="grid two"></div>
            </div>
            <div class="card" style="margin-top:16px">
                <h3>Transmission d’un rapport d’entretien</h3>
                <div class="notice">La liste ne contient que les interventions autorisées affectées à votre unité.</div>
                <form id="f" class="form">
                    <div class="field"><label>Drain affecté</label><select id="drainUnit" required></select></div>
                    <div class="field"><label>Intervention</label><select name="intervention_id" id="op"
                            required></select></div>
                    <div class="field full"><label>Titre du rapport</label><input name="titre" required></div>
                    <div class="field full"><label>Compte rendu</label><textarea name="report_commentaire" rows="6"
                            required
                            placeholder="Travaux réalisés, difficultés, matériel utilisé, observations…"></textarea>
                    </div>
                    <div class="field"><label>Photos (3 max)</label><input name="images[]" id="imgs" type="file"
                            accept="image/jpeg,image/png,image/webp,image/gif" multiple></div>
                    <div class="field"><label>Niveau d’exécution</label><select name="status">
                            <option>EN_COURS</option>
                            <option>TERMINEE</option>
                            <option>EN_RETARD</option>
                        </select></div>
                    <div class="field full"><button class="btn">Envoyer le rapport en direct</button></div>
                </form>
            </div>
        </main>
    </div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="assets/app.js?v=27"></script>
    <script src="assets/map.js"></script>
    <script>const op = document.getElementById('op'), drainUnit = document.getElementById('drainUnit'), formEl = document.getElementById('f'); let rows = [], unitDrains = []; function renderInterventions(id) { let list = rows.filter(i => i.type_intervention !== 'INSPECTION' && (!id || String(i.drain_id) === String(id))); op.innerHTML = list.map(i => `<option value="${i.id}" data-drain="${i.drain_id}">${esc(i.reference)} — ${esc(i.drain_nom)}</option>`).join('') || '<option value="">Aucune intervention autorisée</option>'; if (list[0]) op.value = list[0].id } async function load() { rows = await api('my_work'); rows = Array.isArray(rows) ? rows : []; let ds = await api('unit_context', { _v: 27 }); if (!ds || !ds.ok) ds = { ok: true, drains: [] }; let assigned = await api('my_unit_drains', { _v: 27 }); if (assigned && assigned.ok && Array.isArray(assigned.drains)) ds.drains = assigned.drains; if (ds && ds.ok) { unitDrains = Array.isArray(ds.drains) ? ds.drains : []; document.getElementById('membersCount').textContent = ds.members.length; document.getElementById('memberNames').textContent = ds.members.join(' · ') || 'Aucun membre'; document.getElementById('todo').textContent = ds.todo; document.getElementById('done').textContent = ds.done; document.getElementById('drains').innerHTML = unitDrains.map(d => `<div class="card"><b>${esc(d.code)}</b><br>${esc(d.nom)}</div>`).join('') || '<div class="notice">Aucun drain affecté.</div>'; drainUnit.innerHTML = unitDrains.map(d => `<option value="${d.id}">${esc(d.code)} — ${esc(d.nom)}</option>`).join('') || '<option value="">Aucun drain affecté</option>'; renderInterventions(drainUnit.value) } } drainUnit.onchange = () => renderInterventions(drainUnit.value); op.onchange = () => { let o = op.selectedOptions[0]; if (o?.dataset.drain) drainUnit.value = o.dataset.drain }; formEl.onsubmit = async e => { e.preventDefault(); if (!drainUnit.value) return toast('Aucun drain affecté à votre unité.', 'error'); if (!op.value) return toast('Aucune intervention autorisée pour ce drain.', 'error'); if (document.getElementById('imgs').files.length > 3) return toast('Maximum 3 photos.', 'error'); let r = await api('submit_report', new FormData(formEl), 'POST'); if (r.ok) { toast('Rapport transmis.'); formEl.reset(); load() } else toast(r.message || 'Échec de l’enregistrement.', 'error') }; guard('AGENT').then(async () => { let r = await api('map'); initMap(r.settings || {}); loadMap(); startMapLoader(); load() }); function startMapLoader() { let t = 0, bar = document.getElementById('mapLoadingBar'), ov = document.getElementById('mapLoading'), txt = document.getElementById('mapLoadingText'); let x = setInterval(() => { t += 100; let p = t / 100; bar.style.width = p + '%'; txt.textContent = p < 100 ? 'Chargement — ' + Math.ceil(10 - t / 1000) + ' s' : 'Carte prête'; if (t >= 10000) { clearInterval(x); setTimeout(() => ov.classList.add('hide'), 250) } }, 100) }
    startAutoRefresh(async () => { await load(); if (typeof loadMap === 'function' && window.map) await loadMap(false); }, 2000);
</script>
</body>

</html>