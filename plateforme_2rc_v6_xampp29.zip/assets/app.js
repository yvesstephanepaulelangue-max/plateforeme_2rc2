async function api(action, data = {}, method = 'GET') {
    method = method.toUpperCase(); const headers = { 'X-Requested-With': 'XMLHttpRequest' };
    if (method !== 'GET' && window.__csrf) headers['X-CSRF-Token'] = window.__csrf;
    const o = { method, headers }; if (method !== 'GET') o.body = data instanceof FormData ? data : new URLSearchParams(data);
    const u = 'api/api.php?action=' + encodeURIComponent(action) + (method === 'GET' && data && Object.keys(data).length ? '&' + new URLSearchParams(data) : '');
    try { const r = await fetch(u, o); const txt = await r.text(); const out = JSON.parse(txt); if (out.csrf_token) window.__csrf = out.csrf_token; if (r.status === 401 && action !== 'login') location = 'login.php'; return out } catch (e) { return { ok: false, message: 'Impossible de joindre le serveur ou réponse invalide.' } }
}
async function guard(role) { let r = await api('me'); if (!r.ok) { location = 'login.php'; return null } if (r.csrf_token) window.__csrf = r.csrf_token; if (role && (Array.isArray(role) ? !role.includes(r.user.role) : r.user.role !== role)) { document.body.innerHTML = '<main><div class="card"><h2>Accès refusé</h2><p>Ce profil ne possède pas les droits pour cette page.</p></div></main>'; return null } return r.user }
function badge(v) { return `<span class="badge ${v || ''}">${v || '—'}</span>` } function money(v) { return new Intl.NumberFormat('fr-FR').format(v || 0) } function esc(v) { return String(v ?? '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m])) }
async function logout() { await api('logout'); location = 'login.php' }
function animateNumber(el, target, suffix = '') { target = Number(target) || 0; let start = 0, steps = 22, step = target / steps, n = 0; let timer = setInterval(() => { n++; start += step; if (n >= steps) { start = target; clearInterval(timer) } el.textContent = (Number.isInteger(target) ? Math.round(start) : start.toFixed(1)) + suffix }, 24) }
function toast(message, type = 'success') { let t = document.createElement('div'); t.className = 'toast ' + type; t.textContent = message; document.body.appendChild(t); requestAnimationFrame(() => t.classList.add('show')); setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 250) }, 3000) }

function startAutoRefresh(loadFn, interval = 3000000000) {
    let running = false;
    const tick = async () => {
        if (running || document.hidden) return;
        const active = document.activeElement;
        if (active && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName)) return;
        if (document.querySelector('.modal.show')) return;
        running = true;
        try { await loadFn(true); } catch (e) { console.error('Actualisation automatique:', e); }
        finally { running = false; }
    };
    const timer = setInterval(tick, interval);
    window.addEventListener('beforeunload', () => clearInterval(timer), { once: true });
    return () => clearInterval(timer);
}

document.addEventListener('DOMContentLoaded', () => { document.body.classList.add('page-ready'); document.querySelectorAll('a[href]').forEach(a => a.addEventListener('click', e => { const href = a.getAttribute('href'); if (href && !href.startsWith('#') && !href.startsWith('http') && href !== location.pathname.split('/').pop()) { e.preventDefault(); document.body.classList.add('page-leave'); setTimeout(() => location.href = href, 220) } })); });
