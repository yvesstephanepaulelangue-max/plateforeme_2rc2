<?php
$role = $_SESSION['user']['role'] ?? '';
$page = basename($_SERVER['PHP_SELF']);
$level = (int) str_replace('NIVEAU_', '', $_SESSION['user']['niveau_accreditation'] ?? '1');
$manager = in_array($role, ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true);
$label = $role === 'ADMIN' ? 'Chef service assainissement' : ($role === 'SOUS_DIRECTEUR_OPERATIONS' ? 'Sous-directeur des opérations' : ($role === 'INSPECTEUR' ? 'Unité d’inspection' : ($role === 'AGENT' ? 'Unité d’entretien' : 'Direction')));
function notificationTypeForNav($href)
{
    $b = basename($href);
    if ($b === 'accreditations.php') return 'ACCREDITATION';
    if ($b === 'journal.php') return 'JOURNAL';
    if ($b === 'corbeille.php') return 'CORBEILLE';
    if ($b === 'rapports.php') return 'RAPPORT';
    if ($b === 'unites-equipes.php') return 'UNITE';
    if (in_array($b, ['interventions.php','operation-inspection.php','operation-entretien.php'], true)) return 'INTERVENTION';
    return '';
}
function navlink($href, $text, $page)
{
    $active = basename($href) === $page ? ' active' : '';
    $type = notificationTypeForNav($href);
    $badge = $type ? '<span class="nav-notification" data-notif-type="' . htmlspecialchars($type, ENT_QUOTES, 'UTF-8') . '" hidden></span>' : '';
    return '<a class="sidebar-item' . $active . '" href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8') . '">'
         . '<span class="sidebar-label">' . htmlspecialchars($text, ENT_QUOTES, 'UTF-8') . '</span>'
         . $badge
         . '</a>';
}
?>
<aside>
    <div class="side-brand"><strong></strong><span><?= htmlspecialchars($label) ?></span></div>
    <nav>
        <?php if ($manager): ?>
            <div style="display:flex;align-items: center;">
                <img src="assets-2/dashbord.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('dashboard.php','Tableau de bord', $page) ?>
            </div>
            <div class="sidebar-row">
                <img src="assets-2/operateur.png" alt="" class="sidebar-icon"><?= navlink('interventions.php', 'Interventions', $page) ?>
            </div>
            <div class="sidebar-row">
                <img src="assets-2/disposition.png" alt="" class="sidebar-icon"><?= navlink('archive.php', 'Archive', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/Maps.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('carte.php', 'Carte SIG', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/egout.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('drains.php', 'Drains', $page) ?>
            </div>
            <div style="display:flex;align-items: center;">
                <img src="assets-2/journal.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('journal.php', 'Journal', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/disposition.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('corbeille.php', 'Corbeille', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/rapport.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('rapports.php', 'Rapports', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/groupe.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('unites-equipes.php', 'Unités', $page) ?>
            </div>
            <div style="display:flex;align-items: center;">
                <img src="assets-2/accreditation 1.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('accreditations.php', 'Accréditations', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/parametres.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('parametres.php', 'Paramètres', $page) ?>
            </div>

        <?php elseif (in_array($role, ['INSPECTEUR', 'AGENT'], true)): ?>

            <div style="display:flex; align-items: center;">
                <img src="assets-2/Maps.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('carte.php', 'Carte SIG', $page) ?>
            </div>

        <?= navlink($role === 'INSPECTEUR' ? 'operation-inspection.php' : 'operation-entretien.php', 'Interventions', $page) ?>

        <?php if ($level >= 2): ?> 
            
            <div style="display:flex; align-items: center;">
                <img src="assets-2/egout.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('drains.php', 'Drains', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/rapport.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('rapports.php', 'Rapports', $page) ?>
            </div> 
            
            <?php endif; ?>

        <?php if ($level >= 3): ?> 

            <div style="display:flex; align-items: center;">
                <img src="assets-2/groupe.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('unites-equipes.php', 'Unités', $page) ?>
            </div>
            <?php endif; ?>

        <?php elseif ($role === 'CHEF_UNITE'): ?>
            
            <div style="display:flex; align-items: center;">
                <img src="assets-2/page-daccueil.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('chef-unite.php', 'Acceuil', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/Maps.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('carte.php', 'Carte SIG', $page) ?>
            </div>
            <div class="sidebar-row">
                <img src="assets-2/operateur.png" alt="" class="sidebar-icon"><?= navlink('interventions.php', 'Interventions', $page) ?>
            </div>
            <div class="sidebar-row">
                <img src="assets-2/disposition.png" alt="" class="sidebar-icon"><?= navlink('archive.php', 'Archive', $page) ?>
            </div> 
            <div style="display:flex; align-items: center;">
                <img src="assets-2/egout.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('drains.php', 'Drains', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/rapport.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('rapports.php', 'Rapports', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/groupe.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('unites-equipes.php', 'Unités', $page) ?>
            </div>
            <div style="display:flex; align-items: center;">
                <img src="assets-2/cadenas.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('securite.php', 'Sécurité', $page) ?>
            </div>
        <?php elseif ($role === 'HSE'): ?>


        <div style="display:flex; align-items: center;">
            <img src="assets-2/Maps.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('carte.php', 'Carte SIG', $page) ?>
        </div>
        <div style="display:flex; align-items: center;">
            <img src="assets-2/parametres.png" alt="" srcset="" style="width: 30px;heigth:10px "><?= navlink('parametres.php', 'Paramètres', $page) ?>
        </div>
        <?php endif; ?>
    </nav>
<style>
/* Sidebar : liens, texte et badges */
nav .sidebar-row{display:flex;align-items:center;width:100%;min-width:0;}
nav .sidebar-icon{width:30px;height:30px;flex:0 0 30px;object-fit:contain;}
nav .sidebar-item{width:100%;min-width:0;box-sizing:border-box;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px;border-radius:11px;color:#526474;font-weight:800;text-decoration:none;margin:3px 0;position:relative;transition:.2s transform,.2s background,.2s color;}
nav .sidebar-row .sidebar-item{flex:1 1 auto;}
nav .sidebar-label{min-width:0;flex:1 1 auto;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
nav .nav-notification{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;box-sizing:border-box;margin-left:auto;border-radius:999px;color:#fff;font-size:10px;line-height:1;font-weight:900;background:#28a745;vertical-align:middle;}
nav .nav-notification.badge-green{background:#28a745;}
nav .nav-notification.badge-red{background:#dc3545;}
/* Un badge à 0 ou sans notification reste réellement masqué. */
nav .nav-notification[hidden]{display:none !important;}
nav .sidebar-item:hover{transform:translateX(3px);background:#fff0e9;color:var(--navy);}
nav .sidebar-item.active{background:linear-gradient(90deg,#e6f4f8,#f4fafc);color:var(--navy);}
</style>
<script>
(function(){
 async function refreshNavNotifications(){
   try{
     const r=await api('notification_counts');
     if(!r||r.ok===false)return;
     document.querySelectorAll('.nav-notification').forEach(el=>{
       const n=Number(r[el.dataset.notifType]||0);
       el.textContent=n>99?'99+':String(n);
       /* Le badge n'existe visuellement que lorsqu'il y a au moins 1 notification. */
       el.hidden=n<1;
       el.classList.remove('badge-green','badge-red');
       if(n>=1 && n<=9) el.classList.add('badge-red');
       else if(n>=10) el.classList.add('badge-red');
     });
   }catch(e){console.error('Erreur notifications sidebar:',e);}
 }

 async function markBadgeReadAndNavigate(e){
   const link=e.currentTarget;
   const badge=link.querySelector('.nav-notification');
   if(!badge || badge.hidden) return;

   /* Empêche le gestionnaire global de navigation de partir avant le marquage. */
   e.preventDefault();
   e.stopImmediatePropagation();

   const href=link.getAttribute('href');
   const type=badge.dataset.notifType;

   /* Disparition immédiate du badge au clic. */
   badge.hidden=true;

   try{
     await api('notification_read',{type:type},'POST');
   }catch(err){
     console.error('Erreur lecture notification:',err);
   }finally{
     if(href) window.location.href=href;
   }
 }

 function bindBadgeClicks(){
   document.querySelectorAll('nav .sidebar-item').forEach(link=>{
     link.addEventListener('click',markBadgeReadAndNavigate,true);
   });
 }

 function start(){
   bindBadgeClicks();
   refreshNavNotifications();
   /* Actualisation périodique pour les nouvelles notifications. */
   setInterval(refreshNavNotifications,15000);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
</aside>