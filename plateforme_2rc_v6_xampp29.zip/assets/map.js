let map, drawn, mapDataLayer, drainPopupLayers = {};
const sat = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: 'Esri' });
const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: 'OpenStreetMap' });
function initMap(opts = {}) {
  const base = opts.provider === 'OSM' ? osm : sat;
  map = L.map('map', { layers: [base], zoomControl: true }).setView([opts.lat || 4.05, opts.lng || 9.70], opts.zoom || 12);
  drawn = L.featureGroup().addTo(map);
  mapDataLayer = L.layerGroup().addTo(map);
  window.setMapView = (name) => {
    if (name === 'OSM') { if (map.hasLayer(sat)) map.removeLayer(sat); if (!map.hasLayer(osm)) osm.addTo(map) }
    else { if (map.hasLayer(osm)) map.removeLayer(osm); if (!map.hasLayer(sat)) sat.addTo(map) }
    document.querySelectorAll('.map-view-btn').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  };
}
function stateColor(e) { return ({ DEBIT_CORRECT: '#39e75f', SATURATION_PARTIELLE: '#ff9800', SATURATION_TOTAL: '#e60000' }[e] || '#39e75f') }
function priorityColor(p) { return ({ P1: '#d7191c', P2: '#f26b21', P3: '#f2c511', P4: '#22a35a' }[p] || '#22a35a') }
function drainStyle(d) { return { color: stateColor(d.etat), weight: d.priorite === 'P1' ? 8 : 6, opacity: .98, dashArray: null } }
function interventionStyle(i) { if (i.statut === 'EN_COURS') return { color: '#ff5119', weight: 8, opacity: .98 }; if (i.statut === 'PLANIFIEE') return { color: '#1575d1', weight: 7, opacity: .95, dashArray: '10 7' }; if (i.statut === 'EN_RETARD') return { color: '#d7191c', weight: 8, opacity: .98 }; return { color: '#6e7b88', weight: 5, opacity: .55, dashArray: '4 7' } }
function parseGeo(s) { try { return typeof s === 'string' ? JSON.parse(s) : s } catch (e) { return null } }
function lineLengthMeters(latlngs) { let total = 0, R = 6371000; for (let i = 1; i < latlngs.length; i++) { let a = latlngs[i - 1], b = latlngs[i], p1 = a.lat * Math.PI / 180, p2 = b.lat * Math.PI / 180, dp = (b.lat - a.lat) * Math.PI / 180, dl = (b.lng - a.lng) * Math.PI / 180; let x = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2; total += 2 * R * Math.asin(Math.sqrt(x)) } return Math.round(total * 100) / 100 }
function geoDistance(a, b) { const R = 6371000, p1 = a[1] * Math.PI / 180, p2 = b[1] * Math.PI / 180, dp = (b[1] - a[1]) * Math.PI / 180, dl = (b[0] - a[0]) * Math.PI / 180; const x = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(x)) }
function drainCoordinates(gj) {
  return gj && gj.geometry && gj.geometry.type === 'LineString' ? gj.geometry.coordinates : [];
}
function drainCumulativeDistances(coords) {
  const cum = [0];
  for (let i = 1; i < coords.length; i++) cum.push(cum[i - 1] + geoDistance(coords[i - 1], coords[i]));
  return cum;
}
function pointAtDrainDistance(coords, cum, target) {
  if (!coords.length) return null;
  target = Math.max(0, Math.min(cum[cum.length - 1], target));
  if (target <= 0) return coords[0];
  for (let i = 1; i < coords.length; i++) {
    if (target <= cum[i]) {
      const seg = cum[i] - cum[i - 1];
      const t = seg > 0 ? (target - cum[i - 1]) / seg : 0;
      return [
        coords[i - 1][0] + (coords[i][0] - coords[i - 1][0]) * t,
        coords[i - 1][1] + (coords[i][1] - coords[i - 1][1]) * t
      ];
    }
  }
  return coords[coords.length - 1];
}
function lineRangeByDistance(coords, cum, start, end) {
  start = Math.max(0, start); end = Math.min(cum[cum.length - 1], end);
  if (end <= start + 0.001) return [];
  const out = [];
  const pStart = pointAtDrainDistance(coords, cum, start);
  const pEnd = pointAtDrainDistance(coords, cum, end);
  if (pStart) out.push([pStart[1], pStart[0]]);
  for (let i = 1; i < coords.length - 1; i++) {
    if (cum[i] > start && cum[i] < end) out.push([coords[i][1], coords[i][0]]);
  }
  if (pEnd) out.push([pEnd[1], pEnd[0]]);
  return out;
}
function normalizeWorkIntervals(rows, total) {
  const iv = [];
  (rows || []).forEach(r => {
    let a = Number(r.distance_depart_m) || 0, b = Number(r.distance_arrivee_m) || 0;
    if (b < a) [a, b] = [b, a];
    a = Math.max(0, Math.min(total, a)); b = Math.max(0, Math.min(total, b));
    if (b > a + 0.001) iv.push([a, b]);
  });
  iv.sort((a, b) => a[0] - b[0]);
  const merged = [];
  iv.forEach(x => {
    const last = merged[merged.length - 1];
    if (last && x[0] <= last[1] + 0.001) last[1] = Math.max(last[1], x[1]);
    else merged.push(x.slice());
  });
  return merged;
}
function drawDrainRanges(d, gj, workRows) {
  const coords = drainCoordinates(gj);
  if (coords.length < 2) return null;
  const ordered = d.direction_travaux === 'B_VERS_A' ? [...coords].reverse() : coords;
  const cum = drainCumulativeDistances(ordered), total = cum[cum.length - 1];
  if (total <= 0) return null;
  const intervals = normalizeWorkIntervals(workRows, total);
  const group = L.layerGroup().addTo(mapDataLayer);
  const baseOpts = {
    weight: d.priorite === 'P1' ? 8 : 6, opacity: .98, interactive: false,
    dashArray: null
  };
  const drawRange = (a, b, color) => {
    const pts = lineRangeByDistance(ordered, cum, a, b);
    if (pts.length >= 2) L.polyline(pts, { ...baseOpts, color }).addTo(group);
  };
  if (!intervals.length) {
    drawRange(0, total, Number(d.avancement_pct || 0) > 0 ? '#f26b21' : stateColor(d.etat));
    return group;
  }
  let cursor = 0;
  intervals.forEach(iv => {
    const [a, b] = iv;
    if (a > cursor) drawRange(cursor, a, '#f26b21');
    drawRange(a, b, '#22a35a');
    cursor = b;
  });
  if (cursor < total) drawRange(cursor, total, '#f26b21');

  // Les intervalles entre deux tronçons exécutés correspondent au linéaire sauté.
  for (let i = 1; i < intervals.length; i++) {
    const a = intervals[i - 1][1], b = intervals[i][0];
    if (b > a + 0.001) drawRange(a, b, '#808080');
  }
  return group;
}
function drawProgressiveDrain(d, gj, workRows) {
  if (workRows && workRows.length) return drawDrainRanges(d, gj, workRows);
  const coords = gj && gj.geometry && gj.geometry.type === 'LineString' ? gj.geometry.coordinates : [];
  if (coords.length < 2) return null;
  const ordered = d.direction_travaux === 'B_VERS_A' ? [...coords].reverse() : coords;
  const progress = Math.max(0, Math.min(100, Number(d.avancement_pct) || 0)) / 100;
  let total = 0; for (let i = 1; i < ordered.length; i++)total += geoDistance(ordered[i - 1], ordered[i]);
  const target = total * progress, group = L.layerGroup().addTo(map); let cum = 0;
  for (let i = 1; i < ordered.length; i++) {
    const a = ordered[i - 1], b = ordered[i], len = geoDistance(a, b); if (!len) continue; const next = cum + len;
    const opts = { weight: d.priorite === 'P1' ? 8 : 6, opacity: .98, dashArray: null, interactive: false };
    if (progress > 0 && cum < target && next > target) {
      const t = (target - cum) / len, cut = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
      L.polyline([[a[1], a[0]], [cut[1], cut[0]]], { ...opts, color: '#22a35a' }).addTo(group);
      L.polyline([[cut[1], cut[0]], [b[1], b[0]]], { ...opts, color: '#f26b21' }).addTo(group);
    } else {
      L.polyline([[a[1], a[0]], [b[1], b[0]]], { ...opts, color: (next <= target || progress >= 1) ? '#22a35a' : '#f26b21' }).addTo(group);
    }
    cum = next;
  }
  return group;
}
async function loadMap(fitView = true) {
  let r = await api('map'), bounds = [];
  if (!r || r.ok === false) { console.error('Erreur API carte:', r); return r || { ok: false, message: 'Réponse carte vide' }; }
  if (!mapDataLayer) mapDataLayer = L.layerGroup().addTo(map);
  mapDataLayer.clearLayers();
  drainPopupLayers = {};
  if (!Array.isArray(r.drains)) r.drains = [];
  // Tous les segments enregistrés sont regroupés par drain : ils sont donc visibles par tous les profils autorisés à la Carte SIG.
  const workByDrain = {};
  (r.work_segments || []).forEach(seg => {
    const id = Number(seg.drain_id);
    (workByDrain[id] || (workByDrain[id] = [])).push(seg);
  });
  const by = {};
  (r.drains || []).forEach(d => by[d.id] = d);

  // Les interventions sont dessinées en premier, puis le suivi des travaux au-dessus afin que vert/gris restent visibles.
  (r.interventions || []).forEach(i => {
    let gj = parseGeo(i.geom_json), d = by[i.drain_id];
    if (!gj && d) gj = parseGeo(d.geom_json);
    if (!gj) return;
    let l = L.geoJSON(gj, { style: interventionStyle(i), interactive: false }).addTo(mapDataLayer);
    l.bindPopup(`<b>${esc(i.reference)}</b><br>${esc(i.type_intervention)}<br>${esc(i.drain_nom)}<br>${esc(i.statut)}<br>${esc(i.date_prevue)}<br>${i.mission_autorisee ? 'Mission autorisée' : 'En attente des visas'}`);
  });

  (r.drains || []).forEach(d => {
    let gj = parseGeo(d.geom_json); if (!gj) return;
    let l = drawProgressiveDrain(d, gj, workByDrain[Number(d.id)] || []); if (!l) return;
    let hit = L.geoJSON(gj, { style: { color: '#000', weight: 14, opacity: 0, interactive: true } }).addTo(mapDataLayer);
    hit.bindPopup(`<div class="map-popup"><b>${esc(d.code)} — ${esc(d.nom)}</b><br>${esc(d.arrondissement)} · ${esc(d.type_drain)}<hr><b>Linéaire :</b> ${Number(d.lineaire_m || 0).toLocaleString('fr-FR')} m<br><b>Exécuté :</b> ${Number(d.lineaire_execute_m || 0).toLocaleString('fr-FR')} m<br><b>Sauté :</b> ${Number(d.lineaire_saute_m || 0).toLocaleString('fr-FR')} m<br><b>Restant :</b> ${Number(d.lineaire_restant_m || 0).toLocaleString('fr-FR')} m<br><b>Avancement :</b> ${Number(d.avancement_pct || 0)}%<br><b>État technique :</b> ${esc(d.etat)}<br><b>Direction :</b> ${d.direction_travaux === 'B_VERS_A' ? 'B → A' : 'A → B'}<br><b>État travaux :</b> ${esc(d.etat_travail)}</div>`);
    drainPopupLayers[String(d.id)] = hit;
    bounds.push(hit.getBounds());
  });

  const requestedDrainId = new URLSearchParams(window.location.search).get('drain_id');
  if (requestedDrainId && drainPopupLayers[String(requestedDrainId)]) {
    const requestedLayer = drainPopupLayers[String(requestedDrainId)];
    const requestedBounds = requestedLayer.getBounds();
    if (requestedBounds.isValid()) map.fitBounds(requestedBounds.pad(.35), { animate: true, duration: .5 });
    // Depuis le bouton « Voir », le popup s'ouvre après l'animation de chargement de 3 s.
    const popupDelay = 3000;
    setTimeout(() => requestedLayer.openPopup(), popupDelay);
  }

  if (fitView) {
    if (bounds.length) { let b = bounds[0]; bounds.slice(1).forEach(x => b = b.extend(x)); map.fitBounds(b.pad(.08)); }
    else map.setView([4.05, 9.70], 12);
  }
  setTimeout(() => map.invalidateSize(), 100);
  return r;
}

function drawLine(cb) { let c = new L.Control.Draw({ draw: { polyline: { shapeOptions: { color: '#002f6e', weight: 6 } }, polygon: false, rectangle: false, circle: false, marker: false, circlemarker: false }, edit: false }); map.addControl(c); map.once(L.Draw.Event.CREATED, e => { drawn.addLayer(e.layer); cb(e.layer.toGeoJSON(), lineLengthMeters(e.layer.getLatLngs())); map.removeControl(c) }) }
