<?php session_start();
if (empty($_SESSION['user'])) {
    header('Location:login.php');
    exit;
}
$__r = $_SESSION['user']['role'] ?? '';
$__lvl = (int) str_replace('NIVEAU_', '', $_SESSION['user']['niveau_accreditation'] ?? '1');
if (!in_array($__r, ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'CHEF_UNITE'], true) && (!in_array($__r, ['AGENT', 'INSPECTEUR'], true) || $__lvl < 2)) {
    header('Location:login.php');
    exit;
} ?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Rapports</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt" onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>

            <div class="head">
                <div>
                    <h1>Gestion des rapports</h1>
                    <div class="sub">Les rapports transmis depuis le terrain arrivent ici en direct.</div>
                </div>
            </div>
            <div class="grid kpis" id="k" style="margin-bottom:10px"></div>
            <div class="card" style="margin-bottom:16px">
                <div class="form">
                    <div class="field"><label>Rechercher</label><input id="searchReport"
                            placeholder="Titre, auteur, intervention ou drain…"></div>
                    <div class="field"><label>Type de rapport</label><select id="typeReport">
                            <option value="">Tous les types</option>
                            <option value="INTERVENTION">Rapport d’intervention</option>
                            <option value="ENTRETIEN">Rapport d’entretien</option>
                            <option value="INSPECTION">Rapport d’inspection</option>
                        </select></div>
                </div>
            </div>
            <div class="table">
                <table id="t">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Rapport</th>
                            <th>Auteur</th>
                            <th>Unité</th>
                            <th>Intervention</th>
                            <th>Fichiers</th>
                            <th>État</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>
    let rows = [];
    let filtered = [];

    function typeLabel(t) {
        return t === 'INTERVENTION' ? 'Rapport d’intervention' : t === 'ENTRETIEN' ? 'Rapport d’entretien' : t ===
            'INSPECTION' ? 'Rapport d’inspection' : t
    }

    function render() {
        const q = document.getElementById('searchReport').value.trim().toLowerCase(),
            type = document.getElementById('typeReport').value;
        filtered = rows.filter(r => (!type || r.type_rapport === type) && (!q || [r.titre, r.auteur_nom, r.reference, r
            .drain_nom
        ].some(v => String(v || '').toLowerCase().includes(q))));
        t.querySelector('tbody').innerHTML = filtered.map(r =>
            `<tr><td>${esc(r.date_envoi)}</td><td><b>${esc(r.titre)}</b><br><small>${esc(typeLabel(r.type_rapport))}</small></td><td>${esc(r.auteur_nom)}</td><td>${esc(r.unite_nom || '—')}</td><td>${esc(r.reference || '—')}<br>${esc(r.drain_nom || '')}</td><td><button class="btn alt" onclick="viewReport(${r.id})">Consulter</button></td><td>${badge(r.statut)}</td><td>${r.statut === 'ENVOYE' && <?= json_encode(in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS'], true)) ?> ? `<button class="btn" onclick="status(${r.id},'LU')">Marquer lu</button>` : ''}</td></tr>`
            ).join('') || '<tr><td colspan="8">Aucun rapport correspondant.</td></tr>'
    }
    async function load() {
        rows = await api('reports');
        rows = Array.isArray(rows) ? rows : [];
        k.innerHTML = [
            ['Total rapports', rows.length, ''],
            ['Nouveaux', rows.filter(x => x.statut === 'ENVOYE').length, 'À traiter'],
            ['Inspection', rows.filter(x => x.type_rapport === 'INSPECTION').length, ''],
            ['Entretien', rows.filter(x => x.type_rapport === 'ENTRETIEN').length, '']
        ].map(x =>
            `<div class="card"><div class="label">${x[0]}</div><div class="value">${x[1]}</div><div class="sub">${x[2]}</div></div>`
            ).join('');
        render()
    }
    async function viewReport(id) {
        let x = await api('report_detail', {
            id
        });
        if (!x.ok) return alert(x.message || 'Impossible de consulter le rapport.');
        const r = x.report;
        let w = window.open('', '_blank');
        if (!w) return;
        const files = (r.fichiers || []).map(f =>
            `<li><a href="download.php?source=rapport_file&id=${f.id}" target="_blank">${esc(f.type_fichier)} — ${esc(f.nom_fichier)}</a></li>`
            ).join('') || '<li>Aucun fichier joint.</li>';
        w.document.write(
            `<html><head><title>${esc(r.titre)}</title><style>body{font-family:Arial,sans-serif;max-width:900px;margin:40px auto;padding:0 20px;color:#222}h1{color:#002f6e}.meta{background:#f5f7fa;padding:15px;border-radius:10px;margin:15px 0}pre{white-space:pre-wrap;font:inherit;line-height:1.6}</style></head><body><h1>${esc(r.titre)}</h1><div class="meta"><b>Type :</b> ${esc(typeLabel(r.type_rapport))}<br><b>Date :</b> ${esc(r.date_envoi)}<br><b>Auteur :</b> ${esc(r.auteur_nom)}<br><b>Unité :</b> ${esc(r.unite_nom || '—')}<br><b>Intervention :</b> ${esc(r.reference || '—')}<br><b>Drain :</b> ${esc(r.drain_code || '—')} — ${esc(r.drain_nom || '—')}<br><b>Statut :</b> ${esc(r.statut)}</div><h2>Compte rendu</h2><pre>${esc(r.commentaire || 'Aucun commentaire.')}</pre><h2>Pièces jointes</h2><ul>${files}</ul></body></html>`
            );
        w.document.close()
    }
    async function status(id, s) {
        let r = await api('report_status', {
            id,
            status: s
        }, 'POST');
        if (r.ok) load();
        else alert(r.message)
    }
    document.getElementById('searchReport').addEventListener('input', render);
    document.getElementById('typeReport').addEventListener('change', render);
    guard(<?= json_encode($_SESSION['user']['role']) ?>).then(load);
    setInterval(load, 15000)
    </script>
</body>

</html>