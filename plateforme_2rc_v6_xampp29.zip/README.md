
5. Ouvrir `http://localhost/plateforme_2rc_v6_xampp29/login.php`.

- Chef service : `admin@2rc.local` / `admin123`
- Sous-directeur opérations : `operations@2rc.local` / `operations123`
- Inspecteur : `inspection@2rc.local` / `inspection123`
- Agent : `paul@2rc.local` / `agent123`
- Directeur : `directeur@2rc.local` / `directeur123`
