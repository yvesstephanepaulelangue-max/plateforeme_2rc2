# 2RC — Déploiement InfinityFree

Cette archive est configurée pour l'hébergement InfinityFree fourni pour le projet.

## 1. Base de données

La connexion de `api/db.php` est configurée pour la base InfinityFree existante. Ne modifiez pas les identifiants si vous utilisez cette base.

Pour initialiser une nouvelle base, utilisez `database/schema.sql`, puis `database/seed.sql` si vous souhaitez les données de démonstration. Les scripts ont été adaptés pour ne pas tenter de créer la base elle-même.

## 2. Envoi des fichiers

1. Ouvrir le gestionnaire de fichiers FTP/Online File Manager InfinityFree.
2. Ouvrir le dossier `htdocs` du domaine.
3. Envoyer le contenu de `plateforme_2rc_v6_xampp28/` dans `htdocs`.
4. Conserver les sous-dossiers `api`, `assets`, `assets-2`, `database`, `data`, etc.

## 3. Première ouverture

Ouvrir le domaine dans un navigateur. La plateforme démarre par `intro.php`.

`api/db.php` applique ensuite uniquement les vérifications/mises à niveau non destructives déjà prévues par la plateforme.

## 4. Important

Le mot de passe MySQL est intégré à `api/db.php` pour permettre à la plateforme de fonctionner immédiatement. Après le premier déploiement, il est recommandé de changer le mot de passe MySQL dans le panneau InfinityFree puis de mettre à jour `api/db.php`.

Ne publiez pas ce fichier dans un dépôt public.
