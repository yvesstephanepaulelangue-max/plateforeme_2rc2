<?php
// Point d'entrée principal : toujours commencer par l'écran d'introduction.
header('Location: intro.php');
exit;
