<?php session_start();
if (isset($_SESSION['user'])) {
    header('Location:route.php');
    exit;
}
if (empty($_SESSION['intro_seen']) && !isset($_GET['intro'])) {
    header('Location:intro.php');
    exit;
}
unset($_SESSION['intro_seen']); ?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Accès plateforme</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body class="login" style="min-height: 100%;margin-top:5%;overflow-y: auto;
    overflow-x: hidden;">
    <div class="login-shell">
        <section class="login-visual">
            <div class="login-copy">
                <div style="font-weight:900;font-size:34px"></div>
                <div style="opacity:.8;font-size:12px"></div>
                <h1>Une plateforme de terrain et décisionnelle.</h1>
                <p>Suivi des drains, interventions, visas, équipes et rapports dans un même espace.</p>
            </div><img class="engineer" src="assets/logo-plateforme.svg"
                alt="Illustration d’un ingénieur en tenue de travail 2RC">
        </section>
        <section class="login-form">
            <div id="loginPanel" class="auth-panel">
                <div class="brand">Connexion</div>
                <p class="sub">Accédez à votre espace 2RC.</p>
                <form id="loginForm" class="form" style="display:block">
                    <div class="field"><label>Email</label><input name="email" type="email" required
                            autocomplete="username"></div>
                    <div class="field" style="margin-top:12px"><label>Mot de passe</label>
                        <input name="password"type="password" required autocomplete="current-password">
                    </div><button class="btn"style="width:100%;margin-top:16px">Se connecter</button>
                </form>
                <p style="margin-top:12px"><a href="recuperation.php">Mot de passe oublié ?</a></p>
                <div class="auth-switch">Pas encore de compte ? <button class="linkbtn" type="button"
                        onclick="showRegister()">Créer un compte</button></div>
            </div>
            <div id="registerPanel" class="auth-panel" style="display:none;overflow-y:scroll;">
                <div class="brand">Inscription</div>
                <p class="sub">Création d’une demande de compte à valider par le chef de service.</p>
                <form id="registerForm" class="form" style="max-height: 80vh;overflow-y: auto;overflow-x: hidden;">
                    <div class="field">
                        <label>Nom</label>
                        <input name="nom" required>
                    </div>
                    <div class="field">
                        <label>Prénom</label>
                        <input name="prenom" required>
                    </div>
                    <div class="field">
                        <label>Email</label>
                        <input name="email" type="email" optional>
                    </div>
                    <div class="field">
                        <label>Téléphone</label>
                        <input name="telephone" type="tel" required maxlength="9" minlength="9">
                    </div>
                    <div class="field full">
                        <label>Type de profil</label>
                        <select name="type_compte" id="typeCompte" required>
                            <option value="AGENT_2RC">Agent 2RC</option>
                            <option value="STAGIAIRE">Stagiaire</option>
                            <option value="TEMPORAIRE">Temporaire</option>
                        </select><small class="sub">Le matricule est obligatoire uniquement pour un Agent 2RC.</small>
                    </div>
                    <div class="field" id="matriculeField">
                        <label>Matricule (4 chiffres)</label>
                        <input name="matricule"id="matriculeInput" inputmode="numeric" maxlength="4" minlength="4" pattern="[0-9]{4}"placeholder="Ex. 0123">
                    </div>
                    <div class="field full">
                        
                    </div>
                    <div class="field full">
                        <label>Mot de passe (8 caractères minimum)</label>
                        <input name="password"type="password" minlength="8" required>
                    </div>
                    <div class="field full">
                        <label>Créer votre phrase de récupération</label>
                        <input name="recovery_phrase"type="text" maxlength="255" required>
                    </div>
                    <div class="field full">
                        <label>Créer la réponse de récupération</label>
                        <input name="recovery_answer" type="text" maxlength="255" required>
                    </div>
                    <div class="field full">
                        <button class="btn" style="width:100%">Créer le compte</button>
                    </div>
                </form>
                <div id="regMsg" class="notice"></div>
                <div class="auth-switch">Déjà inscrit ? <button class="linkbtn" type="button" onclick="showLogin()">Se
                        connecter</button></div>
            </div>
        </section>
    </div>
    <script src="assets/app.js"></script>
    <script>const loginPanelEl = document.getElementById('loginPanel'), registerPanelEl = document.getElementById('registerPanel'), loginFormEl = document.getElementById('loginForm'), registerFormEl = document.getElementById('registerForm'), msgEl = document.getElementById('msg'), regMsgEl = document.getElementById('regMsg'); function showRegister() { loginPanelEl.style.display = 'none'; registerPanelEl.style.display = 'block' } function showLogin() { registerPanelEl.style.display = 'none'; loginPanelEl.style.display = 'block' } loginFormEl.onsubmit = async e => { e.preventDefault(); let r = await api('login', new FormData(loginFormEl), 'POST'); if (r.ok) location = 'route.php'; else msgEl.textContent = r.message }; const typeCompteEl = document.getElementById('typeCompte'), matriculeFieldEl = document.getElementById('matriculeField'), matriculeInputEl = document.getElementById('matriculeInput'); function syncTypeCompte() { const agent = typeCompteEl.value === 'AGENT_2RC'; matriculeFieldEl.style.display = agent ? 'block' : 'none'; matriculeInputEl.required = agent; if (!agent) matriculeInputEl.value = ''; } typeCompteEl.addEventListener('change', syncTypeCompte); syncTypeCompte(); matriculeInputEl.addEventListener('input', () => { matriculeInputEl.value = matriculeInputEl.value.replace(/\D/g, '').slice(0, 4) }); registerFormEl.onsubmit = async e => { e.preventDefault(); let r = await api('register', new FormData(registerFormEl), 'POST'); if (r.ok) { regMsgEl.textContent = r.message; registerFormEl.reset(); setTimeout(showLogin, 1200) } else regMsgEl.textContent = r.message }</script>
</body>

</html>