<?php session_start();
if (empty($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true)) {
    header('Location:login.php');
    exit;
} ?><!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Corbeille</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt"
            onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Corbeille</h1>
                    <div class="sub">Drains supprimés et comptes supprimés conservés sans perte de données.</div>
                </div>
            </div>
            <div class="tabbar"><button class="tabbtn active" onclick="tab('drains',this)">Corbeille des
                    drains</button><button class="tabbtn" onclick="tab('users',this)">Corbeille des comptes</button>
            </div>
            <section id="drains">
                <div class="notice">Les drains supprimés sont restaurables avec leur dernier instantané enregistré.
                </div>
                <div class="grid kpis" id="stats" style="margin-bottom: 10px;"></div>
                <div class="card">
                    <div class="table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Drain</th>
                                    <th>Arrondissement</th>
                                    <th>Type</th>
                                    <th>Linéaire</th>
                                    <th>Supprimé par</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="body">
                                <tr>
                                    <td colspan="7">Chargement…</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
            <section id="users" class="hidden">
                <div class="notice">Un compte supprimé reste conservé dans la base. Il peut être restauré par un
                    responsable autorisé.</div>
                <div class="grid kpis">
                    <div class="card kpi">
                        <div class="label">COMPTES SUPPRIMÉS</div>
                        <div class="value" id="userCount">0</div>
                    </div>
                </div>
                <div class="card">
                    <div class="table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Utilisateur</th>
                                    <th>Profil</th>
                                    <th>Rôle</th>
                                    <th>Poste</th>
                                    <th>Suppression confirmée</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="userBody">
                                <tr>
                                    <td colspan="6">Chargement…</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>let rows = [], users = []; function tab(id, b) { document.querySelectorAll('main section').forEach(s => s.classList.add('hidden')); document.getElementById(id).classList.remove('hidden'); document.querySelectorAll('.tabbtn').forEach(x => x.classList.remove('active')); b.classList.add('active'); if (id === 'users') loadUsers(); } function snap(x) { return x.drain_snapshot || {} } function render() { body.innerHTML = rows.map(x => { let d = snap(x); return `<tr><td>${esc(x.date_modification)}</td><td><b>${esc(d.code || '—')}</b><br><small>${esc(d.nom || 'Drain supprimé')}</small></td><td>${esc(d.arrondissement || '—')}</td><td>${esc(d.type_drain || '—')}</td><td>${Number(d.lineaire_m || 0).toLocaleString('fr-FR')} m</td><td>${esc((x.utilisateur_nom || 'Utilisateur supprimé').trim())}<br><small>${esc(x.role || '—')}</small></td><td><button class="btn" onclick="restore(${x.id})">Restaurer</button></td></tr>` }).join('') || '<tr><td colspan="7">La corbeille des drains est vide.</td></tr>'; stats.innerHTML = `<div class="card kpi"><div class="label">DRAINS SUPPRIMÉS</div><div class="value">${rows.length}</div></div>` } async function restore(id) { if (!confirm('Restaurer ce drain ?')) return; let r = await api('restore_drain', { log_id: id }, 'POST'); toast(r.message || 'Opération terminée.', r.ok ? 'success' : 'error'); if (r.ok) load() } async function load() { let r = await api('drain_trash'); rows = Array.isArray(r) ? r : []; render() } async function loadUsers() { let r = await api('user_trash'); users = Array.isArray(r) ? r : []; userCount.textContent = users.length; userBody.innerHTML = users.map(u => `<tr><td><b>${esc(u.prenom)} ${esc(u.nom)}</b><br><small>${esc(u.email)}</small></td><td>${esc(u.type_compte || 'AGENT_2RC')}</td><td>${badge(u.role)}</td><td>${esc(u.poste || '—')}</td><td>${esc(u.suppression_confirmee_at || '—')}</td><td><?= in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS'], true) ? '<button class="btn alt" onclick="restoreUser(${u.id})">Restaurer</button>' : 'Lecture seule' ?></td></tr>`).join('') || '<tr><td colspan="6">La corbeille des comptes est vide.</td></tr>' } async function restoreUser(id) { if (!confirm('Restaurer ce compte et autoriser son accès ?')) return; let r = await api('restore_user', { id }, 'POST'); toast(r.message || 'Opération terminée.', r.ok ? 'success' : 'error'); if (r.ok) loadUsers() } guard(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']).then(load); startAutoRefresh(load, 2000);</script>
</body>

</html>