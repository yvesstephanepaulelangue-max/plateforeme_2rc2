<?php session_start();
if (empty($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'INSPECTEUR', 'AGENT', 'DIRECTEUR', 'CHEF_UNITE'], true)) {
    header('Location:login.php');
    exit;
}
?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Drains</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt" onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head reveal">
                <div>
                    <h1>Gestion des drains</h1>
                    <div class="sub">État hydraulique, linéaire curé, partie sautée, direction des travaux et priorité
                        décisionnelle.</div>
                </div>
                <?php if (in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS'], true)): ?><button
                    class="btn gold" onclick="newDrain()">＋ Nouveau drain</button><?php endif; ?>
            </div>
            <div class="grid kpis reveal delay1" style="margin-bottom:15px">
                <div class="card kpi">
                    <div class="label">DRAINS</div>
                    <div class="value" id="kTotal">0</div>
                    <div class="sub">référencés</div>
                </div>
                <div class="card kpi">
                    <div class="label">LINÉAIRE TOTAL</div>
                    <div class="value" id="kLinear">0 m</div>
                    <div class="sub">naturels + bétonnés</div>
                </div>
                <div class="card kpi">
                    <div class="label">EXÉCUTÉ</div>
                    <div class="value" id="kDone">0 m</div>
                    <div class="sub">partie réalisée</div>
                </div>
                <div class="card kpi">
                    <div class="label">RESTANT</div>
                    <div class="value" id="kRemain">0 m</div>
                    <div class="sub">à traiter</div>
                </div>
            </div>
            <div class="card reveal delay2" style="margin-bottom:15px">
                <div class="form">
                    <div class="field"><label>Rechercher</label><input id="search" placeholder="Code ou nom du drain">
                    </div>
                    <div class="field"><label>Priorité</label><select id="prio">
                            <option value="">Toutes</option>
                            <option>P1</option>
                            <option>P2</option>
                            <option>P3</option>
                            <option>P4</option>
                        </select></div>
                    <div class="field"><label>État des travaux</label><select id="state">
                            <option value="">Tous</option>
                            <option>PROGRAMME</option>
                            <option>NON_PROGRAMME</option>
                            <option>EN_COURS</option>
                            <option>SUSPENDU</option>
                            <option>REPORTE</option>
                            <option>TERMINE</option>
                        </select></div>
                    <div class="field"><label>État technique</label><select id="tech">
                            <option value="">Tous</option>
                            <option>DEBIT_CORRECT</option>
                            <option>SATURATION_PARTIELLE</option>
                            <option>SATURATION_TOTAL</option>
                        </select></div>
                </div>
            </div>
            <div class="card reveal delay3">
                <div class="table">
                    <table id="t">
                        <thead>
                            <tr>
                                <th>Drain</th>
                                <th>Arr.</th>
                                <th>Linéaire</th>
                                <th>Avancement</th>
                                <th>État travaux</th>
                                <th>État technique</th>
                                <th>Exécuté</th>
                                <th>Sauté</th>
                                <th>Restant</th>
                                <th>Priorité</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div id="modal" class="modal">
                <div class="card modalbox wide">
                    <div class="head">
                        <div>
                            <h2 id="title">Drain</h2>
                            <div class="sub">Les valeurs d’avancement sont recalculées automatiquement.</div>
                        </div><button class="btn alt" onclick="closeM()">Fermer</button>
                    </div>
                    <form id="f" class="form"><input type="hidden" name="id"><input type="hidden" name="geom_json"
                            id="geom"><input type="hidden" name="source_kml">
                        <div class="field"><label>Code</label><input name="code" required></div>
                        <div class="field"><label>Nom</label><input name="nom" required></div>
                        <div class="field"><label>Arrondissement</label><input name="arrondissement" required></div>
                        <div class="field"><label>Type</label><select name="type_drain">
                                <option>NATUREL</option>
                                <option>BETONNE</option>
                            </select></div>
                        <div class="field"><label>Linéaire total (m)</label><input name="lineaire_m" type="number"
                                min="0" step="0.01" required></div>
                        <div class="field"><label>Linéaire exécuté (m)</label><input name="lineaire_execute_m"
                                type="number" min="0" step="0.01" value="0"></div>
                        <div class="field"><label>Linéaire sauté (m)</label><input name="lineaire_saute_m" type="number"
                                min="0" step="0.01" value="0"><small class="sub">Partie du drain qui ne nécessite pas de
                                curage.</small></div>
                        <div class="field"><label>Direction des travaux</label><select name="direction_travaux">
                                <option value="A_VERS_B">Point A → Point B</option>
                                <option value="B_VERS_A">Point B → Point A</option>
                            </select></div>
                        <div class="field"><label>État des travaux</label><select name="etat_travail">
                                <option>PROGRAMME</option>
                                <option>NON_PROGRAMME</option>
                                <option>EN_COURS</option>
                                <option>SUSPENDU</option>
                                <option>REPORTE</option>
                                <option>TERMINE</option>
                            </select></div>
                        <div class="field"><label>État technique</label><select name="etat">
                                <option value="DEBIT_CORRECT">Débit correct</option>
                                <option value="SATURATION_PARTIELLE">Saturation partielle</option>
                                <option value="SATURATION_TOTAL">Saturation totale</option>
                            </select></div>
                        <div class="field full">
                            
                        </div>
                        <div class="field"><label>Criticité hydraulique ×6</label><select name="criticite_hydraulique">
                                <option value="1">1 — Écoulement local</option>
                                <option value="3">3 — Collecteur secondaire</option>
                                <option value="5">5 — Exutoire / vallée / refoulement</option>
                            </select></div>
                        <div class="field"><label>Exposition urbaine ×5</label><select name="exposition_urbaine">
                                <option value="1">1 — Faible densité</option>
                                <option value="3">3 — Habitat/commerces moyens</option>
                                <option value="5">5 — Marché / habitat dense / carrefour</option>
                            </select></div>
                        <div class="field"><label>Équipement sensible ×3</label><select name="equipement_sensible">
                                <option value="1">1 — Aucun</option>
                                <option value="3">3 — Commerce / activité</option>
                                <option value="5">5 — Hôpital / centre / école / aéroport</option>
                            </select></div>
                        <div class="field"><label>Réseau stratégique ×4</label><select name="reseau_strategique">
                                <option value="1">1 — Voie locale</option>
                                <option value="3">3 — Axe secondaire</option>
                                <option value="5">5 — RN3 / PK8 / Ndokoti / aéroport / port</option>
                            </select></div>
                        <div class="field"><label>Difficulté accès/curage ×2</label><select name="difficulte_curage">
                                <option value="1">1 — Manuel simple</option>
                                <option value="3">3 — Engin nécessaire</option>
                                <option value="5">5 — Fermé / exutoire / espace confiné</option>
                            </select></div>
                        <div class="field full"><label>Observation</label><textarea name="observation"
                                rows="4"></textarea></div>
                        <div class="field full" style="display:flex;justify-content:space-between;gap:10px">
                            <button class="btn">Enregistrer le drain</button>
                            <button type="button" id="deleteBtn" class="btn danger" onclick="deleteDrain()"
                                style="display:none">Supprimer</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>
    const modalEl = document.getElementById('modal'),
        formEl = document.getElementById('f'),
        tableEl = document.getElementById('t'),
        titleEl = document.getElementById('title'),
        deleteBtn = document.getElementById('deleteBtn'),
        searchEl = document.getElementById('search'),
        prioEl = document.getElementById('prio'),
        stateEl = document.getElementById('state'),
        techEl = document.getElementById('tech');
    let rows = [];

    function closeM() {
        modalEl.classList.remove('show')
    }

    function closeM() {
        modalEl.classList.remove('show')
    }

    function bar(p) {
        let n = Math.max(0, Math.min(100, Number(p) || 0));
        let color;
        
        if (n >= 80) {
            color = 'green';
        } else if (n > 30 && n <= 79) {
            color = 'orange';
        } else {
            color = 'red';
        }

        return `<div class="progress-wrap"><div class="progress"><span style="width:${n}%; background-color:${color};"></span></div><b>${n.toFixed(0)}%</b></div>`;
    }

    function render() {
        let q = searchEl.value.trim().toLowerCase(),
            p = prioEl.value,
            st = stateEl.value,
            te = techEl.value;
        let rr = rows.filter(d => (!q || (String(d.nom) + ' ' + String(d.code)).toLowerCase().includes(q)) && (!p || d
            .priorite === p) && (!st || d.etat_travail === st) && (!te || d.etat === te));
        tableEl.querySelector('tbody').innerHTML = rr.map(d =>
            `<tr><td><b>${esc(d.code)}</b><br><small>${esc(d.nom)}</small></td><td>${esc(d.arrondissement)}</td><td>${Number(d.lineaire_m || 0).toLocaleString('fr-FR')} m</td><td>${bar(d.avancement_pct)}</td><td>${badge(d.etat_travail)}</td><td>${badge(d.etat)}</td><td>${Number(d.lineaire_execute_m || 0).toLocaleString('fr-FR')} m</td><td>${Number(d.lineaire_saute_m || 0).toLocaleString('fr-FR')} m</td><td>${Number(d.lineaire_restant_m || 0).toLocaleString('fr-FR')} m</td><td>${badge(d.priorite)}<br><small>score ${d.score_priorite}</small></td><td><?php if (in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS'], true)): ?><div style="display:flex;gap:6px;align-items:center;justify-content:flex-end;flex-wrap:wrap"><button class="btn alt" type="button" onclick="editDrain(${d.id})">Modifier</button><a class="btn" href="carte.php?drain_id=${encodeURIComponent(d.id)}">Voir</a></div><?php else: ?><a class="btn alt" href="carte.php?drain_id=${encodeURIComponent(d.id)}">Voir</a><?php endif; ?></td></tr>`
            ).join('') || '<tr><td colspan="11">Aucun drain correspondant.</td></tr>'
    }

    
    function updateKpis() {
        let total = rows.reduce((a, d) => a + Number(d.lineaire_m || 0), 0),
            done = rows.reduce((a, d) => a + Number(d.lineaire_execute_m || 0) + Number(d.lineaire_saute_m || 0), 0),
            remain = rows.reduce((a, d) => a + Number(d.lineaire_restant_m || 0), 0);
        document.getElementById('kTotal').textContent = rows.length;
        document.getElementById('kLinear').textContent = total.toLocaleString('fr-FR') + ' m';
        document.getElementById('kDone').textContent = done.toLocaleString('fr-FR') + ' m';
        document.getElementById('kRemain').textContent = remain.toLocaleString('fr-FR') + ' m'
    }
    async function load() {
        let r = await api('drains');
        if (!Array.isArray(r)) return toast(r.message || 'Impossible de charger les drains.', 'error');
        rows = r;
        render();
        updateKpis()
    }

    function fill(d) {
        ['id', 'code', 'nom', 'arrondissement', 'type_drain', 'lineaire_m', 'lineaire_execute_m', 'lineaire_saute_m',
            'direction_travaux', 'etat_travail', 'etat', 'observation', 'criticite_hydraulique', 'exposition_urbaine',
            'equipement_sensible', 'reseau_strategique', 'difficulte_curage', 'geom_json', 'source_kml'
        ].forEach(k => {
            if (formEl.elements[k]) formEl.elements[k].value = d[k] ?? ''
        })
    }

    function newDrain() {
        formEl.reset();
        formEl.elements.id.value = '';
        formEl.elements.lineaire_execute_m.value = '0';
        formEl.elements.lineaire_saute_m.value = '0';
        titleEl.textContent = 'Nouveau drain';
        deleteBtn.style.display = 'none';
        let g = sessionStorage.getItem('newDrainGeom'),
            len = sessionStorage.getItem('newDrainLength');
        if (g) {
            formEl.elements.geom_json.value = g;
            formEl.elements.lineaire_m.value = len || '';
            formEl.elements.source_kml.value = 'Dessin SIG';
            sessionStorage.removeItem('newDrainGeom');
            sessionStorage.removeItem('newDrainLength')
        }
        modalEl.classList.add('show');
        formEl.elements.code.focus()
    }

    function editDrain(id) {
        let d = rows.find(x => +x.id === +id);
        if (!d) return toast('Drain introuvable', 'error');
        fill(d);
        titleEl.textContent = 'Modifier — ' + d.nom;
        deleteBtn.style.display = 'block';
        modalEl.classList.add('show')
    }
    async function deleteDrain() {
        let id = +formEl.elements.id.value;
        if (!id) return;
        if (!confirm('Supprimer définitivement ce drain ?')) return;
        let r = await api('delete_drain', {
            id
        }, 'POST');
        if (r.ok) {
            toast('Drain supprimé.');
            closeM();
            load()
        } else toast(r.message, 'error')
    }
    formEl.onsubmit = async e => {
        e.preventDefault();
        let total = +formEl.elements.lineaire_m.value || 0,
            ex = +formEl.elements.lineaire_execute_m.value || 0,
            sa = +formEl.elements.lineaire_saute_m.value || 0;
        if (ex + sa > total) return toast('Exécuté + sauté ne peut pas dépasser le linéaire total.', 'error');
        let r = await api(formEl.elements.id.value ? 'update_drain' : 'create_drain', new FormData(formEl),
            'POST');
        if (r.ok) {
            toast('Drain enregistré.');
            closeM();
            load()
        } else toast(r.message || 'Échec.', 'error')
    };
    [searchEl, prioEl, stateEl, techEl].forEach(x => x.addEventListener('input', render));
    guard(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'INSPECTEUR', 'AGENT', 'DIRECTEUR', 'CHEF_UNITE']).then(load);
    startAutoRefresh(load, 10000);
    </script>
</body>

</html>