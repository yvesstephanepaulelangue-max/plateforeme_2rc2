<?php session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'INSPECTEUR') {
    header('Location:login.php');
    exit;
} ?><!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Inspection</title>
    <link rel="stylesheet" href="assets/app.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt"
            onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Unité d’inspection O1</h1>
                    <div class="sub">Suivi des membres, drains à observer et rapports terrain.</div>
                </div>
            </div>
            <div class="card" style="margin-bottom:16px">
                <h3>Carte SIG</h3>
                <div class="map-shell">
                    <div id="map" style="height:430px;min-height:430px"></div>
                    <div id="mapLoading" class="map-loading">
                        <div class="map-loading-box"><b>Chargement de la carte SIG…</b>
                            <div class="map-loading-bar"><span id="mapLoadingBar"></span></div><small
                                id="mapLoadingText">10 secondes</small>
                        </div>
                    </div>
                </div>
            </div>
            <div id="stats" class="grid three">
                <div class="card kpi">
                    <div class="label">MEMBRES DE L’UNITÉ</div>
                    <div class="value" id="membersCount">0</div>
                    <div id="memberNames" class="sub">—</div>
                </div>
                <div class="card kpi">
                    <div class="label">DRAINS À OBSERVER</div>
                    <div class="value" id="toObserve">0</div>
                </div>
                <div class="card kpi">
                    <div class="label">DRAINS OBSERVÉS</div>
                    <div class="value" id="observed">0</div>
                </div>
            </div>
            <div class="card" style="margin-top:16px">
                <h3>Inspection et rapport terrain</h3>
                <div class="notice">La liste des drains contient uniquement les drains affectés à votre unité. Après
                    l’envoi d’un rapport, le drain disparaît automatiquement de cette liste.</div>
                <form id="f" class="form">
                    <div class="field full"><label>Drain observé</label><select name="drain_id" id="d"
                            required></select></div>
                    <div class="field"><label>Intervention d’inspection affectée</label><select name="intervention_id"
                            id="inter">
                            <option value="">— Aucune —</option>
                        </select></div>
                    <div class="field"><label>État de dégradation</label><select name="etat_degradation">
                            <option>BON</option>
                            <option>LEGER</option>
                            <option>MOYEN</option>
                            <option>FORT</option>
                            <option>CRITIQUE</option>
                        </select></div>
                    <div class="field"><label>Criticité hydraulique ×6</label><select name="criticite_hydraulique">
                            <option value="1">1</option>
                            <option value="3">3</option>
                            <option value="5">5</option>
                        </select></div>
                    <div class="field"><label>Exposition urbaine ×5</label><select name="exposition_urbaine">
                            <option value="1">1</option>
                            <option value="3">3</option>
                            <option value="5">5</option>
                        </select></div>
                    <div class="field"><label>Équipement sensible ×3</label><select name="equipement_sensible">
                            <option value="1">1</option>
                            <option value="3">3</option>
                            <option value="5">5</option>
                        </select></div>
                    <div class="field"><label>Réseau stratégique ×4</label><select name="reseau_strategique">
                            <option value="1">1</option>
                            <option value="3">3</option>
                            <option value="5">5</option>
                        </select></div>
                    <div class="field"><label>Difficulté accès/curage ×2</label><select name="difficulte_curage">
                            <option value="1">1</option>
                            <option value="3">3</option>
                            <option value="5">5</option>
                        </select></div>
                    <div class="field full"><label>Titre du rapport</label><input name="titre" required
                            placeholder="Rapport d’inspection — Drain…"></div>
                    <div class="field full"><label>Observations / dégradations constatées</label><textarea
                            name="observations" rows="6" required></textarea></div>
                    <div class="field"><label>Photos (3 max)</label><input name="images[]" id="imgs" type="file"
                            accept="image/jpeg,image/png,image/webp,image/gif" multiple></div>
                    <div class="field"><label>Statut de l’intervention</label><select name="status">
                            <option>EN_COURS</option>
                            <option>TERMINEE</option>
                            <option>PLANIFIEE</option>
                        </select></div>
                    <div class="field full"><button class="btn">Envoyer le rapport et enregistrer l’inspection</button>
                    </div>
                </form>
            </div>
    </div>
    </main>
    </div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="assets/app.js?v=27"></script>
    <script src="assets/map.js"></script>
    <script>const dEl = document.getElementById('d'), interEl = document.getElementById('inter'), formEl = document.getElementById('f'); async function load() { let c = await api('inspection_context', { _v: 27 }); if (!c || !c.members) c = { members: [], to_observe: [], observed: 0 }; let assigned = await api('my_unit_drains', { _v: 27 }); if (assigned && assigned.ok && Array.isArray(assigned.drains)) c.to_observe = assigned.drains; document.getElementById('membersCount').textContent = c.members.length; document.getElementById('memberNames').textContent = c.members.join(' · ') || 'Aucun membre'; document.getElementById('toObserve').textContent = c.to_observe.length; document.getElementById('observed').textContent = c.observed; let availableDrains = Array.isArray(c.to_observe) ? c.to_observe : []; dEl.innerHTML = availableDrains.map(x => `<option value="${x.id}">${esc(x.code)} — ${esc(x.nom)}</option>`).join('') || '<option value="">Aucun drain à observer</option>'; let w = await api('my_work'); w = Array.isArray(w) ? w.filter(i => i.type_intervention === 'INSPECTION') : []; interEl.innerHTML = '<option value="">— Aucune —</option>' + w.map(i => `<option value="${i.id}" data-drain="${i.drain_id}">${esc(i.reference)} — ${esc(i.drain_nom)}</option>`).join(''); interEl.onchange = () => { let o = interEl.selectedOptions[0]; if (o?.dataset.drain) dEl.value = o.dataset.drain } } formEl.onsubmit = async e => { e.preventDefault(); if (!dEl.value) return toast('Aucun drain à observer.', 'error'); if (document.getElementById('imgs').files.length > 3) return toast('Maximum 3 photos.', 'error'); let r = await api('inspection_save', new FormData(formEl), 'POST'); if (r.ok) { toast('Rapport transmis et inspection enregistrée.'); formEl.reset(); load() } else toast(r.message || 'Échec de l’enregistrement.', 'error') }; guard('INSPECTEUR').then(async () => { let r = await api('map'); initMap(r.settings || {}); loadMap(); startMapLoader(); load() }); function startMapLoader() { let t = 0, bar = document.getElementById('mapLoadingBar'), ov = document.getElementById('mapLoading'), txt = document.getElementById('mapLoadingText'); let x = setInterval(() => { t += 100; let p = t / 100; bar.style.width = p + '%'; txt.textContent = p < 100 ? 'Chargement — ' + Math.ceil(10 - t / 1000) + ' s' : 'Carte prête'; if (t >= 10000) { clearInterval(x); setTimeout(() => ov.classList.add('hide'), 250) } }, 100) }
    startAutoRefresh(async () => { await load(); if (typeof loadMap === 'function' && window.map) await loadMap(false); }, 2000);
</script>
</body>

</html>