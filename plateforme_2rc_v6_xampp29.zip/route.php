<?php session_start();
if (empty($_SESSION['user'])) {
    header('Location:login.php');
    exit;
}
$r = $_SESSION['user']['role'];
if (in_array($r, ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS'], true)) {
    header('Location:dashboard.php');
} elseif ($r === 'INSPECTEUR') {
    header('Location:inspection.php');
} elseif ($r === 'AGENT') {
    header('Location:entretien.php');
} elseif ($r === 'CHEF_UNITE') {
    header('Location:chef-unite.php');
} else {
    header('Location:dashboard.php');
}
exit;