<?php session_start();
if (empty($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['ADMIN','SOUS_DIRECTEUR_OPERATIONS','DIRECTEUR'], true)) { header('Location:login.php'); exit; }
?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Journal des drains</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b><small></small></b><span><?=htmlspecialchars($_SESSION['user']['prenom'].' '.$_SESSION['user']['nom'])?>
            · <?=htmlspecialchars($_SESSION['user']['role'])?> <button class="btn alt"
                onclick="logout()">Déconnexion</button></span></header>
    <div class="layout"><?php require __DIR__.'/assets/nav.php'; ?><main>
            <div class="head reveal">
                <div>
                    <h1>Journal des modifications des drains</h1>
                    <div class="sub">Journal chronologique et traçable de toutes les modifications enregistrées sur les
                        données des drains.</div>
                </div>
            </div>
            <div class="grid kpis" id="stats" style="margin-bottom: 10px;"></div>
            <div class="card reveal">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
                    <div>
                        <h3 style="margin:0">Journal des modifications</h3>
                        <p class="sub" style="margin:4px 0 0">Chaque enregistrement indique qui a modifié les données et
                            quand.</p>
                    </div><select id="filterAction" class="input" style="max-width:240px">
                        <option value="">Toutes les actions</option>
                        <option>CREATION</option>
                        <option>MODIFICATION</option>
                        <option>INSPECTION</option>
                        <option>SUPPRESSION</option>
                        <option>RESTAURATION</option>
                    </select>
                </div>
                <div class="table" style="margin-top:14px">
                    <table>
                        <thead>
                            <tr>
                                <th>Date / heure</th>
                                <th>Drain</th>
                                <th>Action</th>
                                <th>Utilisateur</th>
                                <th>Rôle</th>
                                <th>Détails</th>
                            </tr>
                        </thead>
                        <tbody id="body">
                            <tr>
                                <td colspan="6">Chargement…</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>
    let logs = [];

    function pretty(v) {
        try {
            return JSON.parse(v)
        } catch {
            return null
        }
    }

    function diff(oldv, newv) {
        const a = pretty(oldv) || {},
            b = pretty(newv) || {};
        const keys = [...new Set([...Object.keys(a), ...Object.keys(b)])];
        const labels = {
            nom: 'Nom',
            code: 'Code',
            arrondissement: 'Arrondissement',
            type_drain: 'Type',
            lineaire_m: 'Linéaire',
            etat: 'État technique',
            etat_travail: 'État travail',
            avancement_pct: 'Avancement',
            lineaire_execute_m: 'Exécuté',
            lineaire_saute_m: 'Sauté',
            lineaire_restant_m: 'Restant',
            direction_travaux: 'Direction',
            observation: 'Observation',
            unite_inspection_id: 'Unité inspection'
        };
        return keys.filter(k => JSON.stringify(a[k]) !== JSON.stringify(b[k])).slice(0, 8).map(k =>
                `<b>${esc(labels[k]||k)}</b>: ${esc(a[k]??'—')} → ${esc(b[k]??'—')}`).join('<br>') ||
            'Aucune différence détaillée';
    }

    function actionBadge(a) {
        const map = {
            CREATION: 'Création',
            MODIFICATION: 'Modification',
            INSPECTION: 'Inspection',
            SUPPRESSION: 'Suppression',
            RESTAURATION: 'Restauration'
        };
        return `<span class="badge">${map[a]||esc(a)}</span>`
    }

    function render() {
        const f = filterAction.value;
        const rows = logs.filter(x => !f || x.action === f);
        body.innerHTML = rows.map(x => {
            const old = pretty(x.ancienne_valeur) || {};
            const neu = pretty(x.nouvelle_valeur) || {};
            const code = x.code || old.code || neu.code || '—';
            const nom = x.nom || old.nom || neu.nom || 'Drain supprimé';
            let details = x.action === 'MODIFICATION' || x.action === 'INSPECTION' ? diff(x.ancienne_valeur, x
                    .nouvelle_valeur) : x.action === 'CREATION' ? 'Nouveau drain créé' : x.action ===
                'RESTAURATION' ? 'Drain restauré depuis la corbeille' : 'Drain supprimé — instantané conservé';
            return `<tr><td><b>${esc(x.date_modification)}</b></td><td>${esc(code)}<br><small>${esc(nom)}</small></td><td>${actionBadge(x.action)}</td><td>${esc((x.utilisateur_nom||'Utilisateur supprimé').trim())}</td><td>${esc(x.role||'—')}</td><td>${details}</td></tr>`
        }).join('') || '<tr><td colspan="6">Aucune modification enregistrée.</td></tr>';
        stats.innerHTML = [
                ['Total', logs.length],
                ['Créations', logs.filter(x => x.action === 'CREATION').length],
                ['Modifications', logs.filter(x => x.action === 'MODIFICATION').length],
                ['Inspections', logs.filter(x => x.action === 'INSPECTION').length],
                ['Restaurations', logs.filter(x => x.action === 'RESTAURATION').length]
            ].map(x => `<div class="card kpi"><div class="label">${x[0]}</div><div class="value">${x[1]}</div></div>`)
            .join('')
    }
    async function load() {
        const r = await api('drain_history');
        if (r?.ok === false) {
            body.innerHTML =
                `<tr><td colspan="6">${esc(r.message||'Impossible de charger l’historique.')}</td></tr>`;
            return
        }
        logs = Array.isArray(r) ? r : [];
        render()
    }
    filterAction.addEventListener('change', render);
    guard(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']).then(load);
    startAutoRefresh(load, 2000);
    </script>
</body>

</html>