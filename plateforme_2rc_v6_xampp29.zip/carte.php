<?php session_start();
if (empty($_SESSION['user'])) {
    header('Location:login.php');
    exit;
} ?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Carte SIG</title>
    <link rel="stylesheet" href="assets/app.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css">
</head>

<body>
    <header class="top">
        <b><small></small></b><span><?= htmlspecialchars($_SESSION['user']['prenom'] . ' ' . $_SESSION['user']['nom']) ?>
            <button class="btn alt" onclick="logout()">Déconnexion</button></span>
    </header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Carte SIG</h1>
                    <?php if ($_SESSION['user']['role'] === 'CHEF_UNITE' && isset($_GET['pick']) && in_array($_GET['pick'], ['depart', 'arrivee'], true)): ?>
                    <div id="pickNotice"
                        style="margin-top:8px;padding:10px 14px;border-radius:10px;background:#fff3cd;border:1px solid #ffe69c;color:#664d03;font-weight:600;">
                        Cliquez sur la carte pour définir le point
                        <?= $_GET['pick'] === 'depart' ? 'de début' : 'de fin' ?> des travaux. Le point sera ensuite
                        recalé automatiquement sur le tracé du drain.</div>
                    <?php endif; ?>
                </div>
                <?php if (in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS'], true)): ?><button
                    class="btn gold" onclick="trace()">＋ Tracer un drain</button><?php endif; ?>
            </div>
            <div class="map-toolbar">
                <div class="map-views"><button class="map-view-btn active" data-view="SATELLITE"
                        onclick="setView('SATELLITE')">Satellite</button><button class="map-view-btn" data-view="OSM"
                        onclick="setView('OSM')">OpenStreetMap</button></div>
                <div class="legend" aria-label="Légende des états techniques"><b>État technique</b>
                    <div class="legend-row"><span class="legend-dot" style="background:#39e75f"></span>Débit correct
                    </div>
                    <div class="legend-row"><span class="legend-dot" style="background:#ff9800"></span>Saturation
                        partielle</div>
                    <div class="legend-row"><span class="legend-dot" style="background:#e60000"></span>Saturation totale
                    </div>
                    <div class="legend-row"><span class="legend-dot" style="background:#22a35a"></span>Partie exécutée /
                        sautée</div>
                    <div class="legend-row"><span class="legend-dot" style="background:#f26b21"></span>Partie restante
                    </div>
                </div>
            </div>
            <div class="map-shell">
                <div id="map"></div>
                <div id="mapLoading" class="map-loading">
                    <div class="map-loading-box"><b>Chargement de la carte SIG…</b>
                        <div class="map-loading-bar"><span id="mapLoadingBar"></span></div><small
                            id="mapLoadingText">Préparation — 10 s</small>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js"></script>
    <script src="assets/app.js"></script>
    <script src="assets/map.js"></script>
    <script>
    function setView(v) {
        if (window.setMapView) window.setMapView(v)
    }

    function startMapLoader() {
        const picker = pickerMode;
        let t = 0,
            bar = document.getElementById('mapLoadingBar'),
            txt = document.getElementById('mapLoadingText'),
            ov = document.getElementById('mapLoading');
        if (picker) {
            // En mode « Choisir sur la carte », le délai d'introduction est désactivé.
            ov.classList.add('hide');
            return;
        }

        const focusDrain = new URLSearchParams(window.location.search).has('drain_id');
        const duration = focusDrain ? 3000 : 10000;
        txt.textContent = 'Préparation — ' + (duration / 1000) + ' s';

        let timer = setInterval(() => {
            t += 100;
            let p = Math.min(100, Math.round((t / duration) * 100));
            bar.style.width = p + '%';
            txt.textContent = p < 100
                ? 'Chargement de la carte — ' + Math.ceil((duration - t) / 1000) + ' s'
                : 'Carte prête';
            if (t >= duration) {
                clearInterval(timer);
                setTimeout(() => ov.classList.add('hide'), 250);
            }
        }, 100);
    }
    const pickerMode =
        <?= json_encode($_SESSION['user']['role'] === 'CHEF_UNITE' && isset($_GET['pick']) && in_array($_GET['pick'], ['depart', 'arrivee'], true)) ?>;
    const pickerKind = <?= json_encode($_GET['pick'] ?? '') ?>;
    const pickerInterventionId = <?= (int) ($_GET['intervention_id'] ?? 0) ?>;
    let pickerMarker = null,
        pickerTarget = null;

    function setupCoordinatePicker(mapData) {
        if (!pickerMode || !window.map) return;
        const drains = Array.isArray(mapData.drains) ? mapData.drains : [];
        const interventions = Array.isArray(mapData.interventions) ? mapData.interventions : [];
        const selectedIntervention = interventions.find(i => Number(i.id) === pickerInterventionId);
        pickerTarget = selectedIntervention ? drains.find(d => Number(d.id) === Number(selectedIntervention.drain_id)) :
            null;
        if (pickerTarget) {
            const gj = parseGeo(pickerTarget.geom_json);
            if (gj) {
                try {
                    const layer = L.geoJSON(gj, {
                        style: {
                            color: '#ffe000',
                            weight: 12,
                            opacity: .35,
                            interactive: false
                        }
                    }).addTo(map);
                    map.fitBounds(layer.getBounds().pad(.18));
                } catch (e) {}
            }
        }
        map.getContainer().style.cursor = 'crosshair';
        map.on('click', function(ev) {
            if (pickerMarker) map.removeLayer(pickerMarker);
            pickerMarker = L.marker(ev.latlng, {
                draggable: false
            }).addTo(map).bindPopup('<b>Point sélectionné</b><br>' + ev.latlng.lat.toFixed(7) + ', ' + ev
                .latlng.lng.toFixed(7)).openPopup();
            const payload = {
                type: '2RC_MAP_COORDINATE',
                kind: pickerKind,
                intervention_id: pickerInterventionId,
                lat: ev.latlng.lat,
                lng: ev.latlng.lng
            };
            if (window.opener && !window.opener.closed) window.opener.postMessage(payload, window.location
                .origin);
            setTimeout(() => {
                if (window.opener && !window.opener.closed) window.close();
            }, 350);
        });
    }
    guard().then(async () => {
        try {
            let r = await api('map');
            if (!r || r.ok === false) {
                console.error(r);
                toast(r?.message || 'Impossible de charger les données SIG.', 'error');
                initMap({});
                startMapLoader();
                return;
            }
            initMap(r.settings || {});
            setView(r.settings?.provider === 'OSM' ? 'OSM' : 'SATELLITE');
            await loadMap(true);
            setupCoordinatePicker(r);
            setTimeout(() => map.invalidateSize(), 250);
            startMapLoader();
            if (!pickerMode) startAutoRefresh(() => loadMap(false), 30000);
        } catch (e) {
            console.error(e);
            toast('Erreur de chargement de la carte SIG. Vérifiez l’API et la base de données.', 'error');
            try {
                initMap({});
                startMapLoader()
            } catch (_) {}
        }
    });
    <?php if (in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS'], true)): ?>function trace() {
        drawLine((g, len) => {
            sessionStorage.setItem('newDrainGeom', JSON.stringify(g));
            sessionStorage.setItem('newDrainLength', len);
            location = 'drains.php?new=1'
        })
    }
    <?php endif; ?>
    </script>
</body>

</html>