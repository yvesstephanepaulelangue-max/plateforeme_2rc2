<?php session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'CHEF_UNITE') {
    header('Location:login.php');
    exit;
} ?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Espace Chef d’unité</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt"onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Espace Chef d’unité</h1>
                    <div class="sub">Constitution et suivi de votre unité d’intervention ou d’inspection.</div>
                </div>
            </div>
            <div id="msg" class="notice">Chargement…</div>
            <div class="grid three" style="margin-top:16px">
                <div class="card">
                    <div class="label">UNITÉ</div>
                    <div class="value" id="unitName">—</div>
                </div>
                <div class="card">
                    <div class="label">TYPE</div>
                    <div class="value" id="unitType">—</div>
                </div>
                <div class="card">
                    <div class="label">MEMBRES</div>
                    <div class="value" id="unitCount">0</div>
                </div>
            </div>
            
            <div class="card" style="margin-top:16px">
                <h2>Envoyer un rapport</h2>
                <p class="sub">Seul le Chef d’unité peut transmettre le rapport de son unité.</p>
                <form id="rf" class="form">
                    <div class="field"><label>Type</label><select name="type_rapport" id="rt">
                            <option value="ENTRETIEN">Entretien</option>
                            <option value="INSPECTION">Inspection</option>
                        </select></div>
                    <div class="field"><label>Intervention autorisée</label><select name="intervention_id" id="ri"
                            required></select></div>
                    <div class="field full"><label>Titre</label><input name="titre" required></div>
                    <div style="display: flex;">
                        <div class="field full">
                            <label>Coordonnées de debut</label>
                            <input type="text" name="coordonnees_depart" required>
                            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
                                <button type="button" id="getLocation" class="btn">Utiliser ma localisation</button>
                                <button type="button" id="pickStartMap" class="btn alt">Choisir sur la carte</button>
                            </div>
                        </div>
                        <div class="field full" style="margin-left: 10px;">
                            <label>Coordonnées de fin</label>
                            <input type="text" name="coordonnees_arrivee" required>
                            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
                                <button type="button" id="getDestinationLocation" class="btn">Utiliser ma localisation</button>
                                <button type="button" id="pickEndMap" class="btn alt">Choisir sur la carte</button>
                            </div>
                        </div>
                    </div>
                    <div class="field full">
                        <div> 
                            <label>Compte rendu</label>
                            <textarea name="report_commentaire" rows="6"required></textarea>
                        </div>
                    </div>

                    <div class="field">
                        <label>insérer un document</label>
                        <input type="file" name="rapport"accept="application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
                    </div>
                    <div class="field"><label>Images</label><input type="file" name="images[]" multiple
                            accept="image/jpeg,image/png,image/webp,image/gif"></div>
                    <div class="field full"><button class="btn">Envoyer le rapport</button></div>
                </form>
            </div>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>
        async function load() {
            const r = await api('units');
            if (!Array.isArray(r.units)) {
                document.getElementById('msg').textContent = r.message || 'Impossible de charger les unités.';
                return
            }
            const mine = r.units.find(x => Number(x.chef_unite_id) === Number(<?= (int) $_SESSION['user']['id'] ?>));
            if (!mine) {
                document.getElementById('msg').textContent =
                    'Aucune unité ne vous est encore attribuée. Utilisez « Constituer une unité ». ';
                return
            }
            document.getElementById('msg').textContent = 'Votre unité est active.';
            document.getElementById('unitName').textContent = mine.code + ' — ' + mine.nom;
            document.getElementById('unitType').textContent = mine.type_unite;
            document.getElementById('unitCount').textContent = mine.membres || 0
        }
        const rf = document.getElementById('rf'),
            ri = document.getElementById('ri'),
            rt = document.getElementById('rt');
        let allInterventions = [];
        async function loadReportsForm() {
            let x = await api('interventions');
            allInterventions = Array.isArray(x) ? x : [];
            renderReportOptions()
        }

        function renderReportOptions() {
            const previous = ri.value;
            const type = rt.value === 'INSPECTION' ? 'INSPECTION' : 'ENTRETIEN';
            const list = allInterventions.filter(i => Number(i.unite_id) === Number(window.__mineId) && Number(i
                .mission_autorisee) === 1 && ((type === 'INSPECTION' && i.type_intervention === 'INSPECTION') || (
                    type === 'ENTRETIEN' && i.type_intervention !== 'INSPECTION')));
            ri.innerHTML = list.map(i => `<option value="${i.id}">${esc(i.reference)} — ${esc(i.drain_nom)}</option>`).join(
                '') || '<option value="">Aucune intervention autorisée</option>';
            if (list.some(i => String(i.id) === String(previous))) ri.value = previous;
        }
        rt.onchange = renderReportOptions;
        function fillFromBrowserLocation(inputName, buttonId) {
            const input = document.querySelector(`[name="${inputName}"]`);
            const button = document.getElementById(buttonId);
            if (!navigator.geolocation) return toast('La géolocalisation n’est pas disponible sur ce navigateur.', 'error');
            button.disabled = true; const old = button.textContent; button.textContent = 'Localisation…';
            navigator.geolocation.getCurrentPosition(pos => {
                input.value = `${pos.coords.latitude.toFixed(7)}, ${pos.coords.longitude.toFixed(7)}`;
                input.dispatchEvent(new Event('input', {bubbles:true})); button.disabled = false; button.textContent = old;
                toast('Position récupérée. Elle sera automatiquement recalée sur le tracé du drain.', 'success');
            }, err => {
                button.disabled = false; button.textContent = old;
                toast(err.code === 1 ? 'Autorisation de localisation refusée.' : err.code === 2 ? 'Position indisponible.' : 'Délai de localisation dépassé.', 'error');
            }, {enableHighAccuracy:true, timeout:15000, maximumAge:0});
        }
        document.getElementById('getLocation').addEventListener('click', () => fillFromBrowserLocation('coordonnees_depart','getLocation'));
        document.getElementById('getDestinationLocation').addEventListener('click', () => fillFromBrowserLocation('coordonnees_arrivee','getDestinationLocation'));
        function openMapPicker(kind){
            if(!ri.value) return toast('Sélectionnez d’abord une intervention autorisée.', 'error');
            const w=window.open('carte.php?pick='+encodeURIComponent(kind)+'&intervention_id='+encodeURIComponent(ri.value),'coordPicker','width=1200,height=800,resizable=yes,scrollbars=yes');
            if(!w) toast('La fenêtre de sélection cartographique a été bloquée par le navigateur.', 'error');
        }
        document.getElementById('pickStartMap').addEventListener('click', () => openMapPicker('depart'));
        document.getElementById('pickEndMap').addEventListener('click', () => openMapPicker('arrivee'));
        window.addEventListener('message', e => {
            if(e.origin !== window.location.origin || !e.data || e.data.type !== '2RC_MAP_COORDINATE') return;
            const inputName=e.data.kind==='arrivee'?'coordonnees_arrivee':'coordonnees_depart';
            const input=document.querySelector('[name="'+inputName+'"]');
            if(input && Number(e.data.intervention_id)===Number(ri.value)){
                input.value=Number(e.data.lat).toFixed(7)+', '+Number(e.data.lng).toFixed(7);
                input.dispatchEvent(new Event('input',{bubbles:true}));
                toast((e.data.kind==='arrivee'?'Coordonnée de fin':'Coordonnée de début')+' récupérée depuis la carte.', 'success');
            }
        });
        rf.onsubmit = async e => {
            e.preventDefault();
            if (!ri.value) return toast('Aucune intervention autorisée.', 'error');
            let r = await api('submit_report', new FormData(rf), 'POST');
            toast(r.ok ? 'Rapport transmis.' : r.message, r.ok ? 'success' : 'error');
            if (r.ok) {
                rf.reset();
                renderReportOptions()
            }
        };
        async function start() {
            await load();
            const x = await api('units');
            if (Array.isArray(x.units)) {
                const mine = x.units.find(u => Number(u.chef_unite_id) === Number(<?= (int) $_SESSION['user']['id'] ?>));
                if (mine) {
                    window.__mineId = mine.id;
                    loadReportsForm()
                }
            }
        }
        guard('CHEF_UNITE').then(start);
        startAutoRefresh(async () => {
            if (window.__mineId) await loadReportsForm();
            else await load();
        }, 2000)
    </script>
</body>

</html>