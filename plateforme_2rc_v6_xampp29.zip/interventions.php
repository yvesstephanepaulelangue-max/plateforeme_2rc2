<?php session_start();
if (empty($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR','CHEF_UNITE'], true)) {
    header('Location:login.php');
    exit;
} ?><!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Interventions</title>
    <link rel="stylesheet" href="assets/app.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt"
            onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main style="width: 94.5%;">
             <style>
                .carousel {
                width: 100%;
                height: 200px;
                overflow: hidden;
                position: relative;
                margin-bottom: 20px;
                }

                .carousel-inner {
                display: flex;
                animation: slide 600s infinite linear;
                }

                .carousel-inner img {
                width: 100%;
                transition: transform 0.3s ease-in-out;
                }

                @keyframes slide {
                0% { transform: translateX(0); }
                25% { transform: translateX(-100%); }
                50% { transform: translateX(-200%); }
                75% { transform: translateX(-300%); }
                100% { transform: translateX(0); }
                }
                .imt{
                    height: 200px;
                    width: 350px;
                    border-radius: 20px;
                    margin-left: 10px;
                    margin-right: 10px;
                }
            </style>
            <div class="carousel">
                <div class="carousel-inner">
                    <img src="imt1.jpeg" alt="Image 1"class="imt" style="width:350px";>
                    <img src="imt2.jpeg" alt="Image 2"class="imt" style="width:350px";>
                    <img src="imt3.jpeg" alt="Image 3"class="imt" style="width:350px";>
                    <img src="imt4.jpeg" alt="Image 3"class="imt" style="width:350px";>
                    <img src="imt5.jpeg" alt="Image 3"class="imt" style="width:350px";>
                    <img src="imt6.jpeg" alt="Image 3"class="imt" style="width:350px";>
                    <img src="imt7.jpeg" alt="Image 3"class="imt" style="width:350px";>
                    <img src="imt8.jpeg" alt="Image 3"class="imt" style="width:350px";>
                </div>
            </div>
            <div class="head">
                <div>
                    <h1>Interventions</h1>
                </div><?php if(in_array($_SESSION['user']['role'], ['ADMIN','SOUS_DIRECTEUR_OPERATIONS','DIRECTEUR'], true)): ?><button class="btn" onclick="openM()">＋ Nouvelle intervention</button><?php endif; ?>
            </div>
            <div class="notice"><b>Validation obligatoire :</b> une intervention est AUTORISÉE uniquement lorsque les 3 visas sont accordés : <b>Chef service + SDO + Directeur</b>.</div>
            <div class="table">
                <table id="t">
                    <thead>
                        <tr>
                            <th>Référence</th>
                            <th>Type</th>
                            <th>Drain</th>
                            <th>Planification</th>
                            <th>Unité affectée</th>
                            <th>Matériel</th>
                            <th>Visa / autorisation</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            <div id="modal" class="modal">
                <div class="card modalbox wide">
                    <div class="head">
                        <h2>Nouvelle intervention</h2><button class="btn alt" onclick="closeM()">Fermer</button>
                    </div>
                    <form id="f" class="form" enctype="multipart/form-data">
                        <div class="field"><label>Drain</label><select name="drain_id" id="dr" required></select></div>
                        <div class="field"><label>Type d’intervention</label><select name="type_intervention" id="typ">
                                <option>CURAGE</option>
                                <option>REPARATION</option>
                                <option>NETTOYAGE</option>
                                <option>INSPECTION</option>
                            </select></div>
                        <div class="field"><label>Date prévue</label><input name="date_prevue" type="datetime-local"></div><div class="field"><label>Date de début</label><input name="date_debut" type="datetime-local"></div><div class="field"><label>Fin prévue</label><input name="date_fin_prevue" type="datetime-local"></div><div class="field full"><label>Unité disponible</label><select name="unite_id" id="unit"
                                required></select><small id="unitInfo" class="sub">Le choix des unités dépend du type
                                d’intervention et des unités créées dans les paramètres.</small></div>
                        <div class="field full">
                            <div class="notice"><b>Affectation :</b> toute l’unité sélectionnée est affectée à
                                l’intervention. Les agents ne sont pas choisis individuellement.</div>
                        </div>
                        <div class="field full"><label>Matériels utilisables</label>
                            <div id="materials" class="grid two"></div>
                        </div>
                        <div class="field full"><label>Tracé de l’intervention</label><button type="button"
                                class="btn alt" onclick="trace()">Tracer sur la carte</button> <span id="traceInfo"
                                class="sub"></span><input type="hidden" name="geom_json" id="geom"><input type="hidden" name="materials" id="materialsJson"></div>
                        <div class="field full"><label>Description</label><textarea name="description"
                                rows="4"></textarea></div>
                        <div class="field"><label>Images (3 max)</label><input name="images[]" id="imgs" type="file"
                                accept="image/jpeg,image/png,image/webp,image/gif" multiple></div>
                        <div class="field"><label>Vidéo (1 max)</label><input name="video" type="file"
                                accept="video/mp4,video/webm,video/quicktime"></div>
                        <div class="field full"><button class="btn">Créer l’intervention</button></div>
                    </form>
                </div>
            </div>
            <div id="traceModal" class="modal">
                <div class="card modalbox">
                    <div class="head">
                        <h2>Tracer l’intervention</h2><button class="btn alt" onclick="closeTrace()">Fermer</button>
                    </div>
                    <div id="traceMap"></div>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js"></script>
    <script>const modalEl = document.getElementById('modal'), formEl = document.getElementById('f'), tableEl = document.getElementById('t'), drainEl = document.getElementById('dr'), typeEl = document.getElementById('typ'), unitEl = document.getElementById('unit'), matEl = document.getElementById('materials'), geomEl = document.getElementById('geom'), traceModalEl = document.getElementById('traceModal'), traceInfoEl = document.getElementById('traceInfo'); let traceMap; function openM() { modalEl.classList.add('show'); loadForm() } function closeM() { modalEl.classList.remove('show') } async function loadForm() { let ds = await api('drains'); if (!Array.isArray(ds)) return toast(ds.message, 'error'); drainEl.innerHTML = ds.map(d => `<option value="${d.id}">${esc(d.code)} — ${esc(d.nom)} (${d.priorite})</option>`).join(''); await loadUnits(); let ms = await api('materials'); matEl.innerHTML = Array.isArray(ms) ? ms.map(x => `<label class="card"><input type="checkbox" class="mat" value="${x.id}"> <b>${esc(x.designation)}</b><br><small>${esc(x.categorie)} · stock ${x.stock_disponible} ${esc(x.unite)}</small><input class="qty" data-stock="${x.id}" type="number" min="1" step="1" value="1" inputmode="numeric" disabled></label>`).join('') : 'Aucun matériel'; matEl.querySelectorAll('.mat').forEach(c => c.onchange = () => { let q = matEl.querySelector(`[data-stock="${c.value}"]`); q.disabled = !c.checked }) } async function loadUnits() { let type = typeEl.value === 'INSPECTION' ? 'INSPECTION' : 'ENTRETIEN'; let x = await api('units_for_intervention', { type }); if (!Array.isArray(x)) return; unitEl.innerHTML = x.map(u => `<option value="${u.id}">${esc(u.code)} — ${esc(u.nom)} (${u.disponibles || 0} disponible(s))</option>`).join(''); unitEl.disabled = !x.length; } typeEl.onchange = loadUnits; function trace() { traceModalEl.classList.add('show'); setTimeout(() => { if (traceMap) { traceMap.remove(); traceMap = null; } traceMap = L.map('traceMap').setView([4.05, 9.70], 12); L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: 'Esri' }).addTo(traceMap); let c = new L.Control.Draw({ draw: { polyline: { shapeOptions: { color: '#ff8a00', weight: 6 } }, polygon: false, rectangle: false, circle: false, marker: false, circlemarker: false }, edit: false }); traceMap.addControl(c); traceMap.once(L.Draw.Event.CREATED, e => { geomEl.value = JSON.stringify(e.layer.toGeoJSON()); traceInfoEl.textContent = 'Tracé enregistré'; traceMap.remove(); closeTrace() }) }, 80) } function closeTrace() { traceModalEl.classList.remove('show'); if (traceMap) { traceMap.remove(); traceMap = null; } } async function load() { let r = await api('interventions'); if (!Array.isArray(r)) { tableEl.querySelector('tbody').innerHTML = `<tr><td colspan="8"><div class="notice"><b>Impossible de charger les interventions.</b><br>${esc(r?.message || 'Erreur inconnue de l’API.')}</div></td></tr>`; return toast(r?.message || 'Impossible de charger les interventions.', 'error'); } tableEl.querySelector('tbody').innerHTML = r.map(i => { let m = (i.materials || []).map(x => esc(x.designation) + ' × ' + x.quantite + ' ' + esc(x.unite)).join('<br>') || '—'; let actions = '';<?php if ($_SESSION['user']['role'] === 'ADMIN'): ?>if (!i.visa_chef_service && !i.visa_directeur) actions += `<button class="btn" onclick="visa(${i.id},'CHEF_SERVICE')">Visa chef</button>`;<?php elseif ($_SESSION['user']['role'] === 'SOUS_DIRECTEUR_OPERATIONS'): ?>if (!i.visa_sous_directeur && !i.visa_directeur) actions += `<button class="btn" onclick="visa(${i.id},'SOUS_DIRECTEUR')">Visa SDO</button>`;<?php elseif ($_SESSION['user']['role'] === 'DIRECTEUR'): ?>if (!i.visa_directeur) actions += `<button class="btn" onclick="visa(${i.id},'DIRECTEUR')">Visa Directeur</button>`;<?php endif; ?>return `<tr class="${i.mission_autorisee ? 'intervention-authorized' : ''}"><td><b>${esc(i.reference)}</b><br><small>${esc(i.type_intervention)}</small></td><td>${esc(i.type_intervention)}</td><td>${esc(i.drain_nom)}<br><small>${esc(i.arrondissement)}</small></td><td>${esc(i.date_prevue || '—')}</td><td>${esc(i.unite_nom || i.equipe_nom || '—')}</td><td>${m}</td><td>${badge(i.mission_autorisee ? 'AUTORISÉE' : 'EN_ATTENTE')}<br><small>Chef: ${i.visa_chef_service ? '✓' : '—'} · SDO: ${i.visa_sous_directeur ? '✓' : '—'} · Directeur: ${i.visa_directeur ? '✓' : '—'}</small><br>${actions}</td></tr>` }).join('') || '<tr><td colspan="8">Aucune intervention.</td></tr>' } async function visa(id, v) { let r = await api('visa_intervention', { id, visa: v }, 'POST'); toast(r.ok ? (r.mission_autorisee ? 'Mission autorisée.' : 'Visa enregistré.') : r.message, r.ok ? 'success' : 'error'); if (r.ok) load() } formEl.onsubmit = async e => { e.preventDefault(); if (document.getElementById('imgs').files.length > 3) return toast('Maximum 3 images.', 'error'); let fd = new FormData(formEl); let materials = [...matEl.querySelectorAll('.mat:checked')].map(c => ({ id: +c.value, qty: +(matEl.querySelector(`[data-stock="${c.value}"]`)?.value || 0) })).filter(x => x.qty > 0); fd.set('materials', JSON.stringify(materials)); let r = await api('create_intervention', fd, 'POST'); if (r.ok) { toast(r.mission_autorisee ? 'Intervention créée et autorisée.' : 'Intervention créée, en attente des visas requis. Le visa du Directeur autorise immédiatement l’intervention.'); formEl.reset(); geomEl.value = ''; closeM(); load() } else toast(r.message, 'error') }; guard(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR','CHEF_UNITE']).then(load); startAutoRefresh(load, 2000)</script>
</body>

</html>