<?php
session_start();
require __DIR__ . '/api/db.php';
if (empty($_SESSION['user'])) {
    http_response_code(403);
    exit('Accès refusé');
}
$u = $_SESSION['user'];
$source = $_GET['source'] ?? '';
$id = (int) ($_GET['id'] ?? 0);
$row = null;
if ($source === 'rapport_file') {
    $q = $pdo->prepare('SELECT rf.*,r.auteur_id,r.intervention_id FROM rapport_fichier rf JOIN rapport r ON r.id=rf.rapport_id WHERE rf.id=?');
    $q->execute([$id]);
    $row = $q->fetch();
    if ($row) {
        $allowed = in_array($u['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true) || $row['auteur_id'] == $u['id'];
        if (!$allowed && $row['intervention_id']) {
            $q = $pdo->prepare('SELECT 1 FROM intervention_membre WHERE intervention_id=? AND utilisateur_id=?');
            $q->execute([$row['intervention_id'], $u['id']]);
            $allowed = (bool) $q->fetchColumn();
        }
        if (!$allowed) {
            http_response_code(403);
            exit('Accès refusé');
        }
    }
} elseif ($source === 'rapport') {
    $q = $pdo->prepare('SELECT rf.*,r.auteur_id,r.intervention_id FROM rapport_fichier rf JOIN rapport r ON r.id=rf.rapport_id WHERE rf.rapport_id=? ORDER BY rf.id');
    $q->execute([$id]);
    $row = $q->fetch();
    if ($row && !in_array($u['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true) && $row['auteur_id'] != $u['id']) {
        http_response_code(403);
        exit('Accès refusé');
    }
} elseif ($source === 'intervention') {
    $q = $pdo->prepare('SELECT im.*,i.cree_par FROM intervention_media im JOIN intervention i ON i.id=im.intervention_id WHERE im.intervention_id=? ORDER BY im.id');
    $q->execute([$id]);
    $row = $q->fetch();
    if ($row && !in_array($u['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true)) {
        $q = $pdo->prepare('SELECT 1 FROM intervention_membre WHERE intervention_id=? AND utilisateur_id=?');
        $q->execute([$id, $u['id']]);
        if (!$q->fetchColumn()) {
            http_response_code(403);
            exit('Accès refusé');
        }
    }
}
if (!$row) {
    http_response_code(404);
    exit('Fichier introuvable');
}
$path = __DIR__ . '/' . $row['chemin'];
if (!is_file($path)) {
    http_response_code(404);
    exit('Fichier absent du serveur');
}
$name = str_replace(["\r", "\n", '"'], ['_', '_', '_'], basename($row['nom_fichier']));
header('X-Content-Type-Options: nosniff');
header('Content-Type: ' . ($row['mime_type'] ?: 'application/octet-stream'));
header('Content-Length: ' . filesize($path));
header('Content-Disposition: inline; filename="' . $name . '"');
readfile($path);
