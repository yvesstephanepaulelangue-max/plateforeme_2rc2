<?php
session_start();
if (empty($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS','DIRECTEUR'], true)) {
    header('Location:login.php');
    exit;
}
?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Accréditations</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b> <small></small></b><button class="btn alt"
            onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Accréditation des utilisateurs</h1>
                    <div class="sub">Les demandes d'inscription arrivent ici. Le chef de service attribue le poste, les
                        droits et active le compte.</div>
                </div>
            </div>
            <div class="grid kpis" style="margin-bottom:16px">
                <div class="card kpi">
                    <div class="label">DEMANDES EN ATTENTE</div>
                    <div class="value" id="pendingKpi">0</div>
                    <div class="sub">comptes à examiner</div>
                </div>
                <div class="card kpi">
                    <div class="label">COMPTES ACTIFS</div>
                    <div class="value" id="activeKpi">0</div>
                    <div class="sub">accès autorisés</div>
                </div>
            </div>
            <div class="card" style="margin-bottom:16px">
                <div class="form">
                    <div class="field"><label>Rechercher par nom</label><input id="searchName"
                            placeholder="Nom ou prénom…"></div>
                    <div class="field"><label>Filtrer par statut</label><select id="statusFilter">
                            <option value="">Tous les statuts</option>
                            <option value="ACTIF">Actif</option>
                            <option value="INACTIF">Inactif</option>
                            <option value="SUPPRIME">Supprimé</option>
                        </select></div>
                    <div class="field"><label>Filtrer par rôle</label><select id="roleFilter">
                            <option value="">Tous les rôles</option>
                            <option value="AGENT">Agent</option>
                            <option value="INSPECTEUR">Inspecteur</option>
                            <option value="ADMIN">Chef service / Admin</option>
                            <option value="SOUS_DIRECTEUR_OPERATIONS">Sous-directeur des opérations</option>
                            <option value="DIRECTEUR">Directeur</option>
                            <option value="CHEF_UNITE">Chef d’unité</option>
                            <option value="HSE">HSE</option>
                        </select></div>
                </div>
            </div>
            <div id="pageMsg" class="notice" style="margin-bottom:16px">Chargement des demandes…</div>
            <div class="table">
                <table id="usersTable">
                    <thead>
                        <tr>
                            <th>Utilisateur</th>
                            <th>Poste</th>
                            <th>Rôle</th>
                            <th>Niveau</th>
                            <th>Statut</th>
                            <th>Disponibilité</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="usersBody">
                        <tr>
                            <td colspan="7">Chargement…</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div id="accreditationModal" class="modal">
                <div class="card modalbox">
                    <div class="head">
                        <h2>Modifier l’accréditation</h2><button class="btn alt" type="button"
                            id="closeModalBtn">Fermer</button>
                    </div>
                    <form id="accreditationForm" class="form">
                        <input type="hidden" name="id">
                        <div class="field"><label>Utilisateur</label><input id="selectedUser" disabled></div>
                        <div class="field"><label>Poste occupé</label><input name="poste" required></div>
                        <div class="field"><label>Droit / rôle</label><select name="role">
                                <option value="AGENT">Agent</option>
                                <option value="INSPECTEUR">Inspecteur</option>
                                <option value="ADMIN">Chef service / Admin</option>
                                <option value="SOUS_DIRECTEUR_OPERATIONS">Sous-directeur des opérations</option>
                                <option value="DIRECTEUR">Directeur</option>
                                <option value="CHEF_UNITE">Chef d’unité</option>
                                <option value="HSE">HSE</option>
                            </select></div>
                        <?php if($_SESSION['user']['role']==='DIRECTEUR'): ?><div class="field"><label>Niveau
                                d’accréditation</label><select name="niveau_accreditation">
                                <option value="NIVEAU_1">NIVEAU_1</option>
                                <option value="NIVEAU_2">NIVEAU_2</option>
                                <option value="NIVEAU_3">NIVEAU_3</option>
                                <option value="NIVEAU_4">NIVEAU_4</option>
                            </select></div><?php else: ?><input type="hidden" name="niveau_accreditation"
                            value="NIVEAU_1"><?php endif; ?>
                        <div class="field"><label>Statut du compte</label><select name="statut">
                                <option value="ACTIF">ACTIF — autoriser la connexion</option>
                                <option value="INACTIF">INACTIF — bloquer la connexion</option>
                            </select></div>
                        <div class="field"><label>Disponibilité</label><select name="disponibilite">
                                <option value="DISPONIBLE">DISPONIBLE</option>
                                <option value="OCCUPE">OCCUPE</option>
                                <option value="ABSENT">ABSENT</option>
                            </select></div>
                        <div class="field full"><button class="btn" type="submit">Enregistrer l’accréditation</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>
    const tableEl = document.getElementById('usersTable');
    const bodyEl = document.getElementById('usersBody');
    const modalEl = document.getElementById('accreditationModal');
    const formEl = document.getElementById('accreditationForm');
    const selectedUserEl = document.getElementById('selectedUser');
    const pageMsgEl = document.getElementById('pageMsg');
    const pendingEl = document.getElementById('pendingKpi');
    const activeEl = document.getElementById('activeKpi');
    let rows = [],
        filteredRows = [];

    function closeM() {
        modalEl.classList.remove('show');
    }

    function edit(id) {
        const u = rows.find(x => Number(x.id) === Number(id));
        if (!u) {
            toast('Utilisateur introuvable.', 'error');
            return;
        }
        ['id', 'poste', 'role', 'niveau_accreditation', 'statut', 'disponibilite'].forEach(k => {
            const el = formEl.elements[k];
            if (el) el.value = u[k] ?? '';
        });
        selectedUserEl.value = (u.prenom || '') + ' ' + (u.nom || '') + ' — ' + (u.email || '');
        modalEl.classList.add('show');
    }
    window.edit = edit;
    window.closeM = closeM;
    async function deleteUser(id) {
        const u = rows.find(x => Number(x.id) === Number(id));
        if (!u) return;
        if (!confirm(`Placer le compte de ${u.prenom||''} ${u.nom||''} dans la corbeille ?`)) return;
        const r = await api('delete_user', {
            id
        }, 'POST');
        toast(r.ok ? r.message : (r.message || 'Suppression impossible.'), r.ok ? 'success' : 'error');
        if (r.ok) await loadUsers();
    }
    window.deleteUser = deleteUser;

    function applyFilters() {
        const q = document.getElementById('searchName').value.trim().toLowerCase(),
            role = document.getElementById('roleFilter').value,
            status = document.getElementById('statusFilter').value;
        filteredRows = rows.filter(u => (!q || (`${u.prenom||''} ${u.nom||''}`).toLowerCase().includes(q)) && (!role ||
            u.role === role) && (!status || u.statut === status));
        bodyEl.innerHTML = filteredRows.length ? filteredRows.map(u => {
            const actions = u.statut === 'SUPPRIME' ? `<span class="badge SUPPRIME">CORBEILLE</span>` :
                `<button class="btn alt" type="button" data-edit-id="${Number(u.id)}">Accréditer</button><?php if($_SESSION['user']['role']!=='DIRECTEUR'): ?><button class="btn danger" type="button" data-delete-id="${Number(u.id)}">Supprimer</button><?php endif; ?>`;
            return `<tr><td><b>${esc(u.prenom)} ${esc(u.nom)}</b><br><small>${esc(u.email)}</small></td><td>${esc(u.poste||'—')}</td><td>${badge(u.role)}</td><td><?= $_SESSION['user']['role']==='DIRECTEUR' ? '${badge(u.niveau_accreditation)}' : '—' ?></td><td>${badge(u.statut)}</td><td>${badge(u.disponibilite)}</td><td style="display:flex;gap:6px;flex-wrap:wrap">${actions}</td></tr>`
        }).join('') : '<tr><td colspan="7">Aucun utilisateur correspondant aux filtres.</td></tr>';
        bodyEl.querySelectorAll('button[data-edit-id]').forEach(b => b.onclick = () => edit(b.dataset.editId));
        bodyEl.querySelectorAll('button[data-delete-id]').forEach(b => b.onclick = () => deleteUser(b.dataset.deleteId))
    }
    async function loadUsers() {
        pageMsgEl.textContent = 'Chargement des demandes…';
        const result = await api('users_manage');
        if (!Array.isArray(result)) {
            bodyEl.innerHTML = '<tr><td colspan="7">Impossible de charger les utilisateurs.</td></tr>';
            pageMsgEl.textContent = result?.message || 'Erreur de chargement.';
            return;
        }
        rows = result;
        const pending = rows.filter(x => x.statut === 'INACTIF').length;
        const active = rows.filter(x => x.statut === 'ACTIF').length;
        pendingEl.textContent = pending;
        activeEl.textContent = active;
        applyFilters();
        pageMsgEl.textContent = pending ? pending + ' demande(s) en attente d’accréditation.' :
            'Aucune demande en attente.';
    }
    document.getElementById('searchName').addEventListener('input', applyFilters);
    document.getElementById('roleFilter').addEventListener('change', applyFilters);
    document.getElementById('statusFilter').addEventListener('change', applyFilters);
    document.getElementById('closeModalBtn').addEventListener('click', closeM);
    modalEl.addEventListener('click', e => {
        if (e.target === modalEl) closeM();
    });
    formEl.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = formEl.querySelector('button[type=submit]');
        btn.disabled = true;
        try {
            const result = await api('update_user_accreditation', new FormData(formEl), 'POST');
            if (result.ok) {
                toast('Accréditation enregistrée.');
                closeM();
                await loadUsers();
            } else toast(result.message || 'Impossible d’enregistrer.', 'error');
        } finally {
            btn.disabled = false;
        }
    });
    guard(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']).then(user => {
        if (user) loadUsers();
    });
    </script>
</body>

</html>