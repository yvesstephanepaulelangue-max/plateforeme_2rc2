<?php
session_start();
if (isset($_SESSION['user'])) {
    header('Location: route.php');
    exit;
}
// L'écran d'introduction est volontairement indépendant de la vidéo.
// Après les 10 secondes d'animation, l'utilisateur est envoyé vers la connexion.
$_SESSION['intro_seen'] = true;
?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Introduction</title>
    <style>
    :root {
        --navy: #002f6e;
        --orange: #ff5119
    }

    * {
        box-sizing: border-box
    }

    html,
    body {
        width: 100%;
        height: 100%;
        margin: 0
    }

    body {
        overflow: hidden;
        background: #fff;
        color: var(--navy);
        font-family: Arial, Helvetica, sans-serif;
    }

    .intro-screen {
        position: relative;
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #fff;
    }

    .intro-stage {
        position: relative;
        width: min(760px, 92vw);
        height: min(620px, 82vh);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    .platform-logo {
        position: absolute;
        top: 50%;
        left: 50%;
        width: min(560px, 78vw);
        height: auto;
        transform: translate(-50%, -50%) scale(.94);
        opacity: 0;
        animation: platformIntro 10s cubic-bezier(.22, .61, .36, 1) forwards;
        transform-origin: center center;
        filter: drop-shadow(0 18px 38px rgba(0, 47, 110, .10));
        z-index: 2;
    }

    .partner-logos {
        position: absolute;
        top: calc(50% + 92px);
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 42px;
        width: min(430px, 72vw);
        opacity: 0;
        animation: partnersIntro 10s ease forwards;
        z-index: 1;
    }

    .partner-logos img {
        width: 150px;
        height: 92px;
        object-fit: contain;
        display: block;
    }

    .partner-logos img.logo-cud {
        width: 112px;
        height: 92px
    }

    .credit {
        position: absolute;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%);
        margin: 0;
        font-size: 10px;
        letter-spacing: .18em;
        text-transform: uppercase;
        color: #6b7f95;
        opacity: 0;
        animation: creditIntro 10s ease forwards;
    }

    @keyframes platformIntro {
        0% {
            opacity: 0;
            transform: translate(-50%, -50%) scale(.94)
        }

        8% {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1)
        }

        32% {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1)
        }

        43% {
            opacity: 1;
            transform: translate(-50%, calc(-50% - 58px)) scale(.80)
        }

        100% {
            opacity: 1;
            transform: translate(-50%, calc(-50% - 58px)) scale(.80)
        }
    }

    @keyframes partnersIntro {

        0%,
        40% {
            opacity: 0;
            transform: translate(-50%, 18px) scale(.96)
        }

        49% {
            opacity: 1;
            transform: translate(-50%, 0) scale(1)
        }

        100% {
            opacity: 1;
            transform: translate(-50%, 0) scale(1)
        }
    }

    @keyframes creditIntro {

        0%,
        48% {
            opacity: 0
        }

        55% {
            opacity: .8
        }

        100% {
            opacity: .8
        }
    }

    @media(max-width:560px) {
        .intro-stage {
            height: 560px
        }

        .platform-logo {
            width: 86vw
        }

        .partner-logos {
            top: calc(50% + 70px);
            gap: 18px
        }

        .partner-logos img {
            width: 125px;
            height: 76px
        }

        .partner-logos img.logo-cud {
            width: 90px;
            height: 76px
        }
    }

    @media(prefers-reduced-motion:reduce) {
        .platform-logo {
            animation: none;
            opacity: 1;
            transform: translate(-50%, calc(-50% - 58px)) scale(.8)
        }

        .partner-logos {
            animation: none;
            opacity: 1;
            transform: translateX(-50%)
        }

        .credit {
            animation: none;
            opacity: .8
        }
    }
    </style>
</head>

<body>
    <main class="intro-screen" aria-label="Introduction de la plateforme 2RC">
        <section class="intro-stage">
            <img class="platform-logo" src="assets/logo-plateforme.svg" alt="Logo de la plateforme décisionnelle 2RC">
            <div class="partner-logos" aria-label="Logos partenaires">
                <img src="assets/logo2RC.svg" alt="Logo 2RC">
                <img class="logo-cud" src="assets/logo-CUD.svg" alt="Logo Communauté Urbaine de Douala">
            </div>
            <p class="credit">Assainissement · SIG · Pilotage</p>
        </section>
    </main>
    <script>
    (function() {
        const DURATION = 10000;
        window.setTimeout(function() {
            window.location.replace('login.php?intro=1');
        }, DURATION);
    })();
    </script>
</body>

</html>