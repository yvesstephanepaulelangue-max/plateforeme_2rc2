<?php
session_start();
if (empty($_SESSION['user'])) {
    header('Location:login.php');
    exit;
}
$__ur = $_SESSION['user']['role'] ?? '';
$__ul = (int) str_replace('NIVEAU_', '', $_SESSION['user']['niveau_accreditation'] ?? '1');
if (!in_array($__ur, ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'CHEF_UNITE'], true) && !in_array($__ur, ['AGENT', 'INSPECTEUR'], true) || (in_array($__ur, ['AGENT', 'INSPECTEUR'], true) && $__ul < 3)) {
    header('Location:login.php');
    exit;
}
?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Unités</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt" onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Unités</h1>
                    <div class="sub">Les responsables administratifs consultent les unités. Seul le Chef d’unité peut
                        créer et constituer une unité.</div>
                </div><?php if ($__ur === 'CHEF_UNITE'): ?><button class="btn" id="newBtn">＋ Constituer mon
                        unité</button><?php endif; ?>
            </div>
            <div id="msg" class="notice" style="margin-bottom:16px">Chargement…</div>
            <div id="units" class="grid two"></div>

            <div class="card" style="margin-top:16px">
                <div class="head">
                    <div>
                        <h2>Membres de l'unité</h2>
                    </div>
                </div>
                <div class="field"><label>Unité</label><select id="unitSelect"></select></div>
                <div id="members" class="grid two" style="margin-top:12px">

                </div>
                <?php if ($__ur === 'CHEF_UNITE'): ?>
                    <button class="btn" id="saveMembers" style="margin-top:12px">Enregistrer les
                        membres</button><?php endif; ?>
            </div>
        </main>
    </div>

    <div id="um" class="modal">
        <div class="card modalbox">
            <div class="head">
                <h2 id="modalTitle">Nouvelle unité</h2><button type="button" class="btn alt"
                    id="closeBtn">Fermer</button>
            </div>
            <form id="uf" class="form"><input type="hidden" name="id">
                <div class="field"><label>Code unique</label><input name="code" required placeholder="SWAT01"></div>
                <div class="field"><label>Nom de l’unité</label><input name="nom" required placeholder="SWAT 01"></div>
                <div class="field"><label>Type</label><select name="type_unite">
                        <option value="ENTRETIEN">ENTRETIEN</option>
                        <option value="INSPECTION">INSPECTION</option>
                    </select></div>
                <div class="field full"><label>Description</label><textarea name="description"></textarea></div>
                <div class="field full"><button class="btn" id="submitUnit">Créer l’unité</button></div>
            </form>
        </div>
    </div>
    <script src="assets/app.js"></script>
    <script>
        let data = {units: [], workers: [], memberships: []}, selectedUnit = 0;
        const unitsEl = document.getElementById('units'), selectEl = document.getElementById('unitSelect'), membersEl = document.getElementById('members'), msgEl = document.getElementById('msg'), modal = document.getElementById('um'), form = document.getElementById('uf');
        const escH = window.esc || ((v) => String(v ?? '').replace(/[&<>"']/g, m => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'}[m])));
        function closeUnit() {modal.classList.remove('show')} function openNew() {form.reset(); form.elements.id.value = ''; document.getElementById('modalTitle').textContent = 'Nouvelle unité'; document.getElementById('submitUnit').textContent = 'Créer l’unité'; modal.classList.add('show')}
        function openEdit(id) {const u = data.units.find(x => +x.id === +id); if (!u) return; form.elements.id.value = u.id; form.elements.code.value = u.code || ''; form.elements.nom.value = u.nom || ''; form.elements.type_unite.value = u.type_unite || 'ENTRETIEN'; form.elements.description.value = u.description || ''; document.getElementById('modalTitle').textContent = 'Modifier l’unité'; document.getElementById('submitUnit').textContent = 'Enregistrer les modifications'; modal.classList.add('show')}
        function render() {
            unitsEl.innerHTML = data.units.length ? data.units.map(u => `<div class="card"><div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start"><div><b>${escH(u.code)} — ${escH(u.nom)}</b><br><small>${escH(u.type_unite)} · ${Number(u.membres || 0)} membre(s) · Chef : ${escH(u.chef_nom || '—')}</small><p class="sub" style="margin:8px 0 0">${escH(u.description || '')}</p></div><div style="display:flex;gap:6px;flex-wrap:wrap">${<?= json_encode($__ur === 'CHEF_UNITE') ?> && Number(u.chef_unite_id) === <?= (int) ($_SESSION['user']['id'] ?? 0) ?> ? `<button class="btn alt" data-edit="${u.id}">Modifier</button><button class="btn danger" data-delete="${u.id}">Supprimer</button>` : ""}</div></div></div>`).join('') : '<div class="notice">Aucune unité active.</div>';
            selectEl.innerHTML = data.units.map(u => `<option value="${u.id}">${escH(u.code)} — ${escH(u.nom)}</option>`).join(''); if (!data.units.some(u => +u.id === +selectedUnit)) selectedUnit = data.units[0]?.id || 0; selectEl.value = selectedUnit || ''; renderMembers();
            unitsEl.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => openEdit(b.dataset.edit)); unitsEl.querySelectorAll('[data-delete]').forEach(b => b.onclick = () => deleteUnit(b.dataset.delete));
        }
        function renderMembers() {const uid = +selectEl.value; const ids = data.memberships.filter(m => +m.unite_id === uid).map(m => +m.utilisateur_id); membersEl.innerHTML = data.workers.length ? data.workers.map(w => `<label class="card"><input type="checkbox" <?= $__ur === 'CHEF_UNITE' ? "" : "disabled" ?> value="${w.id}" ${ids.includes(+w.id) ? 'checked' : ''}> <b>${escH(w.prenom)} ${escH(w.nom)}</b><br><small>${escH(w.matricule || '—')} · ${escH(w.role)} · ${escH(w.poste || '—')} · ${escH(w.disponibilite)}</small></label>`).join('') : '<div class="notice">Aucun agent ou inspecteur actif.</div>'}
        async function load() {const r = await api('units'); if (!r || r.ok === false || !Array.isArray(r.units)) {msgEl.textContent = r?.message || 'Impossible de charger les unités.'; return } data = r; render(); msgEl.textContent = `${data.units.length} unité(s) active(s).`}
        async function deleteUnit(id) {const u = data.units.find(x => +x.id === +id); if (!u) return; if (!confirm(`Archiver l’unité « ${u.nom} » ? Les données historiques seront conservées.`)) return; const r = await api('delete_unit', {id}, 'POST'); toast(r.ok ? 'Unité archivée.' : r.message, r.ok ? 'success' : 'error'); if (r.ok) {selectedUnit = 0; await load()} }
        form.onsubmit = async e => {e.preventDefault(); const id = form.elements.id.value; const action = id ? 'update_unit' : 'create_unit'; const r = await api(action, new FormData(form), 'POST'); if (r.ok) {toast(id ? 'Unité modifiée.' : 'Unité créée.'); closeUnit(); selectedUnit = r.id || id || 0; await load()} else toast(r.message || 'Opération impossible.', 'error')};
        const saveMembersBtn = document.getElementById('saveMembers'); if (saveMembersBtn) saveMembersBtn.onclick = async () => {if (!selectEl.value) {toast('Sélectionnez une unité.', 'error'); return } const members = [...membersEl.querySelectorAll('input:checked')].map(x => +x.value); const r = await api('set_unit_members', {unite_id: selectEl.value, members: JSON.stringify(members)}, 'POST'); toast(r.ok ? 'Membres de l’unité enregistrés.' : r.message, r.ok ? 'success' : 'error'); if (r.ok) load()}; selectEl.onchange = () => {selectedUnit = +selectEl.value; renderMembers()}; const newBtn = document.getElementById('newBtn'); if (newBtn) newBtn.onclick = openNew; const closeBtn = document.getElementById('closeBtn'); if (closeBtn) closeBtn.onclick = closeUnit; modal.onclick = e => {if (e.target === modal) closeUnit()}; guard(<?= json_encode($__ur) ?>).then(load); startAutoRefresh(load, 2000);
    </script>
</body>

</html>