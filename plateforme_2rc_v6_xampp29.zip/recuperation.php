<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Récupération du mot de passe</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <main style="max-width:620px;margin:60px auto;padding:20px">
        <div class="card">
            <h1>Récupérer le mot de passe</h1>
            <p class="sub">Entrez votre email puis répondez à votre question clé.</p>
            <form id="f" class="form">
                <div class="field full"><label>Email</label><input id="email" name="email" type="email" required></div>
                <div class="field full"><button class="btn" type="button" id="getQ">Afficher ma question</button></div>
                <div id="questionBox" class="notice hidden"></div>
                <div class="field full hidden" id="answerBox"><label>Réponse</label><input name="reponse"
                        type="password"></div>
                <div class="field full hidden" id="newBox"><label>Nouveau mot de passe</label><input
                        name="nouveau_mot_de_passe" type="password" minlength="8"></div>
                <div class="field full hidden" id="submitBox"><button class="btn">Réinitialiser</button></div>
            </form>
            <div id="msg" class="notice" style="margin-top:12px"></div>
            <p><a href="login.php">Retour à la connexion</a></p>
        </div>
    </main>
    <script src="assets/app.js"></script>
    <script>
    const f = document.getElementById('f'),
        email = document.getElementById('email'),
        qbox = document.getElementById('questionBox');
    document.getElementById('getQ').onclick = async () => {
        const r = await api('recovery_question', {
            email: email.value
        });
        if (r.ok) {
            qbox.textContent = r.question;
            qbox.classList.remove('hidden');
            ['answerBox', 'newBox', 'submitBox'].forEach(id => document.getElementById(id).classList.remove(
                'hidden'));
        } else document.getElementById('msg').textContent = r.message || 'Impossible de récupérer la question.'
    };
    f.onsubmit = async e => {
        e.preventDefault();
        const r = await api('recover_password', new FormData(f), 'POST');
        document.getElementById('msg').textContent = r.message || '';
        if (r.ok) setTimeout(() => location = 'login.php', 1200)
    }
    </script>
</body>

</html>