# 2RC V22 — correction Accréditations et Unités

Cette version corrige deux problèmes signalés :

1. **Accréditations :** la page peut afficher « Erreur serveur » lorsque la base existante n'a pas encore les colonnes V21. La migration `migration_v22.sql` complète la structure **sans DROP TABLE et sans suppression de données**.
2. **Unités :** la page permet maintenant directement de modifier le code/nom/description, gérer les membres et archiver une unité. La page Paramètres ne gère plus les unités.

## Base existante

1. Faire une sauvegarde SQL dans phpMyAdmin.
2. Sélectionner la base `plateforme_2rc`.
3. Importer/exécuter `migration_v22.sql`.
4. Ne pas exécuter `schema.sql` ni `seed.sql` sur une base qui contient déjà des données.
5. Remplacer les fichiers du projet par ceux de cette archive.

La migration ne contient aucun `DROP TABLE` ni `DELETE`.
