-- V32 NON DESTRUCTIF
ALTER TABLE unite ADD COLUMN chef_unite_id INT NULL AFTER description;
ALTER TABLE intervention MODIFY mission_autorisee TINYINT(1) GENERATED ALWAYS AS (CASE WHEN visa_directeur=1 OR (visa_chef_service=1 AND visa_sous_directeur=1) THEN 1 ELSE 0 END) STORED;
CREATE TABLE IF NOT EXISTS recuperation_mot_de_passe(id BIGINT AUTO_INCREMENT PRIMARY KEY,utilisateur_id INT NOT NULL,question VARCHAR(255) NOT NULL,reponse_hash VARCHAR(255) NOT NULL,date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,date_modification DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE KEY uq_recup_user(utilisateur_id),FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS recuperation_tentative(id BIGINT AUTO_INCREMENT PRIMARY KEY,identifiant VARCHAR(160) NOT NULL,ip_hash CHAR(64) NULL,date_tentative DATETIME DEFAULT CURRENT_TIMESTAMP,succes TINYINT(1) DEFAULT 0,INDEX idx_recup_try(identifiant,date_tentative));
