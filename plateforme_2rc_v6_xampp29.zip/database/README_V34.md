# V34 — Tronçons exécutés et linéaire sauté

Cette version corrige l'affichage cartographique des travaux exécutés.

- Chaque rapport d'entretien géolocalisé enregistre un intervalle sur le tracé réel du drain.
- Les intervalles exécutés sont fusionnés lorsqu'ils se chevauchent.
- Les espaces situés entre deux intervalles exécutés sont automatiquement considérés comme **linéaire sauté**.
- Exemple : A→B exécuté, puis C→D exécuté : B→C est affiché en gris et comptabilisé comme linéaire sauté.
- Les portions avant le premier tronçon exécuté et après le dernier restent en orange comme linéaire restant.
- Aucun changement de structure de base de données n'est nécessaire : la table `intervention_travail_segment` de V33 est réutilisée.
