2RC V20 - MIGRATION SANS PERTE

IMPORTANT
La plateforme ne doit plus utiliser schema.sql comme script de reinstallation destructive sur une base qui contient des données.

schema.sql V20 est désormais NON DESTRUCTIF : il ne contient plus de DROP TABLE.

Pour une base existante :
1. Sélectionner la base plateforme_2rc dans phpMyAdmin.
2. Importer/exécuter database/migration_sans_perte_v20.sql.
3. NE PAS exécuter seed.sql sur une base existante si l'objectif est de conserver les données et d'éviter les doublons.

La migration :
- conserve les drains, utilisateurs, interventions, inspections, rapports, unités, stocks, véhicules, etc. ;
- convertit OUVRIER vers AGENT ;
- crée agent_unite si nécessaire et copie les anciens rattachements ;
- ajoute les colonnes nécessaires aux drains ;
- convertit les anciens états techniques ;
- crée/actualise le journal des drains ;
- ajoute RESTAURATION au journal ;
- ne contient aucun DROP TABLE et aucun DELETE de données.

Pour une nouvelle installation vide, schema.sql puis seed.sql restent utilisables.
