# V31 — corrections accès Directeur et interventions

- Directeur : accès Accréditations, Unités et Paramètres.
- Directeur : chargement des unités et matériels dans la création d’intervention.
- Visa Directeur : autorisation immédiate (prioritaire).
- Une intervention autorisée est affichée en vert dans la page Interventions.
- Aucun DROP/DELETE de données n’est nécessaire pour ces corrections.
