-- V33 NON DESTRUCTIF : recalage des positions approximatives du Chef d’unité sur le tracé du drain.
CREATE TABLE IF NOT EXISTS intervention_travail_segment(
 id BIGINT AUTO_INCREMENT PRIMARY KEY, intervention_id INT NOT NULL, drain_id INT NOT NULL,
 coord_depart_approx_lat DECIMAL(10,7) NOT NULL, coord_depart_approx_lng DECIMAL(10,7) NOT NULL,
 coord_arrivee_approx_lat DECIMAL(10,7) NOT NULL, coord_arrivee_approx_lng DECIMAL(10,7) NOT NULL,
 point_depart_lat DECIMAL(10,7) NOT NULL, point_depart_lng DECIMAL(10,7) NOT NULL,
 point_arrivee_lat DECIMAL(10,7) NOT NULL, point_arrivee_lng DECIMAL(10,7) NOT NULL,
 distance_depart_m DECIMAL(12,2) NOT NULL DEFAULT 0, distance_arrivee_m DECIMAL(12,2) NOT NULL DEFAULT 0,
 longueur_executee_m DECIMAL(12,2) NOT NULL DEFAULT 0, mis_a_jour_par INT NULL,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_its_intervention_interval(intervention_id,distance_depart_m,distance_arrivee_m), INDEX idx_its_drain_distance(drain_id,distance_depart_m,distance_arrivee_m),
 FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE CASCADE,
 FOREIGN KEY(drain_id) REFERENCES drain(id) ON DELETE CASCADE,
 FOREIGN KEY(mis_a_jour_par) REFERENCES utilisateur(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
