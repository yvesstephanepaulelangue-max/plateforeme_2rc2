-- 2RC — Migration : rendre les dates d'intervention optionnelles
-- A exécuter sur une base existante.
ALTER TABLE intervention MODIFY COLUMN date_prevue DATETIME NULL;
-- date_debut et date_fin_prevue sont déjà NULL dans les versions corrigées.
ALTER TABLE intervention MODIFY COLUMN date_debut DATETIME NULL;
ALTER TABLE intervention MODIFY COLUMN date_fin_prevue DATETIME NULL;
