-- ================================================================
-- 2RC V20 - MIGRATION SANS PERTE DE DONNEES
-- Cette migration ne contient aucun DROP TABLE ni DELETE de donnees.
-- Elle adapte une base existante aux versions recentes de la plateforme.
-- Base cible : if0_43096180_plateforme_2rc / MySQL ou MariaDB
-- ================================================================

USE if0_43096180_plateforme_2rc;

-- 1) ROLE : OUVRIER -> AGENT
-- On conserve temporairement les deux valeurs afin de pouvoir convertir les anciens comptes.
ALTER TABLE utilisateur
  MODIFY role ENUM('ADMIN','INSPECTEUR','OUVRIER','AGENT','DIRECTEUR','SOUS_DIRECTEUR_OPERATIONS') NOT NULL;

UPDATE utilisateur SET role='AGENT' WHERE role='OUVRIER';

ALTER TABLE utilisateur
  MODIFY role ENUM('ADMIN','INSPECTEUR','AGENT','DIRECTEUR','SOUS_DIRECTEUR_OPERATIONS') NOT NULL;

-- 2) TABLE DE RATTACHEMENT DES AGENTS
-- Création si elle manque, sans toucher à l'ancienne table ouvrier_unite.
CREATE TABLE IF NOT EXISTS agent_unite(
 id INT AUTO_INCREMENT PRIMARY KEY,
 utilisateur_id INT NOT NULL,
 unite_id INT NOT NULL,
 UNIQUE(utilisateur_id,unite_id),
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
 FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE CASCADE
);

-- Copie des anciens rattachements uniquement si ouvrier_unite existe.
SET @old_ou = (SELECT COUNT(*) FROM information_schema.tables
               WHERE table_schema=DATABASE() AND table_name='ouvrier_unite');
SET @copy_sql = IF(@old_ou > 0,
  'INSERT IGNORE INTO agent_unite(utilisateur_id,unite_id) SELECT utilisateur_id,unite_id FROM ouvrier_unite',
  'SELECT 1');
PREPARE stmt_copy FROM @copy_sql;
EXECUTE stmt_copy;
DEALLOCATE PREPARE stmt_copy;

-- 3) COLONNES NECESSAIRES AUX DRAINS
ALTER TABLE drain
  ADD COLUMN IF NOT EXISTS lineaire_saute_m DECIMAL(12,2) DEFAULT 0 AFTER lineaire_execute_m;

ALTER TABLE drain
  ADD COLUMN IF NOT EXISTS direction_travaux ENUM('A_VERS_B','B_VERS_A') DEFAULT 'A_VERS_B' AFTER lineaire_saute_m;

ALTER TABLE drain
  ADD COLUMN IF NOT EXISTS updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Etats techniques : conversion des anciens états sans perte.
ALTER TABLE drain
  MODIFY etat ENUM('BON','A_SURVEILLER','DEGRADE','CRITIQUE','DEBIT_CORRECT','SATURATION_PARTIELLE','SATURATION_TOTAL') DEFAULT 'DEBIT_CORRECT';

UPDATE drain SET etat='DEBIT_CORRECT' WHERE etat='BON';
UPDATE drain SET etat='SATURATION_PARTIELLE' WHERE etat IN('A_SURVEILLER','DEGRADE');
UPDATE drain SET etat='SATURATION_TOTAL' WHERE etat='CRITIQUE';

ALTER TABLE drain
  MODIFY etat ENUM('DEBIT_CORRECT','SATURATION_PARTIELLE','SATURATION_TOTAL') DEFAULT 'DEBIT_CORRECT';

-- Recalcul de la colonne dérivée du linéaire restant.
ALTER TABLE drain DROP COLUMN IF EXISTS lineaire_restant_m;
ALTER TABLE drain
  ADD COLUMN lineaire_restant_m DECIMAL(12,2)
  GENERATED ALWAYS AS (
    GREATEST(COALESCE(lineaire_m,0)-COALESCE(lineaire_execute_m,0)-COALESCE(lineaire_saute_m,0),0)
  ) STORED AFTER direction_travaux;

-- 4) JOURNAL DES MODIFICATIONS DES DRAINS
CREATE TABLE IF NOT EXISTS drain_modification_log(
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 drain_id INT NULL,
 action ENUM('CREATION','MODIFICATION','SUPPRESSION','INSPECTION','RESTAURATION') NOT NULL,
 utilisateur_id INT NULL,
 date_modification DATETIME DEFAULT CURRENT_TIMESTAMP,
 ancienne_valeur LONGTEXT NULL,
 nouvelle_valeur LONGTEXT NULL,
 commentaire VARCHAR(500) NULL,
 INDEX idx_dml_drain_date(drain_id,date_modification),
 INDEX idx_dml_date(date_modification),
 FOREIGN KEY(drain_id) REFERENCES drain(id) ON DELETE SET NULL,
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE SET NULL
);

-- Si le journal existait déjà avec l'ancien ENUM, on ajoute RESTAURATION sans supprimer ses lignes.
ALTER TABLE drain_modification_log
  MODIFY action ENUM('CREATION','MODIFICATION','SUPPRESSION','INSPECTION','RESTAURATION') NOT NULL;

-- 5) Postes / niveau d'accréditation si absents.
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS poste VARCHAR(160) AFTER role;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS niveau_accreditation ENUM('NIVEAU_1','NIVEAU_2','NIVEAU_3','NIVEAU_4') DEFAULT 'NIVEAU_1' AFTER poste;

-- 6) Message de fin : la migration est terminée sans suppression de données.
SELECT 'Migration V20 terminée : aucune table ni donnée existante n''a été supprimée.' AS resultat;


-- V21 NON DESTRUCTIVE
ALTER TABLE utilisateur MODIFY statut ENUM('ACTIF','INACTIF','SUPPRIME') DEFAULT 'ACTIF';
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS type_compte ENUM('AGENT_2RC','STAGIAIRE','TEMPORAIRE') DEFAULT 'AGENT_2RC' AFTER statut;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_demande TINYINT(1) DEFAULT 0 AFTER type_compte;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_demande_par INT NULL AFTER suppression_demande;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_demande_at DATETIME NULL AFTER suppression_demande_par;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_confirmee_par INT NULL AFTER suppression_demande_at;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_confirmee_at DATETIME NULL AFTER suppression_confirmee_par;
ALTER TABLE unite ADD COLUMN IF NOT EXISTS actif TINYINT(1) DEFAULT 1;
UPDATE utilisateur SET type_compte='AGENT_2RC' WHERE type_compte IS NULL OR type_compte='';
SELECT 'Migration V21 terminée : données existantes conservées.' AS resultat;
