-- Migration V30 : le visa du Directeur autorise immédiatement l’intervention.
-- Sans visa Directeur, les visas Chef de service + SDO ne suffisent pas.
ALTER TABLE intervention MODIFY mission_autorisee TINYINT(1) GENERATED ALWAYS AS (CASE WHEN visa_directeur=1 OR (visa_chef_service=1 AND visa_sous_directeur=1 AND visa_directeur=1) THEN 1 ELSE 0 END) STORED;
