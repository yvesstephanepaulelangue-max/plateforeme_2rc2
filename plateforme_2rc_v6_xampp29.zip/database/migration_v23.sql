-- 2RC V23 - MISE A NIVEAU SANS PERTE
-- Cette migration est conservée comme option manuelle.
-- La V23 applique désormais automatiquement les mêmes vérifications via api/db.php.
-- AUCUN DROP TABLE et AUCUN DELETE de données.
-- Base : if0_43096180_plateforme_2rc

USE if0_43096180_plateforme_2rc;

-- Rôles : conversion sécurisée des anciens OUVRIER vers AGENT.
ALTER TABLE utilisateur MODIFY role ENUM('ADMIN','INSPECTEUR','OUVRIER','AGENT','DIRECTEUR','SOUS_DIRECTEUR_OPERATIONS') NOT NULL;
UPDATE utilisateur SET role='AGENT' WHERE role='OUVRIER';
ALTER TABLE utilisateur MODIFY role ENUM('ADMIN','INSPECTEUR','AGENT','DIRECTEUR','SOUS_DIRECTEUR_OPERATIONS') NOT NULL;

ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS poste VARCHAR(160) NULL AFTER role;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS niveau_accreditation ENUM('NIVEAU_1','NIVEAU_2','NIVEAU_3','NIVEAU_4') DEFAULT 'NIVEAU_1' AFTER poste;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS type_compte ENUM('AGENT_2RC','STAGIAIRE','TEMPORAIRE') DEFAULT 'AGENT_2RC' AFTER statut;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_demande TINYINT(1) DEFAULT 0 AFTER type_compte;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_demande_par INT NULL AFTER suppression_demande;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_demande_at DATETIME NULL AFTER suppression_demande_par;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_confirmee_par INT NULL AFTER suppression_demande_at;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_confirmee_at DATETIME NULL AFTER suppression_confirmee_par;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS disponibilite ENUM('DISPONIBLE','OCCUPE','ABSENT') DEFAULT 'DISPONIBLE';
ALTER TABLE utilisateur MODIFY statut ENUM('ACTIF','INACTIF','SUPPRIME') DEFAULT 'ACTIF';
UPDATE utilisateur SET type_compte='AGENT_2RC' WHERE type_compte IS NULL OR type_compte='';
UPDATE utilisateur SET suppression_demande=0 WHERE suppression_demande IS NULL;

ALTER TABLE unite ADD COLUMN IF NOT EXISTS actif TINYINT(1) DEFAULT 1;
UPDATE unite SET actif=1 WHERE actif IS NULL;

CREATE TABLE IF NOT EXISTS agent_unite(
 id INT AUTO_INCREMENT PRIMARY KEY,
 utilisateur_id INT NOT NULL,
 unite_id INT NOT NULL,
 UNIQUE(utilisateur_id,unite_id),
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
 FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET @has_old_ou := (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='ouvrier_unite');
SET @sql_copy := IF(@has_old_ou>0,'INSERT IGNORE INTO agent_unite(utilisateur_id,unite_id) SELECT utilisateur_id,unite_id FROM ouvrier_unite','SELECT 1');
PREPARE s FROM @sql_copy; EXECUTE s; DEALLOCATE PREPARE s;

ALTER TABLE drain ADD COLUMN IF NOT EXISTS lineaire_saute_m DECIMAL(12,2) DEFAULT 0 AFTER lineaire_execute_m;
ALTER TABLE drain ADD COLUMN IF NOT EXISTS direction_travaux ENUM('A_VERS_B','B_VERS_A') DEFAULT 'A_VERS_B' AFTER lineaire_saute_m;
ALTER TABLE drain ADD COLUMN IF NOT EXISTS updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

CREATE TABLE IF NOT EXISTS drain_modification_log(
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 drain_id INT NULL,
 action ENUM('CREATION','MODIFICATION','SUPPRESSION','INSPECTION','RESTAURATION') NOT NULL,
 utilisateur_id INT NULL,
 date_modification DATETIME DEFAULT CURRENT_TIMESTAMP,
 ancienne_valeur LONGTEXT NULL,
 nouvelle_valeur LONGTEXT NULL,
 commentaire VARCHAR(500) NULL,
 INDEX idx_dml_drain_date(drain_id,date_modification),
 INDEX idx_dml_date(date_modification),
 FOREIGN KEY(drain_id) REFERENCES drain(id) ON DELETE SET NULL,
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE drain_modification_log MODIFY action ENUM('CREATION','MODIFICATION','SUPPRESSION','INSPECTION','RESTAURATION') NOT NULL;

SELECT 'V23 terminée : aucune table ni donnée existante supprimée.' AS resultat;
