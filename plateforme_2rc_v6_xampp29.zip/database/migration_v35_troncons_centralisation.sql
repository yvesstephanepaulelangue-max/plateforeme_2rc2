-- Migration V35 - centralisation des tronçons exécutés/sautés
-- Non destructive : les données existantes sont conservées.
-- La plateforme recalcule et persiste lineaire_execute_m et lineaire_saute_m
-- à partir de l'ensemble des intervention_travail_segment du drain.

-- Vérification de la table des tronçons (créée automatiquement par api/db.php si absente).
-- Aucun DROP/TRUNCATE/DELETE n'est exécuté ici.

-- Recalcul manuel facultatif après installation :
-- UPDATE drain d
-- SET lineaire_execute_m = (... union des intervalles ...),
--     lineaire_saute_m = (... gaps entre intervalles ...);
-- Le recalcul applicatif est exécuté à chaque enregistrement de rapport.

-- Pour une base déjà existante avec uq_its_intervention :
-- ALTER TABLE intervention_travail_segment DROP INDEX uq_its_intervention,
-- ADD UNIQUE KEY uq_its_intervention_interval(intervention_id,distance_depart_m,distance_arrivee_m);
-- api/db.php effectue automatiquement cette migration sans supprimer les lignes.
