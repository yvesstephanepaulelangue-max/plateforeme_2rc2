# V35 — Centralisation des tronçons et actualisation 2 secondes

## Modifications
- Les tronçons de travaux sont centralisés par `drain_id` dans `intervention_travail_segment`.
- Plusieurs tronçons distincts peuvent être enregistrés pour une même intervention grâce à une unicité `(intervention_id, distance_depart_m, distance_arrivee_m)`.
- `drain.lineaire_execute_m` est recalculé par union de tous les intervalles exécutés du drain.
- `drain.lineaire_saute_m` est recalculé à partir des espaces situés entre les intervalles exécutés.
- `drain.lineaire_restant_m` reste calculé par la colonne générée existante.
- La Carte SIG récupère tous les segments sans filtre par chef d’unité.
- Les segments exécutés sont verts et les segments sautés gris.
- Les couches de suivi sont redessinées toutes les 2 secondes sur les pages concernées sans recentrer la Carte SIG.
- L’actualisation est suspendue lorsque la page est masquée, qu’un champ de formulaire est actif ou qu’une fenêtre `.modal.show` est ouverte.

## Données existantes
Aucune suppression, TRUNCATE ou DROP de données métier n’est effectuée. `api/db.php` adapte automatiquement l’ancienne contrainte unique si elle existe.
