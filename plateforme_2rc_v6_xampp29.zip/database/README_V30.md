# V30 — Règle des visas

- Chef de service seul : non autorisée.
- Chef de service + SDO, sans Directeur : non autorisée.
- Directeur seul : autorisée immédiatement.
- Directeur + Chef de service : autorisée.
- Directeur + SDO : autorisée.
- Directeur + Chef de service + SDO : autorisée.

Le visa Directeur est prioritaire. La migration automatique est également appliquée par `api/db.php`.
