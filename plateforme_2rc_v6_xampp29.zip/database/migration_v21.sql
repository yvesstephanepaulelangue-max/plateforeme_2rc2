-- 2RC V21 - MIGRATION SANS PERTE DE DONNEES
-- A executer sur une base existante deja en V20/V18 Agent.
-- NE SUPPRIME AUCUNE TABLE ET NE SUPPRIME AUCUNE DONNEE.
USE if0_43096180_plateforme_2rc;

ALTER TABLE utilisateur MODIFY statut ENUM('ACTIF','INACTIF','SUPPRIME') DEFAULT 'ACTIF';
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS type_compte ENUM('AGENT_2RC','STAGIAIRE','TEMPORAIRE') DEFAULT 'AGENT_2RC' AFTER statut;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_demande TINYINT(1) DEFAULT 0 AFTER type_compte;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_demande_par INT NULL AFTER suppression_demande;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_demande_at DATETIME NULL AFTER suppression_demande_par;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_confirmee_par INT NULL AFTER suppression_demande_at;
ALTER TABLE utilisateur ADD COLUMN IF NOT EXISTS suppression_confirmee_at DATETIME NULL AFTER suppression_confirmee_par;
ALTER TABLE unite ADD COLUMN IF NOT EXISTS actif TINYINT(1) DEFAULT 1;
UPDATE utilisateur SET type_compte='AGENT_2RC' WHERE type_compte IS NULL OR type_compte='';
SELECT 'V21 appliquee sans suppression de donnees.' AS resultat;
