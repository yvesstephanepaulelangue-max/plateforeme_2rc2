CREATE DATABASE IF NOT EXISTS plateforme_2rc CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE plateforme_2rc;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS rapport_fichier, rapport, intervention_media, inspection, intervention_membre, equipe_membre, intervention, equipe, agent_unite, vehicule, stock, drain, utilisateur, unite, parametre_global;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE parametre_global(
 id INT AUTO_INCREMENT PRIMARY KEY,
 cle VARCHAR(80) UNIQUE NOT NULL,
 valeur TEXT,
 type_param ENUM('TEXT','NUMBER','BOOLEAN') DEFAULT 'TEXT',
 description VARCHAR(255),
 date_modification DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE unite(
 id INT AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(30) UNIQUE NOT NULL,
 nom VARCHAR(120) NOT NULL,
 type_unite ENUM('INSPECTION','ENTRETIEN') NOT NULL,
 description TEXT,
 actif TINYINT(1) DEFAULT 1,
 date_creation DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE utilisateur(
 id INT AUTO_INCREMENT PRIMARY KEY,
 matricule VARCHAR(40) UNIQUE,
 nom VARCHAR(80) NOT NULL,
 prenom VARCHAR(80) NOT NULL,
 email VARCHAR(160) UNIQUE NOT NULL,
 mot_de_passe VARCHAR(255) NOT NULL,
 role ENUM('ADMIN','INSPECTEUR','AGENT','DIRECTEUR') NOT NULL,
 telephone VARCHAR(30),
 statut ENUM('ACTIF','INACTIF') DEFAULT 'ACTIF',
 disponibilite ENUM('DISPONIBLE','OCCUPE','ABSENT') DEFAULT 'DISPONIBLE',
 date_creation DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE agent_unite(
 id INT AUTO_INCREMENT PRIMARY KEY,
 utilisateur_id INT NOT NULL,
 unite_id INT NOT NULL,
 UNIQUE(utilisateur_id,unite_id),
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
 FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE CASCADE
);

CREATE TABLE drain(
 id INT AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(40) UNIQUE NOT NULL,
 nom VARCHAR(220) NOT NULL,
 arrondissement VARCHAR(80) NOT NULL,
 type_drain ENUM('NATUREL','BETONNE') NOT NULL,
 lineaire_m DECIMAL(12,2),
 observation TEXT,
 etat ENUM('BON','A_SURVEILLER','DEGRADE','CRITIQUE') DEFAULT 'A_SURVEILLER',
 criticite_hydraulique TINYINT NOT NULL DEFAULT 1,
 exposition_urbaine TINYINT NOT NULL DEFAULT 1,
 equipement_sensible TINYINT NOT NULL DEFAULT 1,
 reseau_strategique TINYINT NOT NULL DEFAULT 1,
 difficulte_curage TINYINT NOT NULL DEFAULT 1,
 score_priorite INT GENERATED ALWAYS AS (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2) STORED,
 priorite VARCHAR(2) GENERATED ALWAYS AS (CASE WHEN (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2)>=80 THEN 'P1' WHEN (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2)>=65 THEN 'P2' WHEN (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2)>=50 THEN 'P3' ELSE 'P4' END) STORED,
 geom_json LONGTEXT,
 source_kml VARCHAR(255),
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_drain_priority(score_priorite,priorite)
);

CREATE TABLE equipe(
 id INT AUTO_INCREMENT PRIMARY KEY,
 nom VARCHAR(120) NOT NULL,
 type_intervention VARCHAR(80),
 unite_id INT NULL,
 cree_par INT NULL,
 actif TINYINT(1) DEFAULT 1,
 date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE SET NULL,
 FOREIGN KEY(cree_par) REFERENCES utilisateur(id) ON DELETE SET NULL
);

CREATE TABLE equipe_membre(
 id INT AUTO_INCREMENT PRIMARY KEY,
 equipe_id INT NOT NULL,
 utilisateur_id INT NOT NULL,
 UNIQUE(equipe_id,utilisateur_id),
 FOREIGN KEY(equipe_id) REFERENCES equipe(id) ON DELETE CASCADE,
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE
);

CREATE TABLE intervention(
 id INT AUTO_INCREMENT PRIMARY KEY,
 reference VARCHAR(40) UNIQUE NOT NULL,
 drain_id INT NOT NULL,
 equipe_id INT,
 type_intervention ENUM('CURAGE','REPARATION','NETTOYAGE','INSPECTION','AUTRE') NOT NULL,
 date_prevue DATETIME NOT NULL,
 date_fin_prevue DATETIME,
 statut ENUM('PLANIFIEE','EN_COURS','TERMINEE','EN_RETARD','ANNULEE') DEFAULT 'PLANIFIEE',
 description TEXT,
 geom_json LONGTEXT,
 cree_par INT,
 date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(drain_id) REFERENCES drain(id),
 FOREIGN KEY(equipe_id) REFERENCES equipe(id) ON DELETE SET NULL,
 FOREIGN KEY(cree_par) REFERENCES utilisateur(id) ON DELETE SET NULL,
 INDEX idx_intervention_date(date_prevue),
 INDEX idx_intervention_statut(statut)
);

CREATE TABLE intervention_membre(
 id INT AUTO_INCREMENT PRIMARY KEY,
 intervention_id INT NOT NULL,
 utilisateur_id INT NOT NULL,
 UNIQUE(intervention_id,utilisateur_id),
 FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE CASCADE,
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE
);

CREATE TABLE intervention_media(
 id INT AUTO_INCREMENT PRIMARY KEY,
 intervention_id INT NOT NULL,
 type_media ENUM('IMAGE','VIDEO','RAPPORT') NOT NULL,
 nom_fichier VARCHAR(255) NOT NULL,
 chemin VARCHAR(500) NOT NULL,
 mime_type VARCHAR(120),
 taille_octets BIGINT,
 date_ajout DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE CASCADE
);

CREATE TABLE inspection(
 id INT AUTO_INCREMENT PRIMARY KEY,
 drain_id INT NOT NULL,
 inspecteur_id INT,
 date_inspection DATETIME DEFAULT CURRENT_TIMESTAMP,
 etat_degradation ENUM('BON','LEGER','MOYEN','FORT','CRITIQUE') NOT NULL,
 criticite_hydraulique TINYINT NOT NULL,
 exposition_urbaine TINYINT NOT NULL,
 equipement_sensible TINYINT NOT NULL,
 reseau_strategique TINYINT NOT NULL,
 difficulte_curage TINYINT NOT NULL,
 score INT GENERATED ALWAYS AS (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2) STORED,
 observations TEXT,
 FOREIGN KEY(drain_id) REFERENCES drain(id),
 FOREIGN KEY(inspecteur_id) REFERENCES utilisateur(id) ON DELETE SET NULL
);

CREATE TABLE rapport(
 id INT AUTO_INCREMENT PRIMARY KEY,
 intervention_id INT,
 auteur_id INT,
 unite_id INT,
 titre VARCHAR(220) NOT NULL,
 type_rapport ENUM('INSPECTION','ENTRETIEN','INTERVENTION') NOT NULL,
 statut ENUM('ENVOYE','LU','TRAITE') DEFAULT 'ENVOYE',
 commentaire TEXT,
 date_envoi DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE SET NULL,
 FOREIGN KEY(auteur_id) REFERENCES utilisateur(id) ON DELETE SET NULL,
 FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE SET NULL,
 INDEX idx_rapport_date(date_envoi), INDEX idx_rapport_statut(statut)
);

CREATE TABLE rapport_fichier(
 id INT AUTO_INCREMENT PRIMARY KEY,
 rapport_id INT NOT NULL,
 type_fichier ENUM('RAPPORT','IMAGE','VIDEO') NOT NULL,
 nom_fichier VARCHAR(255) NOT NULL,
 chemin VARCHAR(500) NOT NULL,
 mime_type VARCHAR(120),
 taille_octets BIGINT,
 date_ajout DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(rapport_id) REFERENCES rapport(id) ON DELETE CASCADE
);

CREATE TABLE vehicule(
 id INT AUTO_INCREMENT PRIMARY KEY,
 immatriculation VARCHAR(30) UNIQUE NOT NULL,
 designation VARCHAR(120) NOT NULL,
 statut ENUM('DISPONIBLE','EN_SERVICE','MAINTENANCE','HORS_SERVICE') DEFAULT 'DISPONIBLE',
 unite VARCHAR(120),
 lieu_operation VARCHAR(220)
);

CREATE TABLE stock(
 id INT AUTO_INCREMENT PRIMARY KEY,
 designation VARCHAR(160) NOT NULL,
 categorie ENUM('MATERIAU','MATERIEL') NOT NULL,
 unite VARCHAR(30) NOT NULL,
 stock_disponible DECIMAL(12,2) DEFAULT 0,
 seuil_minimum DECIMAL(12,2) DEFAULT 0
);
