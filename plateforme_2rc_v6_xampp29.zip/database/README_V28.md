Migration V28 non destructive :
- téléphone obligatoire à l’inscription ;
- rôles CHEF_UNITE et HSE ajoutés ;
- Directeur autorisé à créer des interventions ;
- visa Directeur prioritaire : il autorise seul l’intervention ;
- quantités de matériel entières, pas de décimales ;
- Directeur seul peut attribuer le niveau d’accréditation ;
- Chef service/SDO peuvent accréditer stagiaires et temporaires mais pas Agent 2RC ;
- niveaux 1/2/3 appliqués aux accès Agent/Inspecteur ; niveau 4 et rôles de direction conservent leurs accès prévus.
La mise à niveau automatique est intégrée dans api/db.php. Ne pas lancer schema.sql ou seed.sql sur une base existante.