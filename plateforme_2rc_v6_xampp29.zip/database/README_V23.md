# 2RC V23 — mise à niveau sans perte

Cette version corrige le problème où les pages **Inscription**, **Accréditations** et **Unités** indiquaient que la base n'était pas à jour.

## Nouveau comportement

Le fichier `api/db.php` vérifie automatiquement la structure de la base au démarrage de chaque requête API et ajoute uniquement les éléments manquants.

La mise à niveau est **non destructive** :
- aucun `DROP TABLE` ;
- aucun `DELETE` de données existantes ;
- les anciens comptes `OUVRIER` sont convertis en `AGENT` ;
- les rattachements `ouvrier_unite` sont copiés vers `agent_unite` ;
- les colonnes nécessaires à l'accréditation, à la corbeille et aux unités sont ajoutées si elles manquent ;
- les éléments nécessaires au journal des drains sont ajoutés si absents.

## Installation

1. Remplacer l'ancienne plateforme par cette V23.
2. Conserver la même base `plateforme_2rc`.
3. Ne pas exécuter `schema.sql` ni `seed.sql` sur une base contenant déjà vos données.
4. Ouvrir `login.php`, puis tester Inscription et Accréditations.

`database/migration_v23.sql` reste disponible comme migration manuelle si vous préférez l'appliquer depuis phpMyAdmin.
