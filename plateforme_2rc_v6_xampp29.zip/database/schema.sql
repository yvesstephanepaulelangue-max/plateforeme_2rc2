USE if0_43096180_plateforme_2rc;
-- IMPORTANT : ce fichier est NON DESTRUCTIF.
-- Il ne supprime aucune table et ne supprime aucune donnée.
-- Pour une base existante, exécuter ensuite database/migration_sans_perte_v20.sql.

CREATE TABLE parametre_global(
 id INT AUTO_INCREMENT PRIMARY KEY,
 cle VARCHAR(80) UNIQUE NOT NULL,
 valeur TEXT,
 type_param ENUM('TEXT','NUMBER','BOOLEAN') DEFAULT 'TEXT',
 description VARCHAR(255),
 date_modification DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE unite(
 id INT AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(30) UNIQUE NOT NULL,
 nom VARCHAR(120) NOT NULL,
 type_unite ENUM('INSPECTION','ENTRETIEN') NOT NULL,
 description TEXT,
 chef_unite_id INT NULL,
 actif TINYINT(1) DEFAULT 1,
 date_creation DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE utilisateur(
 id INT AUTO_INCREMENT PRIMARY KEY,
 matricule VARCHAR(40) UNIQUE,
 nom VARCHAR(80) NOT NULL,
 prenom VARCHAR(80) NOT NULL,
 email VARCHAR(160) UNIQUE NOT NULL,
 mot_de_passe VARCHAR(255) NOT NULL,
 role ENUM('ADMIN','INSPECTEUR','AGENT','CHEF_UNITE','HSE','DIRECTEUR','SOUS_DIRECTEUR_OPERATIONS') NOT NULL,
 poste VARCHAR(160),
 niveau_accreditation ENUM('NIVEAU_1','NIVEAU_2','NIVEAU_3','NIVEAU_4') DEFAULT 'NIVEAU_1',
 telephone VARCHAR(30),
 statut ENUM('ACTIF','INACTIF','SUPPRIME') DEFAULT 'ACTIF',
 type_compte ENUM('AGENT_2RC','STAGIAIRE','TEMPORAIRE') DEFAULT 'AGENT_2RC',
 suppression_demande TINYINT(1) DEFAULT 0,
 suppression_demande_par INT NULL,
 suppression_demande_at DATETIME NULL,
 suppression_confirmee_par INT NULL,
 suppression_confirmee_at DATETIME NULL,
 disponibilite ENUM('DISPONIBLE','OCCUPE','ABSENT') DEFAULT 'DISPONIBLE',
 date_creation DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE agent_unite(
 id INT AUTO_INCREMENT PRIMARY KEY,
 utilisateur_id INT NOT NULL,
 unite_id INT NOT NULL,
 UNIQUE(utilisateur_id,unite_id),
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
 FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE CASCADE
);

CREATE TABLE drain(
 id INT AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(40) UNIQUE NOT NULL,
 nom VARCHAR(220) NOT NULL,
 arrondissement VARCHAR(80) NOT NULL,
 type_drain ENUM('NATUREL','BETONNE') NOT NULL,
 lineaire_m DECIMAL(12,2),
 observation TEXT,
 etat ENUM('DEBIT_CORRECT','SATURATION_PARTIELLE','SATURATION_TOTAL') DEFAULT 'DEBIT_CORRECT',
 criticite_hydraulique TINYINT NOT NULL DEFAULT 1,
 exposition_urbaine TINYINT NOT NULL DEFAULT 1,
 equipement_sensible TINYINT NOT NULL DEFAULT 1,
 reseau_strategique TINYINT NOT NULL DEFAULT 1,
 difficulte_curage TINYINT NOT NULL DEFAULT 1,
 avancement_pct DECIMAL(5,2) DEFAULT 0,
 etat_travail ENUM('PROGRAMME','NON_PROGRAMME','EN_COURS','SUSPENDU','REPORTE','TERMINE') DEFAULT 'NON_PROGRAMME',
 lineaire_execute_m DECIMAL(12,2) DEFAULT 0,
 lineaire_saute_m DECIMAL(12,2) DEFAULT 0,
 direction_travaux ENUM('A_VERS_B','B_VERS_A') DEFAULT 'A_VERS_B',
 lineaire_restant_m DECIMAL(12,2) GENERATED ALWAYS AS (GREATEST(COALESCE(lineaire_m,0)-COALESCE(lineaire_execute_m,0)-COALESCE(lineaire_saute_m,0),0)) STORED,
 score_priorite INT GENERATED ALWAYS AS (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2) STORED,
 priorite VARCHAR(2) GENERATED ALWAYS AS (CASE WHEN (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2)>=80 THEN 'P1' WHEN (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2)>=65 THEN 'P2' WHEN (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2)>=50 THEN 'P3' ELSE 'P4' END) STORED,
 geom_json LONGTEXT,
 source_kml VARCHAR(255),
 unite_inspection_id INT NULL,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_drain_priority(score_priorite,priorite),
 FOREIGN KEY(unite_inspection_id) REFERENCES unite(id) ON DELETE SET NULL
);

CREATE TABLE drain_modification_log(
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 drain_id INT NULL,
 action ENUM('CREATION','MODIFICATION','SUPPRESSION','INSPECTION','RESTAURATION') NOT NULL,
 utilisateur_id INT NULL,
 date_modification DATETIME DEFAULT CURRENT_TIMESTAMP,
 ancienne_valeur LONGTEXT NULL,
 nouvelle_valeur LONGTEXT NULL,
 commentaire VARCHAR(500) NULL,
 INDEX idx_dml_drain_date(drain_id,date_modification),
 INDEX idx_dml_date(date_modification),
 FOREIGN KEY(drain_id) REFERENCES drain(id) ON DELETE SET NULL,
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE SET NULL
);

CREATE TABLE equipe(
 id INT AUTO_INCREMENT PRIMARY KEY,
 nom VARCHAR(120) NOT NULL,
 type_intervention VARCHAR(80),
 unite_id INT NULL,
 cree_par INT NULL,
 actif TINYINT(1) DEFAULT 1,
 date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE SET NULL,
 FOREIGN KEY(cree_par) REFERENCES utilisateur(id) ON DELETE SET NULL
);

CREATE TABLE equipe_membre(
 id INT AUTO_INCREMENT PRIMARY KEY,
 equipe_id INT NOT NULL,
 utilisateur_id INT NOT NULL,
 UNIQUE(equipe_id,utilisateur_id),
 FOREIGN KEY(equipe_id) REFERENCES equipe(id) ON DELETE CASCADE,
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE
);

CREATE TABLE intervention(
 id INT AUTO_INCREMENT PRIMARY KEY,
 reference VARCHAR(40) UNIQUE NOT NULL,
 drain_id INT NOT NULL,
 equipe_id INT,
 unite_id INT NULL,
 type_intervention ENUM('CURAGE','REPARATION','NETTOYAGE','INSPECTION','AUTRE') NOT NULL,
 date_prevue DATETIME NULL,
 date_debut DATETIME NULL,
 date_fin_prevue DATETIME,
 statut ENUM('PLANIFIEE','EN_COURS','TERMINEE','EN_RETARD','ANNULEE') DEFAULT 'PLANIFIEE',
 visa_chef_service TINYINT(1) DEFAULT 0,
 visa_chef_service_par INT NULL,
 visa_chef_service_at DATETIME NULL,
 visa_sous_directeur TINYINT(1) DEFAULT 0,
 visa_sous_directeur_par INT NULL,
 visa_sous_directeur_at DATETIME NULL,
 visa_directeur TINYINT(1) DEFAULT 0,
 visa_directeur_par INT NULL,
 visa_directeur_at DATETIME NULL,
 mission_autorisee TINYINT(1) GENERATED ALWAYS AS (CASE WHEN visa_directeur=1 OR (visa_chef_service=1 AND visa_sous_directeur=1 AND visa_directeur=1) THEN 1 ELSE 0 END) STORED,
 description TEXT,
 geom_json LONGTEXT,
 cree_par INT,
 date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
 archivee TINYINT(1) NOT NULL DEFAULT 0,
 FOREIGN KEY(drain_id) REFERENCES drain(id),
 FOREIGN KEY(equipe_id) REFERENCES equipe(id) ON DELETE SET NULL,
 FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE SET NULL,
 FOREIGN KEY(cree_par) REFERENCES utilisateur(id) ON DELETE SET NULL,
 FOREIGN KEY(visa_chef_service_par) REFERENCES utilisateur(id) ON DELETE SET NULL,
 FOREIGN KEY(visa_sous_directeur_par) REFERENCES utilisateur(id) ON DELETE SET NULL,
 FOREIGN KEY(visa_directeur_par) REFERENCES utilisateur(id) ON DELETE SET NULL,
 INDEX idx_intervention_date(date_prevue),
 INDEX idx_intervention_statut(statut)
);

CREATE TABLE intervention_membre(
 id INT AUTO_INCREMENT PRIMARY KEY,
 intervention_id INT NOT NULL,
 utilisateur_id INT NOT NULL,
 UNIQUE(intervention_id,utilisateur_id),
 FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE CASCADE,
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE
);

CREATE TABLE intervention_media(
 id INT AUTO_INCREMENT PRIMARY KEY,
 intervention_id INT NOT NULL,
 type_media ENUM('IMAGE','VIDEO','RAPPORT') NOT NULL,
 nom_fichier VARCHAR(255) NOT NULL,
 chemin VARCHAR(500) NOT NULL,
 mime_type VARCHAR(120),
 taille_octets BIGINT,
 date_ajout DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE CASCADE
);

CREATE TABLE inspection(
 id INT AUTO_INCREMENT PRIMARY KEY,
 drain_id INT NOT NULL,
 inspecteur_id INT,
 date_inspection DATETIME DEFAULT CURRENT_TIMESTAMP,
 etat_degradation ENUM('BON','LEGER','MOYEN','FORT','CRITIQUE') NOT NULL,
 criticite_hydraulique TINYINT NOT NULL,
 exposition_urbaine TINYINT NOT NULL,
 equipement_sensible TINYINT NOT NULL,
 reseau_strategique TINYINT NOT NULL,
 difficulte_curage TINYINT NOT NULL,
 score INT GENERATED ALWAYS AS (criticite_hydraulique*6+exposition_urbaine*5+equipement_sensible*3+reseau_strategique*4+difficulte_curage*2) STORED,
 observations TEXT,
 FOREIGN KEY(drain_id) REFERENCES drain(id),
 FOREIGN KEY(inspecteur_id) REFERENCES utilisateur(id) ON DELETE SET NULL
);

CREATE TABLE intervention_travail_segment(
 id BIGINT AUTO_INCREMENT PRIMARY KEY, intervention_id INT NOT NULL, drain_id INT NOT NULL,
 coord_depart_approx_lat DECIMAL(10,7) NOT NULL, coord_depart_approx_lng DECIMAL(10,7) NOT NULL,
 coord_arrivee_approx_lat DECIMAL(10,7) NOT NULL, coord_arrivee_approx_lng DECIMAL(10,7) NOT NULL,
 point_depart_lat DECIMAL(10,7) NOT NULL, point_depart_lng DECIMAL(10,7) NOT NULL,
 point_arrivee_lat DECIMAL(10,7) NOT NULL, point_arrivee_lng DECIMAL(10,7) NOT NULL,
 distance_depart_m DECIMAL(12,2) NOT NULL DEFAULT 0, distance_arrivee_m DECIMAL(12,2) NOT NULL DEFAULT 0,
 longueur_executee_m DECIMAL(12,2) NOT NULL DEFAULT 0, mis_a_jour_par INT NULL,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE(intervention_id), INDEX idx_its_drain_distance(drain_id,distance_depart_m,distance_arrivee_m),
 FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE CASCADE,
 FOREIGN KEY(drain_id) REFERENCES drain(id) ON DELETE CASCADE,
 FOREIGN KEY(mis_a_jour_par) REFERENCES utilisateur(id) ON DELETE SET NULL
);

CREATE TABLE rapport(
 id INT AUTO_INCREMENT PRIMARY KEY,
 intervention_id INT,
 auteur_id INT,
 unite_id INT,
 titre VARCHAR(220) NOT NULL,
 type_rapport ENUM('INSPECTION','ENTRETIEN','INTERVENTION') NOT NULL,
 statut ENUM('ENVOYE','LU','TRAITE') DEFAULT 'ENVOYE',
 commentaire TEXT,
 date_envoi DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE SET NULL,
 FOREIGN KEY(auteur_id) REFERENCES utilisateur(id) ON DELETE SET NULL,
 FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE SET NULL,
 INDEX idx_rapport_date(date_envoi), INDEX idx_rapport_statut(statut)
);

CREATE TABLE rapport_fichier(
 id INT AUTO_INCREMENT PRIMARY KEY,
 rapport_id INT NOT NULL,
 type_fichier ENUM('RAPPORT','IMAGE','VIDEO') NOT NULL,
 nom_fichier VARCHAR(255) NOT NULL,
 chemin VARCHAR(500) NOT NULL,
 mime_type VARCHAR(120),
 taille_octets BIGINT,
 date_ajout DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(rapport_id) REFERENCES rapport(id) ON DELETE CASCADE
);

CREATE TABLE vehicule(
 id INT AUTO_INCREMENT PRIMARY KEY,
 immatriculation VARCHAR(30) UNIQUE NOT NULL,
 designation VARCHAR(120) NOT NULL,
 statut ENUM('DISPONIBLE','EN_SERVICE','MAINTENANCE','HORS_SERVICE') DEFAULT 'DISPONIBLE',
 unite VARCHAR(120),
 lieu_operation VARCHAR(220)
);

CREATE TABLE stock(
 id INT AUTO_INCREMENT PRIMARY KEY,
 designation VARCHAR(160) NOT NULL,
 categorie ENUM('MATERIAU','MATERIEL') NOT NULL,
 unite VARCHAR(30) NOT NULL,
 stock_disponible DECIMAL(12,2) DEFAULT 0,
 seuil_minimum DECIMAL(12,2) DEFAULT 0
);

CREATE TABLE intervention_material(
 id INT AUTO_INCREMENT PRIMARY KEY,
 intervention_id INT NOT NULL,
 stock_id INT NOT NULL,
 quantite DECIMAL(12,2) DEFAULT 1,
 FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE CASCADE,
 FOREIGN KEY(stock_id) REFERENCES stock(id) ON DELETE RESTRICT,
 UNIQUE(intervention_id,stock_id)
);



CREATE TABLE IF NOT EXISTS recuperation_mot_de_passe(id BIGINT AUTO_INCREMENT PRIMARY KEY,utilisateur_id INT NOT NULL,question VARCHAR(255) NOT NULL,reponse_hash VARCHAR(255) NOT NULL,date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,date_modification DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE KEY uq_recup_user(utilisateur_id),FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS recuperation_tentative(id BIGINT AUTO_INCREMENT PRIMARY KEY,identifiant VARCHAR(160) NOT NULL,ip_hash CHAR(64) NULL,date_tentative DATETIME DEFAULT CURRENT_TIMESTAMP,succes TINYINT(1) DEFAULT 0,INDEX idx_recup_try(identifiant,date_tentative));


CREATE TABLE IF NOT EXISTS notification(
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 utilisateur_id INT NOT NULL,
 type VARCHAR(40) NOT NULL,
 reference_id INT NULL,
 acteur_id INT NULL,
 message VARCHAR(255) NOT NULL,
 lu TINYINT(1) NOT NULL DEFAULT 0,
 date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 date_lecture DATETIME NULL,
 INDEX idx_notification_user_lu(utilisateur_id,lu,date_creation),
 INDEX idx_notification_type_ref(type,reference_id),
 FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
 FOREIGN KEY(acteur_id) REFERENCES utilisateur(id) ON DELETE SET NULL
);
