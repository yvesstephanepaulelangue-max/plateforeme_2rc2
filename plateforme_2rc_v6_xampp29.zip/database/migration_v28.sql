-- Migration V28 non destructive
-- Ajout des rôles Chef d'unité / HSE et du visa Directeur.
ALTER TABLE utilisateur MODIFY role ENUM('ADMIN','INSPECTEUR','AGENT','CHEF_UNITE','HSE','DIRECTEUR','SOUS_DIRECTEUR_OPERATIONS') NOT NULL;
ALTER TABLE intervention ADD COLUMN visa_directeur TINYINT(1) DEFAULT 0 AFTER visa_sous_directeur;
ALTER TABLE intervention ADD COLUMN visa_directeur_par INT NULL AFTER visa_directeur;
ALTER TABLE intervention ADD COLUMN visa_directeur_at DATETIME NULL AFTER visa_directeur_par;
ALTER TABLE intervention DROP COLUMN mission_autorisee;
ALTER TABLE intervention ADD COLUMN mission_autorisee TINYINT(1) GENERATED ALWAYS AS (CASE WHEN visa_directeur=1 OR (visa_chef_service=1 AND visa_sous_directeur=1 AND visa_directeur=1) THEN 1 ELSE 0 END) STORED;
