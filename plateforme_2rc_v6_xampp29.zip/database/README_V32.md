# V32 — Chef d’unité et sécurité

- Seul le rôle `CHEF_UNITE` peut créer/modifier/constituer/archiver une unité.
- `ADMIN`, `SOUS_DIRECTEUR_OPERATIONS`, `DIRECTEUR` peuvent uniquement consulter les unités.
- Une unité possède `chef_unite_id`.
- Le Chef d’unité a accès à Carte SIG, Interventions, Drains, Rapports et à son espace de constitution.
- L’envoi de rapports est réservé au Chef d’unité de l’unité concernée.
- Filtre de statut ajouté à Accréditations.
- Question clé de récupération : réponse hachée avec `password_hash`, tentatives limitées.
- Migration automatique dans `api/db.php`; ne pas exécuter `seed.sql` sur une base existante.
