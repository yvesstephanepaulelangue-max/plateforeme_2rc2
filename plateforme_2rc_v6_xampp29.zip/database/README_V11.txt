PLATEFORME 2RC — V11

IMPORTANT — installation propre XAMPP/MySQL/MariaDB
1. Créer la base plateforme_2rc.
2. Importer database/schema.sql.
3. Importer database/seed.sql.
4. Configurer api/db.php si les identifiants MySQL diffèrent.
5. Ouvrir index.php.

IMPORTANT — base existante
- Faire une sauvegarde de la base.
- Importer database/migration_v8.sql une seule fois.
- Cette migration convertit d’abord les anciens états BON/A_SURVEILLER/DEGRADE/CRITIQUE avant de modifier l’ENUM.

V11 corrige notamment :
- interface Drains réellement modifiée ;
- DEBIT_CORRECT / SATURATION_PARTIELLE / SATURATION_TOTAL ;
- linéaire sauté ;
- calcul exécuté+sauté, avancement et restant ;
- direction A→B / B→A ;
- carte SIG et clics sur les drains ;
- carte SIG sur Entretien ;
- page Opérations Inspection et Entretien ;
- inscription → compte INACTIF → Accréditations → attribution du poste → activation ;
- dates d’intervention optionnelles mais correctement enregistrées lorsqu’elles sont fournies ;
- intervention créée par le SDO directement autorisée ; intervention créée par ADMIN soumise aux deux visas ;
- seed.sql compatible avec le nouvel ENUM ;
- palette/logo 2RC intégrés à l’interface.
