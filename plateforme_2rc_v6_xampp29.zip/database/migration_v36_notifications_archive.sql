-- Migration V36 — notifications, archivage des interventions et navigation
-- Sans perte de données. Compatible MariaDB/MySQL.
ALTER TABLE intervention
    ADD COLUMN IF NOT EXISTS archivee TINYINT(1) NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS notification(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    type VARCHAR(40) NOT NULL,
    reference_id INT NULL,
    acteur_id INT NULL,
    message VARCHAR(255) NOT NULL,
    lu TINYINT(1) NOT NULL DEFAULT 0,
    date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_lecture DATETIME NULL,
    INDEX idx_notification_user_lu(utilisateur_id,lu,date_creation),
    INDEX idx_notification_type_ref(type,reference_id),
    FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
    FOREIGN KEY(acteur_id) REFERENCES utilisateur(id) ON DELETE SET NULL
);
