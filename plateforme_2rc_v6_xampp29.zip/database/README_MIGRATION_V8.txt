MIGRATION BASE EXISTANTE - VERSION SANS PERTE

IMPORTANT : ne pas utiliser un ancien schema.sql contenant DROP TABLE sur une base qui contient des données.

Le fichier migration_v8.sql a été remplacé par une migration NON DESTRUCTIVE V20.
Il ne contient aucun DROP TABLE et aucun DELETE de données.

Pour une base existante :
1. Sélectionner la base plateforme_2rc dans phpMyAdmin.
2. Faire de préférence une sauvegarde/export SQL de sécurité.
3. Importer database/migration_v8.sql.
4. Ne pas importer seed.sql sur une base existante, car seed.sql ajoute des données de démonstration.

Cette migration conserve les données existantes et adapte la structure pour la version actuelle de la plateforme.
