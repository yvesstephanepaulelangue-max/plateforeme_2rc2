PLATEFORME 2RC — MIGRATION V10

Modifications :
1. Etats techniques des drains :
   DEBIT_CORRECT / SATURATION_PARTIELLE / SATURATION_TOTAL
2. lineaire_saute_m : longueur qui n'avait pas besoin d'être curée.
3. Avancement = (lineaire_execute_m + lineaire_saute_m) / lineaire_m * 100, plafonné à 100.
4. Linéaire restant = lineaire_m - lineaire_execute_m - lineaire_saute_m, minimum 0.
5. direction_travaux : A_VERS_B ou B_VERS_A.
6. SIG : couleur progressive du tracé, vert pour la partie exécutée/sautée et orange pour la partie restante; le sens est inversé pour B_VERS_A.
7. Inscription : compte créé INACTIF; il apparaît dans Accréditations. Le chef de service attribue le poste, rôle, niveau et active le compte.
8. Pages Opérations : operation-inspection.php et operation-entretien.php affichent les interventions autorisées affectées aux unités.
9. Direction : indicateurs de linéaire total, bétonné, naturel, exécuté et sauté.
10. Carte : choix Satellite/OpenStreetMap et légende placée juste dessous; écran de chargement 10 secondes.

Pour une base existante : exécuter database/migration_v8.sql une seule fois. Cette version contient le bloc V10 à la fin.
Pour une nouvelle installation : utiliser schema.sql puis seed.sql.
