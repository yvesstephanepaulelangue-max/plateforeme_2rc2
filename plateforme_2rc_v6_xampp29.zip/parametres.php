<?php session_start();
if (empty($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true)) {
    header('Location:login.php');
    exit;
} ?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Paramètres</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt" onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Paramètres</h1>
                    <div class="sub">Configuration générale de la plateforme et gestion des matériels. La gestion des
                        unités se fait désormais dans la page Unités.</div>
                </div>
            </div>
            <div class="tabbar">
                <button class="tabbtn active" onclick="tab('general',this)">Paramètres généraux</button>
                <?php if(in_array($_SESSION['user']['role'], ['HSE'], true)): ?><button class="tabbtn"
                    onclick="tab('materials',this)">Paramètre de matériel</button><?php endif; ?>
            </div>
            <section id="general">
                <form id="f" class="form">
                    <div class="card field"><label>Fond cartographique par défaut</label><select name="map_provider">
                            <option value="SATELLITE">Satellite</option>
                            <option value="OSM">OpenStreetMap</option>
                        </select></div>
                    <div class="card field"><label>Latitude centrale</label><input name="map_lat" type="number"
                            step="0.000001"></div>
                    <div class="card field"><label>Longitude centrale</label><input name="map_lng" type="number"
                            step="0.000001"></div>
                    <div class="card field"><label>Zoom initial</label><input name="map_zoom" type="number" min="1"
                            max="20"></div>
                    <div class="card field"><label>Nombre maximal d’images</label><input name="max_images" type="number"
                            min="1" max="20"></div>
                    <div class="card field"><label>Taille maximale vidéo (Mo)</label><input name="max_video_mb"
                            type="number" min="1" max="500"></div>
                    <div class="card field"><label>Taille maximale rapport (Mo)</label><input name="max_report_mb"
                            type="number" min="1" max="100"></div>
                    <div class="field full"><button class="btn">Enregistrer</button></div>
                </form>
            </section>
            <?php if(in_array($_SESSION['user']['role'], ['HSE'], true)): ?>
            <section id="materials" class="hidden">
                <div class="card">
                    <h3>Ajouter un matériel</h3>
                    <form id="mf" class="form">
                        <div class="field"><label>Désignation</label>
                            <input name="designation" required placeholder="Casque de protection"></div>
                        <div class="field">
                            <label>Catégorie</label>
                            <select name="categorie">
                                <option>EPI</option>
                                <option>MATERIAU</option>
                            </select>
                        </div>
                        <div class="field">
                            <label>Unité</label>
                            <input name="unite" value="unité" required>
                        </div>
                        <div class="field">
                            <label>Stock initial</label>
                            <input name="stock_disponible" type="number"
                                min="0" step=".01" value="0"></div>
                        <div class="field">
                            <label>Seuil minimum</label>
                            <input name="seuil_minimum" type="number" min="0"step=".01" value="0">
                        </div>
                        <div class="field full">
                            <button class="btn">Ajouter le matériel</button>
                        </div>
                    </form>
                </div>
                <div class="table" style="margin-top:16px">
                    <table>
                        <thead>
                            <tr>
                                <th>Désignation</th>
                                <th>Catégorie</th>
                                <th>Stock</th>
                                <th>Seuil</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="mtbody"></tbody>
                    </table>
                </div>
            </section>
            <?php endif; ?>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>
    const f = document.getElementById('f'),
        mf = document.getElementById('mf');

    function tab(id, b) {
        document.querySelectorAll('main section').forEach(s => s.classList.add('hidden'));
        document.getElementById(id).classList.remove('hidden');
        document.querySelectorAll('.tabbtn').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        if (id === 'materials') loadMaterials()
    }
    async function loadGeneral() {
        let x = await api('settings');
        x.forEach(s => {
            if (f.elements[s.cle]) f.elements[s.cle].value = s.valeur
        })
    }
    f.onsubmit = async e => {
        e.preventDefault();
        let o = {};
        for (let el of f.elements)
            if (el.name) o[el.name] = el.value;
        let r = await api('save_settings', {
            settings: JSON.stringify(o)
        }, 'POST');
        toast(r.ok ? 'Paramètres enregistrés.' : r.message, r.ok ? 'success' : 'error')
    };
    async function loadUnits() {
        let x = await api('units');
        document.getElementById('unitList').innerHTML = x.units.map(u =>
            `<div class="card"><b>${esc(u.code)} — ${esc(u.nom)}</b><br><small>${esc(u.type_unite)} · ${u.membres} membre(s)</small></div>`
            ).join('') || '<div class="notice">Aucune unité.</div>'
    }
    async function loadMaterials() {
        let x = await api('materials_manage');
        document.getElementById('mtbody').innerHTML = x.map(m =>
            `<tr><td>${esc(m.designation)}</td><td>${esc(m.categorie)}</td><td>${m.stock_disponible} ${esc(m.unite)}</td><td>${m.seuil_minimum}</td><td><button class="btn danger" onclick="delMat(${m.id})">Supprimer</button></td></tr>`
            ).join('') || '<tr><td colspan="5">Aucun matériel.</td></tr>'
    }
    mf.onsubmit = async e => {
        e.preventDefault();
        let r = await api('create_material', new FormData(mf), 'POST');
        if (r.ok) {
            toast('Matériel ajouté.');
            mf.reset();
            loadMaterials()
        } else toast(r.message, 'error')
    };
    async function delMat(id) {
        if (!confirm('Supprimer ce matériel ?')) return;
        let r = await api('delete_material', {
            id
        }, 'POST');
        toast(r.ok ? 'Matériel supprimé.' : r.message, r.ok ? 'success' : 'error');
        if (r.ok) loadMaterials()
    }
    guard(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']).then(loadGeneral)
    </script>
</body>

</html>