<?php session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'DIRECTEUR') {
    header('Location:login.php');
    exit;
} ?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Direction</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt" onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head reveal">
                <div>
                    <h1>Vue direction</h1>
                    <div class="sub">Information brute et indicateurs — aucune modification.</div>
                </div>
            </div>
            <div id="k" class="grid kpis"></div>
            <div id="linearKpis" class="grid two" style="margin-top:16px"></div>
            <div class="card reveal delay2" style="margin-top:16px">
                <h3>Drains prioritaires</h3>
                <div class="table">
                    <table id="t">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Drain</th>
                                <th>Arrondissement</th>
                                <th>Linéaire</th>
                                <th>Avancement</th>
                                <th>État</th>
                                <th>Priorité</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>
    async function load() {
        let r = await api('dashboard'),
            d = await api('drains');
        let items = [
            ['Interventions', r.interventions.total || 0, ''],
            ['Drains', r.drains.total || 0, ''],
            ['Retards', r.interventions.retard || 0, ''],
            ['Avancement', Number(r.progress || 0), '%']
        ];
        k.innerHTML = items.map(x =>
            `<div class="card kpi"><div class="label">${x[0]}</div><div class="value" data-target="${x[1]}">0</div><div class="sub">${x[2]}</div></div>`
            ).join('');
        linearKpis.innerHTML =
            `<div class="card kpi"><div class="label">LINÉAIRE TOTAL DES DRAINS</div><div class="value">${Number(r.drains.lineaire_total || 0).toLocaleString('fr-FR')} m</div><div class="sub">Bétonnés : ${Number(r.drains.lineaire_beton || 0).toLocaleString('fr-FR')} m · Naturels : ${Number(r.drains.lineaire_naturel || 0).toLocaleString('fr-FR')} m</div></div><div class="card kpi"><div class="label">LINÉAIRE EXÉCUTÉ + SAUTÉ</div><div class="value">${Number(r.drains.lineaire_realise || 0).toLocaleString('fr-FR')} m</div><div class="sub">Exécuté : ${Number(r.drains.lineaire_execute || 0).toLocaleString('fr-FR')} m · Sauté : ${Number(r.drains.lineaire_saute || 0).toLocaleString('fr-FR')} m</div></div>`;
        document.querySelectorAll('.value').forEach(x => animateNumber(x, x.dataset.target, x.parentElement
            .querySelector('.label').textContent === 'Avancement' ? '%' : ''));
        t.querySelector('tbody').innerHTML = d.map(x =>
            `<tr><td>${esc(x.code)}</td><td>${esc(x.nom)}</td><td>${esc(x.arrondissement)}</td><td>${Number(x.lineaire_m || 0).toLocaleString('fr-FR')} m</td><td><div class="progress"><span style="width:${Number(x.avancement_pct || 0)}%"></span></div>${Number(x.avancement_pct || 0)}%</td><td>${badge(x.etat_travail)}</td><td>${badge(x.priorite)}</td></tr>`
            ).join('')
    }
    guard('DIRECTEUR').then(load);
    startAutoRefresh(load, 30000)
    </script>
</body>

</html>