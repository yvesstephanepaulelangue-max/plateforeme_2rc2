<?php
// Connexion DB dynamique pour Railway
$host     = getenv('MYSQLHOST') ?: '127.0.0.1';
$db_name  = getenv('MYSQLDATABASE') ?: 'plateforme_2rc';
$username = getenv('MYSQLUSER') ?: 'root';
$password = getenv('MYSQLPASSWORD') ?: '';
$port     = getenv('MYSQLPORT') ?: '3306';

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$db_name;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
} catch (Exception $e) {
    die('Erreur de connexion : ' . $e->getMessage());
}


function dbHasTable(PDO $pdo,string $table): bool {
    $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?");
    $q->execute([$table]);
    return (bool)$q->fetchColumn();
}
function dbHasColumn(PDO $pdo,string $table,string $column): bool {
    $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?");
    $q->execute([$table,$column]);
    return (bool)$q->fetchColumn();
}
function dbColumnType(PDO $pdo,string $table,string $column): string {
    $q=$pdo->prepare("SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
    $q->execute([$table,$column]);
    return (string)($q->fetchColumn() ?: '');
}
function dbHasIndex(PDO $pdo,string $table,string $index): bool {
    $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND INDEX_NAME=?");
    $q->execute([$table,$index]);
    return (bool)$q->fetchColumn();
}
function dbAlter(PDO $pdo,string $sql): void {
    try { $pdo->exec($sql); }
    catch(PDOException $e) {
        error_log('[2RC DB migration] '.$e->getMessage().' | SQL: '.$sql);
        throw $e;
    }
}

function ensure2RCSchema(PDO $pdo): void {
    if(!dbHasTable($pdo,'utilisateur') || !dbHasTable($pdo,'unite')) return;

    /* ---------- UTILISATEUR ---------- */
    $roleType=dbColumnType($pdo,'utilisateur','role');
    if($roleType && (strpos($roleType,"'AGENT'")===false || strpos($roleType,"'OUVRIER'")!==false || strpos($roleType,"'CHEF_UNITE'")===false || strpos($roleType,"'HSE'")===false || strpos($roleType,"'SOUS_DIRECTEUR_OPERATIONS'")===false)){
        // On conserve temporairement OUVRIER afin de convertir les anciens comptes sans perte.
        dbAlter($pdo,"ALTER TABLE utilisateur MODIFY role ENUM('ADMIN','INSPECTEUR','OUVRIER','AGENT','CHEF_UNITE','HSE','DIRECTEUR','SOUS_DIRECTEUR_OPERATIONS') NOT NULL");
    }
    // Cette requête est sans effet sur les bases qui n'ont plus OUVRIER.
    try { $pdo->exec("UPDATE utilisateur SET role='AGENT' WHERE role='OUVRIER'"); } catch(Throwable $e) { error_log('[2RC DB migration] conversion OUVRIER->AGENT: '.$e->getMessage()); }
    $roleType=dbColumnType($pdo,'utilisateur','role');
    if($roleType && strpos($roleType,"'OUVRIER'")!==false){
        dbAlter($pdo,"ALTER TABLE utilisateur MODIFY role ENUM('ADMIN','INSPECTEUR','AGENT','CHEF_UNITE','HSE','DIRECTEUR','SOUS_DIRECTEUR_OPERATIONS') NOT NULL");
    }

    if(!dbHasColumn($pdo,'utilisateur','poste')) dbAlter($pdo,"ALTER TABLE utilisateur ADD COLUMN poste VARCHAR(160) NULL AFTER role");
    if(!dbHasColumn($pdo,'utilisateur','niveau_accreditation')) dbAlter($pdo,"ALTER TABLE utilisateur ADD COLUMN niveau_accreditation ENUM('NIVEAU_1','NIVEAU_2','NIVEAU_3','NIVEAU_4') DEFAULT 'NIVEAU_1' AFTER poste");
    if(!dbHasColumn($pdo,'utilisateur','type_compte')) dbAlter($pdo,"ALTER TABLE utilisateur ADD COLUMN type_compte ENUM('AGENT_2RC','STAGIAIRE','TEMPORAIRE') DEFAULT 'AGENT_2RC' AFTER statut");
    if(!dbHasColumn($pdo,'utilisateur','suppression_demande')) dbAlter($pdo,"ALTER TABLE utilisateur ADD COLUMN suppression_demande TINYINT(1) DEFAULT 0 AFTER type_compte");
    if(!dbHasColumn($pdo,'utilisateur','suppression_demande_par')) dbAlter($pdo,"ALTER TABLE utilisateur ADD COLUMN suppression_demande_par INT NULL AFTER suppression_demande");
    if(!dbHasColumn($pdo,'utilisateur','suppression_demande_at')) dbAlter($pdo,"ALTER TABLE utilisateur ADD COLUMN suppression_demande_at DATETIME NULL AFTER suppression_demande_par");
    if(!dbHasColumn($pdo,'utilisateur','suppression_confirmee_par')) dbAlter($pdo,"ALTER TABLE utilisateur ADD COLUMN suppression_confirmee_par INT NULL AFTER suppression_demande_at");
    if(!dbHasColumn($pdo,'utilisateur','suppression_confirmee_at')) dbAlter($pdo,"ALTER TABLE utilisateur ADD COLUMN suppression_confirmee_at DATETIME NULL AFTER suppression_confirmee_par");
    if(!dbHasColumn($pdo,'utilisateur','disponibilite')) dbAlter($pdo,"ALTER TABLE utilisateur ADD COLUMN disponibilite ENUM('DISPONIBLE','OCCUPE','ABSENT') DEFAULT 'DISPONIBLE'");

    $statutType=dbColumnType($pdo,'utilisateur','statut');
    if($statutType && strpos($statutType,"'SUPPRIME'")===false){
        dbAlter($pdo,"ALTER TABLE utilisateur MODIFY statut ENUM('ACTIF','INACTIF','SUPPRIME') DEFAULT 'ACTIF'");
    }
    try { $pdo->exec("UPDATE utilisateur SET type_compte='AGENT_2RC' WHERE type_compte IS NULL OR type_compte=''"); } catch(Throwable $e) { error_log('[2RC DB migration] type_compte: '.$e->getMessage()); }
    try { $pdo->exec("UPDATE utilisateur SET suppression_demande=0 WHERE suppression_demande IS NULL"); } catch(Throwable $e) { error_log('[2RC DB migration] suppression_demande: '.$e->getMessage()); }

    /* ---------- UNITES ---------- */
    if(!dbHasColumn($pdo,'unite','actif')) dbAlter($pdo,"ALTER TABLE unite ADD COLUMN actif TINYINT(1) DEFAULT 1");
    if(!dbHasColumn($pdo,'unite','chef_unite_id')) dbAlter($pdo,"ALTER TABLE unite ADD COLUMN chef_unite_id INT NULL AFTER description");
    try { $pdo->exec("UPDATE unite SET actif=1 WHERE actif IS NULL"); } catch(Throwable $e) { error_log('[2RC DB migration] unite.actif: '.$e->getMessage()); }

    if(!dbHasTable($pdo,'agent_unite')){
        dbAlter($pdo,"CREATE TABLE agent_unite(
            id INT AUTO_INCREMENT PRIMARY KEY,
            utilisateur_id INT NOT NULL,
            unite_id INT NOT NULL,
            UNIQUE(utilisateur_id,unite_id),
            FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
            FOREIGN KEY(unite_id) REFERENCES unite(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    if(dbHasTable($pdo,'ouvrier_unite')){
        try { $pdo->exec("INSERT IGNORE INTO agent_unite(utilisateur_id,unite_id) SELECT utilisateur_id,unite_id FROM ouvrier_unite"); }
        catch(Throwable $e) { error_log('[2RC DB migration] copie ouvrier_unite: '.$e->getMessage()); }
    }

    /* ---------- DRAINS ---------- */
    if(dbHasTable($pdo,'drain')){
        if(!dbHasColumn($pdo,'drain','lineaire_saute_m') && dbHasColumn($pdo,'drain','lineaire_execute_m')) dbAlter($pdo,"ALTER TABLE drain ADD COLUMN lineaire_saute_m DECIMAL(12,2) DEFAULT 0 AFTER lineaire_execute_m");
        if(!dbHasColumn($pdo,'drain','direction_travaux')) dbAlter($pdo,"ALTER TABLE drain ADD COLUMN direction_travaux ENUM('A_VERS_B','B_VERS_A') DEFAULT 'A_VERS_B'");
        if(!dbHasColumn($pdo,'drain','updated_at')) dbAlter($pdo,"ALTER TABLE drain ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

        $etatType=dbColumnType($pdo,'drain','etat');
        if($etatType && strpos($etatType,"'DEBIT_CORRECT'")===false){
            dbAlter($pdo,"ALTER TABLE drain MODIFY etat ENUM('BON','A_SURVEILLER','DEGRADE','CRITIQUE','DEBIT_CORRECT','SATURATION_PARTIELLE','SATURATION_TOTAL') DEFAULT 'DEBIT_CORRECT'");
            try { $pdo->exec("UPDATE drain SET etat='DEBIT_CORRECT' WHERE etat='BON'"); } catch(Throwable $e) { error_log('[2RC DB migration] drain BON: '.$e->getMessage()); }
            try { $pdo->exec("UPDATE drain SET etat='SATURATION_PARTIELLE' WHERE etat IN('A_SURVEILLER','DEGRADE')"); } catch(Throwable $e) { error_log('[2RC DB migration] drain surveillance: '.$e->getMessage()); }
            try { $pdo->exec("UPDATE drain SET etat='SATURATION_TOTAL' WHERE etat='CRITIQUE'"); } catch(Throwable $e) { error_log('[2RC DB migration] drain critique: '.$e->getMessage()); }
            dbAlter($pdo,"ALTER TABLE drain MODIFY etat ENUM('DEBIT_CORRECT','SATURATION_PARTIELLE','SATURATION_TOTAL') DEFAULT 'DEBIT_CORRECT'");
        }
    }

    /* ---------- INTERVENTIONS : VISA DIRECTEUR ---------- */
    if(dbHasTable($pdo,'intervention')){
        if(!dbHasColumn($pdo,'intervention','visa_directeur')) dbAlter($pdo,"ALTER TABLE intervention ADD COLUMN visa_directeur TINYINT(1) DEFAULT 0 AFTER visa_sous_directeur");
        if(!dbHasColumn($pdo,'intervention','visa_directeur_par')) dbAlter($pdo,"ALTER TABLE intervention ADD COLUMN visa_directeur_par INT NULL AFTER visa_directeur");
        if(!dbHasColumn($pdo,'intervention','visa_directeur_at')) dbAlter($pdo,"ALTER TABLE intervention ADD COLUMN visa_directeur_at DATETIME NULL AFTER visa_directeur_par");
        try { dbAlter($pdo,"ALTER TABLE intervention MODIFY mission_autorisee TINYINT(1) GENERATED ALWAYS AS (CASE WHEN visa_directeur=1 OR (visa_chef_service=1 AND visa_sous_directeur=1) THEN 1 ELSE 0 END) STORED"); } catch(Throwable $e) { error_log('[2RC DB migration] mission_autorisee: '.$e->getMessage()); }
    }

    /* ---------- RECUPERATION MOT DE PASSE ---------- */
    if(!dbHasTable($pdo,'recuperation_mot_de_passe')) dbAlter($pdo,"CREATE TABLE recuperation_mot_de_passe(id BIGINT AUTO_INCREMENT PRIMARY KEY,utilisateur_id INT NOT NULL,question VARCHAR(255) NOT NULL,reponse_hash VARCHAR(255) NOT NULL,date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,date_modification DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE KEY uq_recup_user(utilisateur_id),FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if(!dbHasTable($pdo,'recuperation_tentative')) dbAlter($pdo,"CREATE TABLE recuperation_tentative(id BIGINT AUTO_INCREMENT PRIMARY KEY,identifiant VARCHAR(160) NOT NULL,ip_hash CHAR(64) NULL,date_tentative DATETIME DEFAULT CURRENT_TIMESTAMP,succes TINYINT(1) DEFAULT 0,INDEX idx_recup_try(identifiant,date_tentative)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    /* ---------- TRONÇONS DE TRAVAUX GÉOLOCALISÉS ---------- */
    if(!dbHasTable($pdo,'intervention_travail_segment')){
        dbAlter($pdo,"CREATE TABLE intervention_travail_segment(
            id BIGINT AUTO_INCREMENT PRIMARY KEY, intervention_id INT NOT NULL, drain_id INT NOT NULL,
            coord_depart_approx_lat DECIMAL(10,7) NOT NULL, coord_depart_approx_lng DECIMAL(10,7) NOT NULL,
            coord_arrivee_approx_lat DECIMAL(10,7) NOT NULL, coord_arrivee_approx_lng DECIMAL(10,7) NOT NULL,
            point_depart_lat DECIMAL(10,7) NOT NULL, point_depart_lng DECIMAL(10,7) NOT NULL,
            point_arrivee_lat DECIMAL(10,7) NOT NULL, point_arrivee_lng DECIMAL(10,7) NOT NULL,
            distance_depart_m DECIMAL(12,2) NOT NULL DEFAULT 0, distance_arrivee_m DECIMAL(12,2) NOT NULL DEFAULT 0,
            longueur_executee_m DECIMAL(12,2) NOT NULL DEFAULT 0, mis_a_jour_par INT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_its_intervention(intervention_id), INDEX idx_its_drain_distance(drain_id,distance_depart_m,distance_arrivee_m),
            FOREIGN KEY(intervention_id) REFERENCES intervention(id) ON DELETE CASCADE,
            FOREIGN KEY(drain_id) REFERENCES drain(id) ON DELETE CASCADE,
            FOREIGN KEY(mis_a_jour_par) REFERENCES utilisateur(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    // Une même intervention peut comporter plusieurs reprises de travaux sur des intervalles distincts.
    // On conserve les lignes existantes et on remplace seulement la contrainte d'unicité par intervalle.
    if(dbHasTable($pdo,'intervention_travail_segment') && dbHasIndex($pdo,'intervention_travail_segment','uq_its_intervention')){
        dbAlter($pdo,"ALTER TABLE intervention_travail_segment DROP INDEX uq_its_intervention, ADD UNIQUE KEY uq_its_intervention_interval(intervention_id,distance_depart_m,distance_arrivee_m)");
    }

    /* ---------- JOURNAL DES DRAINS ---------- */
    if(!dbHasTable($pdo,'drain_modification_log')){
        dbAlter($pdo,"CREATE TABLE drain_modification_log(
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            drain_id INT NULL,
            action ENUM('CREATION','MODIFICATION','SUPPRESSION','INSPECTION','RESTAURATION') NOT NULL,
            utilisateur_id INT NULL,
            date_modification DATETIME DEFAULT CURRENT_TIMESTAMP,
            ancienne_valeur LONGTEXT NULL,
            nouvelle_valeur LONGTEXT NULL,
            commentaire VARCHAR(500) NULL,
            INDEX idx_dml_drain_date(drain_id,date_modification),
            INDEX idx_dml_date(date_modification),
            FOREIGN KEY(drain_id) REFERENCES drain(id) ON DELETE SET NULL,
            FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } else {
        $actionType=dbColumnType($pdo,'drain_modification_log','action');
        if($actionType && strpos($actionType,"'RESTAURATION'")===false) dbAlter($pdo,"ALTER TABLE drain_modification_log MODIFY action ENUM('CREATION','MODIFICATION','SUPPRESSION','INSPECTION','RESTAURATION') NOT NULL");
    }
}

// Mise à niveau automatique et NON DESTRUCTIVE. Si une étape échoue, elle est
// journalisée et l'erreur est remontée : la page affichera un message explicite.
ensure2RCSchema($pdo);
