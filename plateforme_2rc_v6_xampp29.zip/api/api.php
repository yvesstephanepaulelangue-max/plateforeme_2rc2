<?php
$secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
session_start();
try {
    require __DIR__ . '/db.php';
} catch (Throwable $e) {
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'Base de données indisponible. Vérifiez MySQL et api/db.php.'], JSON_UNESCAPED_UNICODE);
    exit;
}
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
if (!isset($_SESSION['csrf_token']))
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));


/*
 * Fonctions ajoutées pour les notifications et l'archivage.
 * Elles créent uniquement les éléments manquants et ne suppriment aucune donnée.
 */
function ensureFeatureSchema()
{
    global $pdo;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS notification (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            utilisateur_id INT NOT NULL,
            type VARCHAR(40) NOT NULL,
            reference_id INT NULL,
            acteur_id INT NULL,
            message VARCHAR(255) NOT NULL,
            lu TINYINT(1) NOT NULL DEFAULT 0,
            date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            date_lecture DATETIME NULL,
            INDEX idx_notification_user_lu (utilisateur_id, lu, date_creation),
            INDEX idx_notification_type_ref (type, reference_id),
            FOREIGN KEY (utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
            FOREIGN KEY (acteur_id) REFERENCES utilisateur(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("ALTER TABLE intervention ADD COLUMN IF NOT EXISTS archivee TINYINT(1) NOT NULL DEFAULT 0");
    } catch (Throwable $e) {
        // Les anciennes installations peuvent être temporairement indisponibles.
        // Les actions qui dépendent de ces éléments retourneront alors leur erreur normale.
    }
}
ensureFeatureSchema();

function notifyUsers(array $types, $message, $referenceId = null, $actorId = null, array $exclude = [])
{
    global $pdo;
    $types = array_values(array_unique($types));
    if (!$types || !$message) return;
    $place = implode(',', array_fill(0, count($types), '?'));
    $params = $types;
    $sql = "SELECT id FROM utilisateur WHERE statut='ACTIF' AND role IN ($place)";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    $users = $st->fetchAll(PDO::FETCH_COLUMN);
    $ins = $pdo->prepare("INSERT INTO notification(utilisateur_id,type,reference_id,acteur_id,message) VALUES(?,?,?,?,?)");
    foreach ($users as $uid) {
        $uid = (int)$uid;
        if ($uid === (int)$actorId || in_array($uid, $exclude, true)) continue;
        $ins->execute([$uid, $types[0], $referenceId ? (int)$referenceId : null, $actorId ? (int)$actorId : null, $message]);
    }
}
function notifyRoles(array $roles, $type, $message, $referenceId = null, $actorId = null)
{
    global $pdo;
    if (!$roles || !$type || !$message) return;
    $place=implode(',',array_fill(0,count($roles),'?'));
    $q=$pdo->prepare("SELECT id FROM utilisateur WHERE statut='ACTIF' AND role IN ($place)");
    $q->execute(array_values($roles));
    $ids=$q->fetchAll(PDO::FETCH_COLUMN);
    notifySpecificUsers($ids,$type,$message,$referenceId,$actorId);
}

function notifySpecificUsers(array $userIds, $type, $message, $referenceId = null, $actorId = null)
{
    global $pdo;
    $ins = $pdo->prepare("INSERT INTO notification(utilisateur_id,type,reference_id,acteur_id,message) VALUES(?,?,?,?,?)");
    foreach (array_unique(array_map('intval', $userIds)) as $uid) {
        if (!$uid || $uid === (int)$actorId) continue;
        $ins->execute([$uid, $type, $referenceId ? (int)$referenceId : null, $actorId ? (int)$actorId : null, $message]);
    }
}
function markNotificationTypeRead($userId, $type, $referenceId = null)
{
    global $pdo;
    if ($referenceId !== null) {
        $q = $pdo->prepare("UPDATE notification SET lu=1,date_lecture=NOW() WHERE utilisateur_id=? AND type=? AND reference_id=? AND lu=0");
        $q->execute([(int)$userId, $type, (int)$referenceId]);
    } else {
        $q = $pdo->prepare("UPDATE notification SET lu=1,date_lecture=NOW() WHERE utilisateur_id=? AND type=? AND lu=0");
        $q->execute([(int)$userId, $type]);
    }
}
function managerRoles()
{
    return ['ADMIN','SOUS_DIRECTEUR_OPERATIONS','DIRECTEUR'];
}

function out($x, $c = 200)
{
    http_response_code($c);
    echo json_encode($x, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function currentUser()
{
    return $_SESSION['user'] ?? null;
}
function csrfToken()
{
    return $_SESSION['csrf_token'] ?? '';
}
function requireCsrf()
{
    if (in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf_token'] ?? '');
        if (!hash_equals(csrfToken(), (string) $token))
            out(['ok' => false, 'message' => 'Jeton de sécurité invalide. Rechargez la page puis réessayez.'], 419);
    }
}
set_exception_handler(function (Throwable $e) {
    out(['ok' => false, 'message' => 'Erreur serveur. Vérifiez les journaux PHP.'], 500);
});
function need($roles = [])
{
    $u = currentUser();
    if (!$u)
        out(['ok' => false, 'message' => 'Session expirée'], 401);
    if ($roles && !in_array($u['role'], $roles, true))
        out(['ok' => false, 'message' => 'Accès refusé'], 403);
    return $u;
}
function post($k, $d = null)
{
    return $_POST[$k] ?? $d;
}
function normalizeDateTime($value)
{
    $value = trim((string) $value);
    if ($value === '')
        return null;
    $formats = ['Y-m-d\TH:i', 'Y-m-d\TH:i:s', 'Y-m-d H:i', 'Y-m-d H:i:s'];
    foreach ($formats as $format) {
        $dt = DateTime::createFromFormat($format, $value);
        $errors = DateTime::getLastErrors();
        $hasErrors = is_array($errors) && ($errors['warning_count'] > 0 || $errors['error_count'] > 0);
        if ($dt !== false && !$hasErrors)
            return $dt->format('Y-m-d H:i:s');
    }
    return null;
}
function parseCoordinatePair($value)
{
    $value = trim((string) $value);
    if ($value === '') return null;
    $value = str_replace([';', '|'], ',', $value);
    if (!preg_match('/^\s*(-?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(-?(?:\d+(?:\.\d+)?|\.\d+))\s*$/', $value, $m)) return null;
    $lat=(float)$m[1]; $lng=(float)$m[2];
    if($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) return null;
    return ['lat'=>$lat,'lng'=>$lng];
}
function geoDistanceMeters(float $lat1,float $lng1,float $lat2,float $lng2): float
{
    $R=6371000.0; $p1=deg2rad($lat1); $p2=deg2rad($lat2); $dp=deg2rad($lat2-$lat1); $dl=deg2rad($lng2-$lng1);
    $x=sin($dp/2)**2+cos($p1)*cos($p2)*sin($dl/2)**2;
    return 2*$R*asin(min(1,sqrt($x)));
}
function geoLineCoordinates($geom): array
{
    if(is_string($geom)) $geom=json_decode($geom,true);
    if(!is_array($geom)) return [];
    if(($geom['type']??'')==='Feature') $geom=$geom['geometry']??null;
    if(!is_array($geom)||($geom['type']??'')!=='LineString') return [];
    $coords=$geom['coordinates']??[];
    return is_array($coords)&&count($coords)>=2?$coords:[];
}
function projectPointToDrain(array $point,array $coords): ?array
{
    $best=null; $cum=0.0;
    for($i=1,$n=count($coords);$i<$n;$i++){
        $a=$coords[$i-1];$b=$coords[$i]; if(!isset($a[0],$a[1],$b[0],$b[1])) continue;
        $lng1=(float)$a[0];$lat1=(float)$a[1];$lng2=(float)$b[0];$lat2=(float)$b[1];
        $meanLat=deg2rad(($lat1+$lat2+$point['lat'])/3.0);
        $mx=6371000.0*cos($meanLat)*deg2rad($lng2-$lng1); $my=6371000.0*deg2rad($lat2-$lat1);
        $px=6371000.0*cos($meanLat)*deg2rad($point['lng']-$lng1); $py=6371000.0*deg2rad($point['lat']-$lat1);
        $den=$mx*$mx+$my*$my; $t=$den>0?(($px*$mx+$py*$my)/$den):0; $t=max(0,min(1,$t));
        $plat=$lat1+($lat2-$lat1)*$t; $plng=$lng1+($lng2-$lng1)*$t; $d=geoDistanceMeters($point['lat'],$point['lng'],$plat,$plng);
        $seg=geoDistanceMeters($lat1,$lng1,$lat2,$lng2); $along=$cum+$seg*$t;
        if($best===null||$d<$best['distance_to_drain_m']) $best=['lat'=>$plat,'lng'=>$plng,'distance_m'=>$along,'distance_to_drain_m'=>$d];
        $cum+=$seg;
    }
    return $best;
}
function mergedDrainSegmentIntervals(array $rows): array
{
    $iv=[];
    foreach($rows as $r){
        $a=(float)$r['distance_depart_m'];
        $b=(float)$r['distance_arrivee_m'];
        if($b<$a)[$a,$b]=[$b,$a];
        if($b>$a)$iv[]=[$a,$b];
    }
    if(!$iv)return [];
    usort($iv,fn($x,$y)=>$x[0]<=>$y[0]);
    $merged=[];
    $start=$iv[0][0]; $end=$iv[0][1];
    foreach(array_slice($iv,1) as $x){
        if($x[0]<=$end){
            $end=max($end,$x[1]);
        }else{
            $merged[]=[$start,$end];
            $start=$x[0]; $end=$x[1];
        }
    }
    $merged[]=[$start,$end];
    return $merged;
}
function mergeDrainSegmentIntervals(array $rows): float
{
    $sum=0.0;
    foreach(mergedDrainSegmentIntervals($rows) as $x) $sum += max(0,$x[1]-$x[0]);
    return $sum;
}
function skippedDrainSegmentLength(array $rows): float
{
    $merged=mergedDrainSegmentIntervals($rows);
    if(count($merged)<2)return 0.0;
    $sum=0.0;
    for($i=1;$i<count($merged);$i++) $sum += max(0,$merged[$i][0]-$merged[$i-1][1]);
    return $sum;
}
function saveWorkSegmentForIntervention(int $interventionId,int $userId,string $coordDepart,string $coordArrivee): array
{
    global $pdo; $depart=parseCoordinatePair($coordDepart);$arrivee=parseCoordinatePair($coordArrivee);
    if(!$depart||!$arrivee)throw new Exception('Les coordonnées de début et de fin doivent être au format latitude, longitude.');
    $q=$pdo->prepare('SELECT i.id,i.drain_id,d.geom_json,d.lineaire_m,d.direction_travaux FROM intervention i JOIN drain d ON d.id=i.drain_id WHERE i.id=? LIMIT 1');$q->execute([$interventionId]);$i=$q->fetch();
    if(!$i)throw new Exception('Intervention introuvable.'); $coords=geoLineCoordinates($i['geom_json']); if(!$coords)throw new Exception('Le drain associé ne possède pas de tracé cartographique exploitable.');
    // Les distances stockées suivent exactement le sens d'affichage du drain.
    if(($i['direction_travaux']??'A_VERS_B')==='B_VERS_A') $coords=array_reverse($coords);
    $p1=projectPointToDrain($depart,$coords);$p2=projectPointToDrain($arrivee,$coords);if(!$p1||!$p2)throw new Exception('Impossible de recaler les coordonnées sur le tracé du drain.');
    $start=min($p1['distance_m'],$p2['distance_m']);$end=max($p1['distance_m'],$p2['distance_m']);$length=max(0,$end-$start);
    $q=$pdo->prepare('INSERT INTO intervention_travail_segment(intervention_id,drain_id,coord_depart_approx_lat,coord_depart_approx_lng,coord_arrivee_approx_lat,coord_arrivee_approx_lng,point_depart_lat,point_depart_lng,point_arrivee_lat,point_arrivee_lng,distance_depart_m,distance_arrivee_m,longueur_executee_m,mis_a_jour_par) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE drain_id=VALUES(drain_id),coord_depart_approx_lat=VALUES(coord_depart_approx_lat),coord_depart_approx_lng=VALUES(coord_depart_approx_lng),coord_arrivee_approx_lat=VALUES(coord_arrivee_approx_lat),coord_arrivee_approx_lng=VALUES(coord_arrivee_approx_lng),point_depart_lat=VALUES(point_depart_lat),point_depart_lng=VALUES(point_depart_lng),point_arrivee_lat=VALUES(point_arrivee_lat),point_arrivee_lng=VALUES(point_arrivee_lng),distance_depart_m=VALUES(distance_depart_m),distance_arrivee_m=VALUES(distance_arrivee_m),longueur_executee_m=VALUES(longueur_executee_m),mis_a_jour_par=VALUES(mis_a_jour_par)');
    $q->execute([$interventionId,$i['drain_id'],$depart['lat'],$depart['lng'],$arrivee['lat'],$arrivee['lng'],$p1['lat'],$p1['lng'],$p2['lat'],$p2['lng'],$start,$end,$length,$userId]);
    $q=$pdo->prepare('SELECT distance_depart_m,distance_arrivee_m FROM intervention_travail_segment WHERE drain_id=?');
    $q->execute([(int)$i['drain_id']]);
    $segmentRows=$q->fetchAll();
    $executed=mergeDrainSegmentIntervals($segmentRows);
    $skipped=skippedDrainSegmentLength($segmentRows);
    $total=(float)$i['lineaire_m'];
    if($total>0){
        $executed=min($executed,$total);
        $skipped=min($skipped,max(0,$total-$executed));
    }
    $av=$total>0?min(100,round((($executed+$skipped)/$total)*100,2)):0;
    $state=$av>=100?'TERMINE':'EN_COURS';
    $pdo->prepare('UPDATE drain SET lineaire_execute_m=?,lineaire_saute_m=?,avancement_pct=?,etat_travail=? WHERE id=?')->execute([$executed,$skipped,$av,$state,(int)$i['drain_id']]);
    return ['drain_id'=>(int)$i['drain_id'],'start_m'=>$start,'end_m'=>$end,'length_m'=>$length,'snapped_start'=>[$p1['lat'],$p1['lng']],'snapped_end'=>[$p2['lat'],$p2['lng']],'approx_start'=>[$depart['lat'],$depart['lng']],'approx_end'=>[$arrivee['lat'],$arrivee['lng']],'snap_error_start_m'=>$p1['distance_to_drain_m'],'snap_error_end_m'=>$p2['distance_to_drain_m']];
}
function safeName($name)
{
    $name = preg_replace('/[^A-Za-z0-9._-]+/u', '_', basename($name));
    return trim($name, '._-') ?: 'fichier';
}
function setting($key, $default = null)
{
    global $pdo;
    $s = $pdo->prepare('SELECT valeur FROM parametre_global WHERE cle=?');
    $s->execute([$key]);
    $r = $s->fetch();
    return $r ? $r['valeur'] : $default;
}

function auditDrain($drainId, $action, $userId, $old = null, $new = null, $comment = null)
{
    global $pdo;
    $q = $pdo->prepare('INSERT INTO drain_modification_log(drain_id,action,utilisateur_id,ancienne_valeur,nouvelle_valeur,commentaire) VALUES(?,?,?,?,?,?)');
    $q->execute([$drainId, $action, $userId, $old === null ? null : json_encode($old, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $new === null ? null : json_encode($new, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $comment]);
}
function drainAuditSnapshot($id)
{
    global $pdo;
    $q = $pdo->prepare('SELECT id,code,nom,arrondissement,type_drain,lineaire_m,observation,etat,criticite_hydraulique,exposition_urbaine,equipement_sensible,reseau_strategique,difficulte_curage,avancement_pct,etat_travail,lineaire_execute_m,lineaire_saute_m,direction_travaux,lineaire_restant_m,score_priorite,priorite,geom_json,source_kml,unite_inspection_id,created_at,updated_at FROM drain WHERE id=?');
    $q->execute([(int) $id]);
    return $q->fetch() ?: null;
}
function saveFile($file, $folder, $allowed, $maxBytes)
{
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE)
        return null;
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name']))
        throw new Exception('Téléversement invalide.');
    if ($file['error'] !== UPLOAD_ERR_OK)
        throw new Exception('Échec du téléversement de ' . ($file['name'] ?? 'fichier'));
    if ((int) $file['size'] > $maxBytes)
        throw new Exception('Fichier trop volumineux : ' . ($file['name'] ?? ''));
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!isset($allowed[$mime]))
        throw new Exception('Type de fichier non autorisé : ' . ($file['name'] ?? ''));
    $root = dirname(__DIR__) . '/uploads/' . $folder;
    if (!is_dir($root) && !mkdir($root, 0775, true))
        throw new Exception('Impossible de créer le dossier uploads.');
    $name = date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '_' . safeName($file['name']);
    $dest = $root . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $dest))
        throw new Exception('Impossible de sauvegarder le fichier.');
    return ['name' => $file['name'], 'path' => 'uploads/' . $folder . '/' . $name, 'mime' => $mime, 'size' => (int) $file['size'], 'type' => $allowed[$mime]];
}
function releaseMemberIfFree($uid)
{
    global $pdo;
    $s = $pdo->prepare("SELECT COUNT(*) FROM intervention_membre im JOIN intervention i ON i.id=im.intervention_id WHERE im.utilisateur_id=? AND i.mission_autorisee=1 AND i.statut IN('PLANIFIEE','EN_COURS','EN_RETARD')");
    $s->execute([$uid]);
    if ((int) $s->fetchColumn() === 0)
        $pdo->prepare("UPDATE utilisateur SET disponibilite='DISPONIBLE' WHERE id=? AND statut='ACTIF'")->execute([$uid]);
}
function canSubmitUnitReport(array $u, ?int $interventionId, string $type): bool
{
    global $pdo;
    if ($u['role'] !== 'CHEF_UNITE')
        return false;
    $unitType = $type === 'INSPECTION' ? 'INSPECTION' : 'ENTRETIEN';
    if ($interventionId) {
        $q = $pdo->prepare('SELECT un.id FROM intervention i JOIN unite un ON un.id=i.unite_id WHERE i.id=? AND un.chef_unite_id=? AND un.actif=1 AND un.type_unite=? LIMIT 1');
        $q->execute([$interventionId, $u['id'], $unitType]);
        return (bool) $q->fetchColumn();
    }
    $q = $pdo->prepare('SELECT id FROM unite WHERE chef_unite_id=? AND actif=1 AND type_unite=? LIMIT 1');
    $q->execute([$u['id'], $unitType]);
    return (bool) $q->fetchColumn();
}
function saveReport($u, $interventionId, $type, $title)
{
    global $pdo;
    $unit = null;
    if ($interventionId) {
        $s = $pdo->prepare('SELECT unite_id FROM intervention WHERE id=?');
        $s->execute([$interventionId]);
        $unit = $s->fetchColumn();
    }
    if (!$unit) {
        $unitType = $type === 'INSPECTION' ? 'INSPECTION' : 'ENTRETIEN';
        $s = $pdo->prepare('SELECT id FROM unite WHERE type_unite=? ORDER BY id LIMIT 1');
        $s->execute([$unitType]);
        $unit = $s->fetchColumn();
    }
    $s = $pdo->prepare('INSERT INTO rapport(intervention_id,auteur_id,unite_id,titre,type_rapport,commentaire) VALUES(?,?,?,?,?,?)');
    $s->execute([$interventionId ?: null, $u['id'], $unit, $title, $type, post('report_commentaire', '')]);
    $rid = (int) $pdo->lastInsertId();
    $maxR = (int) setting('max_report_mb', '15') * 1024 * 1024;
    $maxV = (int) setting('max_video_mb', '50') * 1024 * 1024;
    $maxI = (int) setting('max_images', '3');
    if (isset($_FILES['rapport']) && $_FILES['rapport']['error'] !== UPLOAD_ERR_NO_FILE) {
        $x = saveFile($_FILES['rapport'], 'rapports/' . $rid, ['application/pdf' => 'RAPPORT', 'application/msword' => 'RAPPORT', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'RAPPORT'], $maxR);
        $pdo->prepare('INSERT INTO rapport_fichier(rapport_id,type_fichier,nom_fichier,chemin,mime_type,taille_octets) VALUES(?,?,?,?,?,?)')->execute([$rid, $x['type'], $x['name'], $x['path'], $x['mime'], $x['size']]);
    }
    if (isset($_FILES['images']) && is_array($_FILES['images']['name'])) {
        if (count(array_filter($_FILES['images']['name'])) > $maxI)
            throw new Exception('Maximum ' . $maxI . ' images.');
        foreach ($_FILES['images']['name'] as $i => $nm) {
            if (!$nm)
                continue;
            $one = ['name' => $_FILES['images']['name'][$i], 'tmp_name' => $_FILES['images']['tmp_name'][$i], 'error' => $_FILES['images']['error'][$i], 'size' => $_FILES['images']['size'][$i]];
            $x = saveFile($one, 'rapports/' . $rid, ['image/jpeg' => 'IMAGE', 'image/png' => 'IMAGE', 'image/webp' => 'IMAGE', 'image/gif' => 'IMAGE'], $maxR);
            $pdo->prepare('INSERT INTO rapport_fichier(rapport_id,type_fichier,nom_fichier,chemin,mime_type,taille_octets) VALUES(?,?,?,?,?,?)')->execute([$rid, $x['type'], $x['name'], $x['path'], $x['mime'], $x['size']]);
        }
    }
    if (isset($_FILES['video'])) {
        $x = saveFile($_FILES['video'], 'rapports/' . $rid, ['video/mp4' => 'VIDEO', 'video/webm' => 'VIDEO', 'video/quicktime' => 'VIDEO'], $maxV);
        if ($x)
            $pdo->prepare('INSERT INTO rapport_fichier(rapport_id,type_fichier,nom_fichier,chemin,mime_type,taille_octets) VALUES(?,?,?,?,?,?)')->execute([$rid, $x['type'], $x['name'], $x['path'], $x['mime'], $x['size']]);
    }
    return $rid;
}
$a = $_GET['action'] ?? $_POST['action'] ?? '';
if (!in_array($a, ['register', 'login', 'me', ''], true))
    requireCsrf();

if ($a === 'save_recovery_question') {
    $u = need();
    $q = trim((string) post('question', ''));
    $r = trim((string) post('reponse', ''));
    if ($q === '' || $r === '')
        out(['ok' => false, 'message' => 'Question et réponse obligatoires.'], 400);
    $hash = password_hash(mb_strtolower($r), PASSWORD_DEFAULT);
    $st = $pdo->prepare('INSERT INTO recuperation_mot_de_passe(utilisateur_id,question,reponse_hash) VALUES(?,?,?) ON DUPLICATE KEY UPDATE question=VALUES(question),reponse_hash=VALUES(reponse_hash)');
    $st->execute([$u['id'], $q, $hash]);
    out(['ok' => true]);
}
if ($a === 'recovery_question') {
    $ident = strtolower(trim((string) ($_GET['email'] ?? post('email', ''))));
    if (!filter_var($ident, FILTER_VALIDATE_EMAIL))
        out(['ok' => false, 'message' => 'Email invalide.'], 400);
    $st = $pdo->prepare("SELECT r.question FROM utilisateur u JOIN recuperation_mot_de_passe r ON r.utilisateur_id=u.id WHERE LOWER(u.email)=? AND u.statut='ACTIF' LIMIT 1");
    $st->execute([$ident]);
    $row = $st->fetch();
    if (!$row)
        out(['ok' => false, 'message' => 'Aucune question de récupération disponible.'], 404);
    out(['ok' => true, 'question' => $row['question']]);
}
if ($a === 'recover_password') {
    $ident = strtolower(trim((string) post('email', '')));
    $answer = trim((string) post('reponse', ''));
    $new = (string) post('nouveau_mot_de_passe', '');
    if (!filter_var($ident, FILTER_VALIDATE_EMAIL) || $answer === '' || strlen($new) < 8)
        out(['ok' => false, 'message' => 'Données de récupération invalides.'], 400);
    $ipHash = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . '|2RC');
    $st = $pdo->prepare("SELECT COUNT(*) FROM recuperation_tentative WHERE (identifiant=? OR ip_hash=?) AND date_tentative>=DATE_SUB(NOW(),INTERVAL 15 MINUTE)");
    $st->execute([$ident, $ipHash]);
    if ((int) $st->fetchColumn() >= 5)
        out(['ok' => false, 'message' => 'Trop de tentatives. Réessayez plus tard.'], 429);
    $st = $pdo->prepare("SELECT u.id,r.reponse_hash FROM utilisateur u JOIN recuperation_mot_de_passe r ON r.utilisateur_id=u.id WHERE LOWER(u.email)=? AND u.statut='ACTIF' LIMIT 1");
    $st->execute([$ident]);
    $row = $st->fetch();
    $ok = $row && password_verify(mb_strtolower($answer), $row['reponse_hash']);
    $pdo->prepare('INSERT INTO recuperation_tentative(identifiant,ip_hash,succes) VALUES(?,?,?)')->execute([$ident, $ipHash, $ok ? 1 : 0]);
    if (!$ok)
        out(['ok' => false, 'message' => 'Réponse incorrecte.'], 403);
    $pdo->prepare('UPDATE utilisateur SET mot_de_passe=? WHERE id=?')->execute([password_hash($new, PASSWORD_DEFAULT), $row['id']]);
    out(['ok' => true, 'message' => 'Mot de passe réinitialisé.']);
}
if ($a === 'register') {
    $nom = trim((string) post('nom', ''));
    $prenom = trim((string) post('prenom', ''));
    $email = strtolower(trim((string) post('email', '')));
    $password = (string) post('password', '');
    $telephone = trim((string) post('telephone', ''));
    $typeCompte = post('type_compte', 'AGENT_2RC');
    $matricule = trim((string) post('matricule', '')) ?: null;
    if (!in_array($typeCompte, ['AGENT_2RC', 'STAGIAIRE', 'TEMPORAIRE'], true))
        $typeCompte = 'AGENT_2RC';
    if ($nom === '' || $prenom === '' || $telephone === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8)
        out(['ok' => false, 'message' => 'Nom, prénom, téléphone, email valide et mot de passe d’au moins 8 caractères requis.'], 400);
    if ($typeCompte === 'AGENT_2RC' && !preg_match('/^[0-9]{4}$/', (string) $matricule))
        out(['ok' => false, 'message' => 'Pour un Agent 2RC, le matricule doit contenir exactement 4 chiffres.'], 400);
    if ($typeCompte !== 'AGENT_2RC')
        $matricule = null;
    try {
        $s = $pdo->prepare('SELECT id FROM utilisateur WHERE LOWER(email)=LOWER(?) LIMIT 1');
        $s->execute([$email]);
        if ($s->fetch())
            out(['ok' => false, 'message' => 'Cet email est déjà enregistré.'], 409);
        if ($matricule !== null) {
            $s = $pdo->prepare('SELECT id FROM utilisateur WHERE matricule=? LIMIT 1');
            $s->execute([$matricule]);
            if ($s->fetch())
                out(['ok' => false, 'message' => 'Ce matricule est déjà enregistré.'], 409);
        }
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $s = $pdo->prepare("INSERT INTO utilisateur(matricule,nom,prenom,email,mot_de_passe,role,poste,niveau_accreditation,telephone,statut,type_compte) VALUES(?,?,?,?,?,'AGENT',NULL,'NIVEAU_1',?,'INACTIF',?)");
        $s->execute([$matricule, $nom, $prenom, $email, $hash, $telephone, $typeCompte]);
        notifyRoles(managerRoles(), 'ACCREDITATION', 'Nouveau compte créé : ' . $prenom . ' ' . $nom . '.', null, null);
        out(['ok' => true, 'message' => 'Demande créée. Votre compte est maintenant visible dans Accréditations et restera bloqué jusqu’à son activation par le responsable.']);
    } catch (PDOException $e) {
        out(['ok' => false, 'message' => 'Création impossible : la structure de la base de données ne correspond pas à cette version. Exécutez la migration SQL fournie puis réessayez.'], 500);
    }
}
if ($a === 'login') {
    $s = $pdo->prepare('SELECT * FROM utilisateur WHERE email=?');
    $s->execute([trim(post('email', ''))]);
    $u = $s->fetch();
    if (!$u)
        out(['ok' => false, 'message' => 'Identifiants incorrects'], 401);
    $valid = password_verify((string) post('password', ''), $u['mot_de_passe']) || hash_equals((string) $u['mot_de_passe'], (string) post('password', ''));
    if (!$valid)
        out(['ok' => false, 'message' => 'Identifiants incorrects'], 401);
    if ($u['statut'] !== 'ACTIF')
        out(['ok' => false, 'message' => 'Compte en attente d’activation/accréditation par un responsable.'], 403);
    if (!password_verify((string) post('password', ''), $u['mot_de_passe'])) {
        $h = password_hash((string) post('password', ''), PASSWORD_DEFAULT);
        $pdo->prepare('UPDATE utilisateur SET mot_de_passe=? WHERE id=?')->execute([$h, $u['id']]);
        $u['mot_de_passe'] = $h;
    }
    session_regenerate_id(true);
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    unset($u['mot_de_passe']);
    $_SESSION['user'] = $u;
    out(['ok' => true, 'user' => $u, 'csrf_token' => csrfToken()]);
}
if ($a === 'me') {
    if (!currentUser())
        out(['ok' => false], 401);
    out(['ok' => true, 'user' => currentUser(), 'csrf_token' => csrfToken()]);
}
if ($a === 'logout') {
    $_SESSION = [];
    session_destroy();
    out(['ok' => true]);
}


if ($a === 'vehicle_options') {
    $u = need(['ADMIN','SOUS_DIRECTEUR_OPERATIONS','DIRECTEUR']);
    $units = $pdo->query("SELECT id,code,nom FROM unite WHERE actif=1 ORDER BY nom")->fetchAll();
    $drains = $pdo->query("SELECT id,code,nom FROM drain ORDER BY nom")->fetchAll();
    out(['statuses'=>['DISPONIBLE','MAINTENANCE','EN_SERVICE','HORS_SERVICE'],'units'=>$units,'drains'=>$drains]);
}
if ($a === 'update_vehicle') {
    $u = need(['ADMIN']);
    $id = (int)post('id',0);
    $status = post('statut','');
    $unitId = (int)post('unite_id',0);
    $locationType = post('lieu_type','DRAIN');
    $other = trim(post('lieu_autre',''));
    if (!$id || !in_array($status,['DISPONIBLE','MAINTENANCE','EN_SERVICE','HORS_SERVICE'],true))
        out(['ok'=>false,'message'=>'Véhicule ou statut invalide.'],400);
    $q=$pdo->prepare("SELECT id,nom FROM unite WHERE id=? AND actif=1");
    $q->execute([$unitId]); $unit=$q->fetch();
    if (!$unit) out(['ok'=>false,'message'=>'Veuillez sélectionner une unité valide.'],400);
    $lieu='';
    if ($locationType==='AUTRE') {
        if ($other==='') out(['ok'=>false,'message'=>'Veuillez préciser le lieu.'],400);
        $lieu=$other;
    } else {
        $drainId=(int)post('drain_id',0);
        $q=$pdo->prepare("SELECT id,code,nom FROM drain WHERE id=?");
        $q->execute([$drainId]); $dr=$q->fetch();
        if (!$dr) out(['ok'=>false,'message'=>'Veuillez sélectionner un drain.'],400);
        $lieu='Drain ' . $dr['code'] . ' — ' . $dr['nom'];
    }
    $pdo->prepare('UPDATE vehicule SET statut=?,unite=?,lieu_operation=? WHERE id=?')->execute([$status,$unit['nom'],$lieu,$id]);
    out(['ok'=>true]);
}

if ($a === 'dashboard') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    // Compatibilité avec les bases déjà installées : certaines peuvent ne pas encore
    // avoir les colonnes/tableaux ajoutés par les dernières migrations.
    $tableExists = function ($table) use ($pdo) {
        $q = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?");
        $q->execute([$table]);
        return (bool) $q->fetchColumn();
    };
    $columnExists = function ($table, $column) use ($pdo) {
        $q = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?");
        $q->execute([$table, $column]);
        return (bool) $q->fetchColumn();
    };
    $hasLog = $tableExists('drain_modification_log');
    $hasUpdated = $columnExists('drain', 'updated_at');
    $hasSaute = $columnExists('drain', 'lineaire_saute_m');
    $hasExecute = $columnExists('drain', 'lineaire_execute_m');
    $executeExpr = $hasExecute ? 'COALESCE(SUM(lineaire_execute_m),0)' : '0';
    $sauteExpr = $hasSaute ? 'COALESCE(SUM(lineaire_saute_m),0)' : '0';
    $realiseExpr = $hasExecute && $hasSaute ? 'COALESCE(SUM(lineaire_execute_m)+SUM(lineaire_saute_m),0)' : ($hasExecute ? $executeExpr : ($hasSaute ? $sauteExpr : '0'));
    $drains = $pdo->query("SELECT COUNT(*) total, COALESCE(SUM(lineaire_m),0) lineaire_total, COALESCE(SUM(CASE WHEN type_drain='BETONNE' THEN lineaire_m ELSE 0 END),0) lineaire_beton, COALESCE(SUM(CASE WHEN type_drain='NATUREL' THEN lineaire_m ELSE 0 END),0) lineaire_naturel, $executeExpr lineaire_execute, $sauteExpr lineaire_saute, $realiseExpr lineaire_realise FROM drain")->fetch();
    $last = '';
    if ($hasLog) {
        $last = $pdo->query("SELECT MAX(date_modification) FROM drain_modification_log")->fetchColumn() ?: '';
    }
    if ($hasUpdated) {
        $last2 = $pdo->query("SELECT MAX(updated_at) FROM drain")->fetchColumn() ?: '';
        if (!$last || ($last2 && strtotime($last2) > strtotime($last)))
            $last = $last2;
    }
    if (!$last) {
        $last = $pdo->query("SELECT MAX(created_at) FROM drain")->fetchColumn() ?: null;
    }
    out([
        'interventions' => $pdo->query("SELECT COUNT(*) total,SUM(statut='EN_COURS') encours,SUM(statut='EN_RETARD') retard,SUM(statut='PLANIFIEE' AND date_prevue BETWEEN NOW() AND DATE_ADD(NOW(),INTERVAL 7 DAY)) semaine,SUM(mission_autorisee=0) sans_visa FROM intervention")->fetch(),
        'drains' => $drains,
        'vehicules' => $pdo->query('SELECT * FROM vehicule ORDER BY statut,designation')->fetchAll(),
        'progress' => $pdo->query("SELECT COALESCE(AVG(avancement_pct),0) p FROM drain")->fetch()['p'],
        'last_drain_modification' => $last,
        'retard' => $pdo->query("SELECT COALESCE(ROUND(100*SUM(statut='EN_RETARD')/NULLIF(COUNT(*),0),1),0) p FROM intervention")->fetch()['p'],
        'reports' => $pdo->query("SELECT COUNT(*) total,SUM(statut='ENVOYE') nouveaux FROM rapport")->fetch(),
        'pending_visas' => $pdo->query("SELECT COUNT(*) total FROM intervention WHERE mission_autorisee=0")->fetch()['total']
    ]);
}
if ($a === 'materials') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    out($pdo->query('SELECT id,designation,categorie,unite,stock_disponible,seuil_minimum FROM stock WHERE stock_disponible>0 ORDER BY designation')->fetchAll());
}
if ($a === 'drains') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'INSPECTEUR', 'DIRECTEUR', 'CHEF_UNITE']);
    out($pdo->query("SELECT * FROM drain ORDER BY FIELD(priorite,'P1','P2','P3','P4'), CASE WHEN etat_travail IN('SUSPENDU','NON_PROGRAMME','REPORTE') THEN 1 ELSE 0 END, score_priorite DESC, nom")->fetchAll());
}
if ($a === 'drain_history') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'CHEF_UNITE']);
    $id = (int) ($_GET['drain_id'] ?? 0);
    $sql = "SELECT l.*,d.code,d.nom,CONCAT(COALESCE(u.prenom,''),' ',COALESCE(u.nom,'')) utilisateur_nom,u.role FROM drain_modification_log l LEFT JOIN drain d ON d.id=l.drain_id LEFT JOIN utilisateur u ON u.id=l.utilisateur_id";
    if ($id) {
        $q = $pdo->prepare($sql . ' WHERE l.drain_id=? ORDER BY l.date_modification DESC,l.id DESC');
        $q->execute([$id]);
        out($q->fetchAll());
    }
    $rows = $pdo->query($sql . ' ORDER BY l.date_modification DESC,l.id DESC')->fetchAll();
    foreach ($rows as &$r) {
        if ($r['action'] === 'SUPPRESSION' && (!$r['code'] || !$r['nom'])) {
            $snap = json_decode((string) $r['ancienne_valeur'], true);
            if (is_array($snap)) {
                $r['code'] = $snap['code'] ?? $r['code'];
                $r['nom'] = $snap['nom'] ?? $r['nom'];
                $r['arrondissement'] = $snap['arrondissement'] ?? null;
                $r['type_drain'] = $snap['type_drain'] ?? null;
            }
        }
    }
    unset($r);
    out($rows);
}
if ($a === 'drain_trash') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    $rows = $pdo->query("SELECT l.*,CONCAT(COALESCE(u.prenom,''),' ',COALESCE(u.nom,'')) utilisateur_nom,u.role FROM drain_modification_log l LEFT JOIN utilisateur u ON u.id=l.utilisateur_id WHERE l.action='SUPPRESSION' AND NOT EXISTS (SELECT 1 FROM drain_modification_log r WHERE r.action='RESTAURATION' AND r.commentaire=CONCAT('Restauration de la suppression #',l.id)) ORDER BY l.date_modification DESC,l.id DESC")->fetchAll();
    foreach ($rows as &$r) {
        $snap = json_decode((string) $r['ancienne_valeur'], true);
        $r['drain_snapshot'] = is_array($snap) ? $snap : [];
        $r['code'] = $r['drain_snapshot']['code'] ?? '—';
        $r['nom'] = $r['drain_snapshot']['nom'] ?? 'Drain supprimé';
        $r['arrondissement'] = $r['drain_snapshot']['arrondissement'] ?? '—';
        $r['type_drain'] = $r['drain_snapshot']['type_drain'] ?? '—';
        $r['lineaire_m'] = $r['drain_snapshot']['lineaire_m'] ?? 0;
    }
    unset($r);
    out($rows);
}
if ($a === 'restore_drain') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS']);
    $logId = (int) post('log_id', 0);
    if (!$logId)
        out(['ok' => false, 'message' => 'Suppression introuvable.'], 400);
    $q = $pdo->prepare("SELECT * FROM drain_modification_log WHERE id=? AND action='SUPPRESSION'");
    $q->execute([$logId]);
    $log = $q->fetch();
    if (!$log)
        out(['ok' => false, 'message' => 'Suppression introuvable.'], 404);
    $q = $pdo->prepare("SELECT 1 FROM drain_modification_log WHERE action='RESTAURATION' AND commentaire=? LIMIT 1");
    $q->execute(['Restauration de la suppression #' . $logId]);
    if ($q->fetchColumn())
        out(['ok' => false, 'message' => 'Ce drain a déjà été restauré.'], 409);
    $snap = json_decode((string) $log['ancienne_valeur'], true);
    if (!is_array($snap))
        out(['ok' => false, 'message' => 'Instantané de restauration indisponible.'], 409);
    $code = trim((string) ($snap['code'] ?? ''));
    $nom = trim((string) ($snap['nom'] ?? ''));
    if ($code === '' || $nom === '')
        out(['ok' => false, 'message' => 'Les données nécessaires à la restauration sont incomplètes.'], 409);
    $q = $pdo->prepare('SELECT id FROM drain WHERE code=? LIMIT 1');
    $q->execute([$code]);
    if ($q->fetch())
        out(['ok' => false, 'message' => 'Un drain avec le code ' . $code . ' existe déjà.'], 409);
    $fields = [$code, $nom, $snap['arrondissement'] ?? '', $snap['type_drain'] ?? 'NATUREL', $snap['lineaire_m'] ?? 0, $snap['observation'] ?? null, $snap['etat'] ?? 'DEBIT_CORRECT', $snap['criticite_hydraulique'] ?? 1, $snap['exposition_urbaine'] ?? 1, $snap['equipement_sensible'] ?? 1, $snap['reseau_strategique'] ?? 1, $snap['difficulte_curage'] ?? 1, $snap['avancement_pct'] ?? 0, $snap['etat_travail'] ?? 'NON_PROGRAMME', $snap['lineaire_execute_m'] ?? 0, $snap['lineaire_saute_m'] ?? 0, $snap['direction_travaux'] ?? 'A_VERS_B', $snap['geom_json'] ?? null, $snap['source_kml'] ?? null, $snap['unite_inspection_id'] ?? null];
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare('INSERT INTO drain(code,nom,arrondissement,type_drain,lineaire_m,observation,etat,criticite_hydraulique,exposition_urbaine,equipement_sensible,reseau_strategique,difficulte_curage,avancement_pct,etat_travail,lineaire_execute_m,lineaire_saute_m,direction_travaux,geom_json,source_kml,unite_inspection_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $s->execute($fields);
        $newId = (int) $pdo->lastInsertId();
        $newSnap = drainAuditSnapshot($newId);
        auditDrain($newId, 'RESTAURATION', $u['id'], null, $newSnap, 'Restauration de la suppression #' . $logId);
        $pdo->prepare('UPDATE drain_modification_log SET drain_id=? WHERE id=?')->execute([$newId, $logId]);
        $pdo->commit();
        out(['ok' => true, 'id' => $newId, 'message' => 'Drain restauré avec succès.']);
    } catch (Throwable $e) {
        if ($pdo->inTransaction())
            $pdo->rollBack();
        out(['ok' => false, 'message' => 'Restauration impossible : ' . $e->getMessage()], 400);
    }
}
if ($a === 'interventions') {
    $u = need([
        'ADMIN',
        'SOUS_DIRECTEUR_OPERATIONS',
        'DIRECTEUR',
        'CHEF_UNITE'
    ]);

    /*
     * Pour le Chef d'unité :
     * on ne retourne que les interventions :
     * - de son unité ;
     * - autorisées ;
     * - actives.
     *
     * Le contrôle est fait côté serveur.
     */
    if ($u['role'] === 'CHEF_UNITE') {

        $q = $pdo->prepare("
            SELECT
                i.*,
                d.code,
                d.nom AS drain_nom,
                d.arrondissement,
                un.nom AS unite_nom,
                e.nom AS equipe_nom,
                CONCAT(
                    COALESCE(cu.prenom,''),
                    ' ',
                    COALESCE(cu.nom,'')
                ) AS auteur
            FROM intervention i

            INNER JOIN drain d
                ON d.id=i.drain_id

            INNER JOIN unite un
                ON un.id=i.unite_id
                AND un.chef_unite_id=?
                AND un.actif=1

            LEFT JOIN equipe e
                ON e.id=i.equipe_id

            LEFT JOIN utilisateur cu
                ON cu.id=i.cree_par

            WHERE i.mission_autorisee=1 AND COALESCE(i.archivee,0)=0

            ORDER BY
                i.date_prevue DESC,
                i.id DESC
        ");

        $q->execute([$u['id']]);

        $rows = $q->fetchAll();

    } else {

        $rows = $pdo->query("
            SELECT
                i.*,
                d.code,
                d.nom AS drain_nom,
                d.arrondissement,
                un.nom AS unite_nom,
                e.nom AS equipe_nom,
                CONCAT(
                    COALESCE(u.prenom,''),
                    ' ',
                    COALESCE(u.nom,'')
                ) AS auteur
            FROM intervention i

            JOIN drain d
                ON d.id=i.drain_id

            LEFT JOIN equipe e
                ON e.id=i.equipe_id

            LEFT JOIN unite un
                ON un.id=i.unite_id

            LEFT JOIN utilisateur u
                ON u.id=i.cree_par

            WHERE COALESCE(i.archivee,0)=0

            ORDER BY i.date_prevue DESC
        ")->fetchAll();
    }

    /*
     * Matériels associés aux interventions.
     */
    foreach ($rows as &$r) {

        $s = $pdo->prepare("
            SELECT
                s.id,
                s.designation,
                s.categorie,
                im.quantite,
                s.unite
            FROM intervention_material im

            JOIN stock s
                ON s.id=im.stock_id

            WHERE im.intervention_id=?

            ORDER BY s.designation
        ");

        $s->execute([(int) $r['id']]);

        $r['materials'] = $s->fetchAll();
    }

    unset($r);

    out($rows);
}

if ($a === 'archives') {
    $u = need(['ADMIN','SOUS_DIRECTEUR_OPERATIONS','DIRECTEUR','CHEF_UNITE']);
    if ($u['role']==='CHEF_UNITE') {
        $q=$pdo->prepare("SELECT i.*,d.code,d.nom AS drain_nom,d.arrondissement,un.nom AS unite_nom,r.id AS rapport_id,r.titre AS rapport_titre,r.date_envoi AS rapport_date
            FROM intervention i JOIN drain d ON d.id=i.drain_id LEFT JOIN unite un ON un.id=i.unite_id
            LEFT JOIN rapport r ON r.intervention_id=i.id
            WHERE i.archivee=1 AND un.chef_unite_id=? ORDER BY r.date_envoi DESC,i.id DESC");
        $q->execute([$u['id']]);
        out($q->fetchAll());
    }
    $rows=$pdo->query("SELECT i.*,d.code,d.nom AS drain_nom,d.arrondissement,un.nom AS unite_nom,
            CONCAT(COALESCE(u.prenom,''),' ',COALESCE(u.nom,'')) AS auteur,
            r.id AS rapport_id,r.titre AS rapport_titre,r.date_envoi AS rapport_date
            FROM intervention i JOIN drain d ON d.id=i.drain_id
            LEFT JOIN unite un ON un.id=i.unite_id LEFT JOIN utilisateur u ON u.id=i.cree_par
            LEFT JOIN rapport r ON r.intervention_id=i.id
            WHERE i.archivee=1 ORDER BY r.date_envoi DESC,i.id DESC")->fetchAll();
    out($rows);
}

if ($a === 'units_for_intervention') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    $type = post('type', $_GET['type'] ?? 'ENTRETIEN');
    $s = $pdo->prepare("SELECT un.id,un.code,un.nom,un.type_unite,COUNT(ou.utilisateur_id) total_membres,SUM(u.statut='ACTIF' AND u.disponibilite='DISPONIBLE') disponibles FROM unite un LEFT JOIN agent_unite ou ON ou.unite_id=un.id LEFT JOIN utilisateur u ON u.id=ou.utilisateur_id WHERE un.type_unite=? AND un.actif=1 GROUP BY un.id ORDER BY un.nom");
    $s->execute([$type]);
    out($s->fetchAll());
}
if ($a === 'unit_available_members') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    $uid = (int) ($_GET['unite_id'] ?? post('unite_id', 0));
    $s = $pdo->prepare("SELECT u.id,u.matricule,u.nom,u.prenom,u.email,u.disponibilite,u.poste FROM utilisateur u JOIN agent_unite ou ON ou.utilisateur_id=u.id WHERE ou.unite_id=? AND u.statut='ACTIF' ORDER BY u.nom,u.prenom");
    $s->execute([$uid]);
    out($s->fetchAll());
}
if ($a === 'map') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'INSPECTEUR', 'AGENT', 'DIRECTEUR', 'CHEF_UNITE']);
    // Les tronçons sont des données SIG globales : aucun filtrage par chef d'unité.
    // Toute personne ayant accès à la Carte SIG voit donc l'ensemble des tronçons validés.
    $segments = $pdo->query("SELECT id,intervention_id,drain_id,point_depart_lat,point_depart_lng,point_arrivee_lat,point_arrivee_lng,distance_depart_m,distance_arrivee_m,longueur_executee_m,created_at,updated_at FROM intervention_travail_segment ORDER BY drain_id,distance_depart_m,id")->fetchAll();
    out([
        'settings' => ['provider' => setting('map_provider', 'SATELLITE'), 'lat' => (float) setting('map_lat', '4.05'), 'lng' => (float) setting('map_lng', '9.70'), 'zoom' => (int) setting('map_zoom', '12')],
        'drains' => $pdo->query('SELECT id,code,nom,arrondissement,type_drain,etat,etat_travail,avancement_pct,lineaire_m,lineaire_execute_m,lineaire_saute_m,lineaire_restant_m,direction_travaux,observation,score_priorite,priorite,geom_json FROM drain WHERE geom_json IS NOT NULL AND geom_json<>\'\'')->fetchAll(),
        'interventions' => $pdo->query("SELECT i.id,i.reference,i.drain_id,i.type_intervention,i.date_prevue,i.statut,i.mission_autorisee,i.visa_chef_service,i.visa_sous_directeur,i.geom_json,d.nom drain_nom,d.arrondissement FROM intervention i JOIN drain d ON d.id=i.drain_id WHERE i.geom_json IS NOT NULL AND i.geom_json<>'' ORDER BY i.date_prevue")->fetchAll(),
        'work_segments' => $segments
    ]);
}
if ($a === 'create_intervention') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    $pdo->beginTransaction();
    try {
        $type = post('type_intervention', 'AUTRE');
        // Les trois dates restent optionnelles. Si elles sont fournies, elles sont normalisées.
        $datePrevue = normalizeDateTime(post('date_prevue'));
        $dateDebut = normalizeDateTime(post('date_debut'));
        $dateFin = normalizeDateTime(post('date_fin_prevue'));
        if (post('date_prevue', '') !== '' && !$datePrevue)
            throw new Exception('Date prévue invalide.');
        if (post('date_debut', '') !== '' && !$dateDebut)
            throw new Exception('Date de début invalide.');
        if (post('date_fin_prevue', '') !== '' && !$dateFin)
            throw new Exception('Date de fin prévue invalide.');
        if ($dateDebut && $dateFin && strtotime($dateFin) < strtotime($dateDebut))
            throw new Exception('La fin prévue ne peut pas être antérieure au début.');
        $drain = (int) post('drain_id', 0);
        $unit = (int) post('unite_id', 0);
        if (!$drain)
            throw new Exception('Veuillez sélectionner un drain.');
        if (!$unit)
            throw new Exception('Veuillez sélectionner une unité.');
        $unitType = $type === 'INSPECTION' ? 'INSPECTION' : 'ENTRETIEN';
        $q = $pdo->prepare("SELECT id FROM unite WHERE id=? AND type_unite=?");
        $q->execute([$unit, $unitType]);
        if (!$q->fetch())
            throw new Exception('L’unité sélectionnée ne correspond pas au type d’intervention.');
        $q = $pdo->prepare("SELECT u.id FROM utilisateur u JOIN agent_unite ou ON ou.utilisateur_id=u.id WHERE ou.unite_id=? AND u.statut='ACTIF' AND u.disponibilite='DISPONIBLE'");
        $q->execute([$unit]);
        $members = array_map('intval', $q->fetchAll(PDO::FETCH_COLUMN));
        if (!$members)
            throw new Exception('Aucun membre disponible dans cette unité.');
        $ref = 'INT-' . date('YmdHis') . '-' . random_int(100, 999);
        $s = $pdo->prepare('INSERT INTO intervention(reference,drain_id,equipe_id,unite_id,type_intervention,date_prevue,date_debut,date_fin_prevue,description,geom_json,cree_par,visa_chef_service,visa_sous_directeur,visa_directeur,visa_directeur_par,visa_directeur_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $chef = 0;
        $sdo = 0;
        $dir = $u['role'] === 'DIRECTEUR' ? 1 : 0;
        $dirPar = $dir ? $u['id'] : null;
        $dirAt = $dir ? date('Y-m-d H:i:s') : null;
        $s->execute([$ref, $drain, null, $unit, $type, $datePrevue, $dateDebut, $dateFin, post('description', ''), post('geom_json') ?: null, $u['id'], $chef, $sdo, $dir, $dirPar, $dirAt]);
        $iid = (int) $pdo->lastInsertId();
        foreach ($members as $m)
            $pdo->prepare('INSERT INTO intervention_membre(intervention_id,utilisateur_id) VALUES(?,?)')->execute([$iid, $m]);
        if ($type === 'INSPECTION')
            $pdo->prepare('UPDATE drain SET unite_inspection_id=? WHERE id=?')->execute([$unit, $drain]);
        $materials = json_decode(post('materials', '[]'), true);
        if (!is_array($materials))
            $materials = [];
        $ms = $pdo->prepare('SELECT id,stock_disponible FROM stock WHERE id=?');
        $mi = $pdo->prepare('INSERT INTO intervention_material(intervention_id,stock_id,quantite) VALUES(?,?,?)');
        foreach ($materials as $m) {
            $sid = (int) ($m['id'] ?? 0);
            $qty = (float) ($m['qty'] ?? 0);
            if (!$sid || $qty <= 0)
                continue;
            if (abs($qty - round($qty)) > 0.000001)
                throw new Exception('La quantité du matériel doit être un nombre entier.');
            $qty = (int) round($qty);
            $ms->execute([$sid]);
            $stock = $ms->fetch();
            if (!$stock || $qty > $stock['stock_disponible'])
                throw new Exception('Stock insuffisant pour un matériel sélectionné.');
            $mi->execute([$iid, $sid, $qty]);
        }
        $maxImages = (int) setting('max_images', '3');
        $maxVideo = (int) setting('max_video_mb', '50') * 1024 * 1024;
        $imgs = $_FILES['images'] ?? null;
        if ($imgs && is_array($imgs['name'])) {
            if (count(array_filter($imgs['name'])) > $maxImages)
                throw new Exception('Maximum ' . $maxImages . ' images.');
            foreach ($imgs['name'] as $idx => $nm) {
                if (!$nm)
                    continue;
                $one = ['name' => $imgs['name'][$idx], 'tmp_name' => $imgs['tmp_name'][$idx], 'error' => $imgs['error'][$idx], 'size' => $imgs['size'][$idx]];
                $x = saveFile($one, 'interventions/' . $iid, ['image/jpeg' => 'IMAGE', 'image/png' => 'IMAGE', 'image/webp' => 'IMAGE', 'image/gif' => 'IMAGE'], $maxVideo);
                $pdo->prepare('INSERT INTO intervention_media(intervention_id,type_media,nom_fichier,chemin,mime_type,taille_octets) VALUES(?,?,?,?,?,?)')->execute([$iid, $x['type'], $x['name'], $x['path'], $x['mime'], $x['size']]);
            }
        }
        if (isset($_FILES['video'])) {
            $x = saveFile($_FILES['video'], 'interventions/' . $iid, ['video/mp4' => 'VIDEO', 'video/webm' => 'VIDEO', 'video/quicktime' => 'VIDEO'], $maxVideo);
            if ($x)
                $pdo->prepare('INSERT INTO intervention_media(intervention_id,type_media,nom_fichier,chemin,mime_type,taille_octets) VALUES(?,?,?,?,?,?)')->execute([$iid, $x['type'], $x['name'], $x['path'], $x['mime'], $x['size']]);
        }
        $pdo->commit();
        $recipients = $pdo->prepare("SELECT chef_unite_id FROM unite WHERE id=? AND chef_unite_id IS NOT NULL");
        $recipients->execute([$unit]);
        $chefIds = array_map('intval',$recipients->fetchAll(PDO::FETCH_COLUMN));
        notifyRoles(managerRoles(), 'INTERVENTION', 'Nouvelle intervention créée : ' . $ref . '.', $iid, $u['id']);
        notifySpecificUsers($chefIds, 'INTERVENTION', 'Nouvelle intervention affectée à votre unité : ' . $ref . '.', $iid, $u['id']);
        out(['ok' => true, 'reference' => $ref, 'intervention_id' => $iid, 'mission_autorisee' => ($dir || ($dir && $chef && $sdo))]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction())
            $pdo->rollBack();
        out(['ok' => false, 'message' => $e->getMessage()], 400);
    }
}
if ($a === 'visa_intervention') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    $id = (int) post('id', 0);
    $type = post('visa', '');
    if (!$id || !in_array($type, ['CHEF_SERVICE', 'SOUS_DIRECTEUR', 'DIRECTEUR'], true))
        out(['ok' => false, 'message' => 'Visa invalide.'], 400);
    if ($type === 'CHEF_SERVICE' && $u['role'] !== 'ADMIN')
        out(['ok' => false, 'message' => 'Seul le chef de service peut apposer ce visa.'], 403);
    if ($type === 'SOUS_DIRECTEUR' && $u['role'] !== 'SOUS_DIRECTEUR_OPERATIONS')
        out(['ok' => false, 'message' => 'Seul le sous-directeur des opérations peut apposer ce visa.'], 403);
    if ($type === 'DIRECTEUR' && $u['role'] !== 'DIRECTEUR')
        out(['ok' => false, 'message' => 'Seul le Directeur peut apposer ce visa.'], 403);
    $pdo->beginTransaction();
    try {
        $q = $pdo->prepare('SELECT visa_chef_service,visa_sous_directeur FROM intervention WHERE id=? FOR UPDATE');
        $q->execute([$id]);
        $iv = $q->fetch();
        if (!$iv)
            throw new Exception('Intervention introuvable.');
        if ($type === 'CHEF_SERVICE')
            $pdo->prepare('UPDATE intervention SET visa_chef_service=1,visa_chef_service_par=?,visa_chef_service_at=NOW() WHERE id=?')->execute([$u['id'], $id]);
        elseif ($type === 'SOUS_DIRECTEUR')
            $pdo->prepare('UPDATE intervention SET visa_sous_directeur=1,visa_sous_directeur_par=?,visa_sous_directeur_at=NOW() WHERE id=?')->execute([$u['id'], $id]);
        else
            $pdo->prepare('UPDATE intervention SET visa_directeur=1,visa_directeur_par=?,visa_directeur_at=NOW() WHERE id=?')->execute([$u['id'], $id]);
        $q = $pdo->prepare('SELECT i.mission_autorisee,im.utilisateur_id FROM intervention i JOIN intervention_membre im ON im.intervention_id=i.id WHERE i.id=?');
        $q->execute([$id]);
        $rows = $q->fetchAll();
        $authorized = !empty($rows) && ((int) $rows[0]['mission_autorisee'] === 1);
        if ($authorized) {
            $ids = array_map('intval', array_column($rows, 'utilisateur_id'));
            $place = implode(',', array_fill(0, count($ids), '?'));
            $q = $pdo->prepare("SELECT id FROM utilisateur WHERE id IN ($place) AND statut='ACTIF' AND disponibilite='DISPONIBLE' FOR UPDATE");
            $q->execute($ids);
            $available = array_map('intval', $q->fetchAll(PDO::FETCH_COLUMN));
            if (count($available) !== count($ids))
                throw new Exception('Un ou plusieurs membres de cette unité ne sont plus disponibles.');
            $q = $pdo->prepare("UPDATE utilisateur SET disponibilite='OCCUPE' WHERE id IN ($place)");
            $q->execute($ids);
        }
        $pdo->commit();
        out(['ok' => true, 'mission_autorisee' => $authorized]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction())
            $pdo->rollBack();
        out(['ok' => false, 'message' => $e->getMessage()], 409);
    }
}
if ($a === 'create_drain' || $a === 'update_drain') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS']);
    $id = (int) post('id', 0);
    $total = max(0, (float) (post('lineaire_m') ?: 0));
    $exec = max(0, (float) (post('lineaire_execute_m') ?: 0));
    $saute = max(0, (float) (post('lineaire_saute_m') ?: 0));
    if ($total > 0 && ($exec + $saute) > $total)
        out(['ok' => false, 'message' => 'Le linéaire exécuté + linéaire sauté ne peut pas dépasser le linéaire total.'], 400);
    $av = $total > 0 ? min(100, round((($exec + $saute) / $total) * 100, 2)) : 0;
    $state = post('etat_travail', 'NON_PROGRAMME');
    if ($av >= 100)
        $state = 'TERMINE';
    elseif ($state === 'TERMINE' && $av < 100)
        $state = 'EN_COURS';
    $etat = post('etat', 'DEBIT_CORRECT');
    if (!in_array($etat, ['DEBIT_CORRECT', 'SATURATION_PARTIELLE', 'SATURATION_TOTAL'], true))
        $etat = 'DEBIT_CORRECT';
    $direction = post('direction_travaux', 'A_VERS_B');
    if (!in_array($direction, ['A_VERS_B', 'B_VERS_A'], true))
        $direction = 'A_VERS_B';
    $fields = [post('code'), post('nom'), post('arrondissement'), post('type_drain', 'NATUREL'), $total ?: null, post('observation', ''), $etat, post('criticite_hydraulique', 1), post('exposition_urbaine', 1), post('equipement_sensible', 1), post('reseau_strategique', 1), post('difficulte_curage', 1), $av, $state, $exec, $saute, $direction, post('geom_json') ?: null, post('source_kml') ?: null];
    if ($a === 'create_drain') {
        $s = $pdo->prepare('INSERT INTO drain(code,nom,arrondissement,type_drain,lineaire_m,observation,etat,criticite_hydraulique,exposition_urbaine,equipement_sensible,reseau_strategique,difficulte_curage,avancement_pct,etat_travail,lineaire_execute_m,lineaire_saute_m,direction_travaux,geom_json,source_kml) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $s->execute($fields);
        $newSnap = drainAuditSnapshot((int) $pdo->lastInsertId());
        auditDrain((int) $newSnap['id'], 'CREATION', $u['id'], null, $newSnap, 'Création du drain');
        notifyRoles(managerRoles(), 'JOURNAL', 'Modification du journal : création du drain ' . $newSnap['code'] . '.', null, $u['id']);
    } else {
        $oldSnap = drainAuditSnapshot($id);
        if (!$oldSnap)
            out(['ok' => false, 'message' => 'Drain introuvable.'], 404);
        $fields[] = $id;
        $s = $pdo->prepare('UPDATE drain SET code=?,nom=?,arrondissement=?,type_drain=?,lineaire_m=?,observation=?,etat=?,criticite_hydraulique=?,exposition_urbaine=?,equipement_sensible=?,reseau_strategique=?,difficulte_curage=?,avancement_pct=?,etat_travail=?,lineaire_execute_m=?,lineaire_saute_m=?,direction_travaux=?,geom_json=?,source_kml=? WHERE id=?');
        $s->execute($fields);
        $newSnap = drainAuditSnapshot($id);
        auditDrain($id, 'MODIFICATION', $u['id'], $oldSnap, $newSnap, 'Modification des données du drain');
        notifyRoles(managerRoles(), 'JOURNAL', 'Modification du journal : drain ' . $newSnap['code'] . '.', $id, $u['id']);
    }
    out(['ok' => true, 'avancement_pct' => $av, 'etat_travail' => $state]);
}
if ($a === 'delete_drain') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS']);
    $u = currentUser();
    $id = (int) post('id', 0);
    $snap = drainAuditSnapshot($id);
    if (!$snap)
        out(['ok' => false, 'message' => 'Drain introuvable.'], 404);
    $s = $pdo->prepare('SELECT COUNT(*) FROM intervention WHERE drain_id=?');
    $s->execute([$id]);
    if ((int) $s->fetchColumn() > 0)
        out(['ok' => false, 'message' => 'Impossible de supprimer ce drain : il possède des interventions liées.'], 409);
    auditDrain($id, 'SUPPRESSION', $u['id'], $snap, null, 'Suppression du drain');
    notifyRoles(managerRoles(), 'CORBEILLE', 'Drain supprimé : ' . $snap['code'] . '.', $id, $u['id']);
    notifyRoles(managerRoles(), 'JOURNAL', 'Une modification a été enregistrée dans le journal.', $id, $u['id']);
    $pdo->prepare('DELETE FROM drain WHERE id=?')->execute([$id]);
    out(['ok' => true]);
}
if ($a === 'my_unit_drains') {
    $u = need(['AGENT', 'INSPECTEUR']);
    $unitType = $u['role'] === 'INSPECTEUR' ? 'INSPECTION' : 'ENTRETIEN';
    // Résolution robuste de l'unité : membership direct OU intervention déjà affectée à l'agent.
    $s = $pdo->prepare("SELECT un.id FROM unite un JOIN agent_unite au ON au.unite_id=un.id WHERE au.utilisateur_id=? AND un.type_unite=? AND un.actif=1 ORDER BY un.id LIMIT 1");
    $s->execute([$u['id'], $unitType]);
    $uid = $s->fetchColumn();
    if (!$uid) {
        $s = $pdo->prepare("SELECT i.unite_id FROM intervention i JOIN intervention_membre im ON im.intervention_id=i.id JOIN unite un ON un.id=i.unite_id WHERE im.utilisateur_id=? AND un.type_unite=? AND un.actif=1 ORDER BY i.id DESC LIMIT 1");
        $s->execute([$u['id'], $unitType]);
        $uid = $s->fetchColumn();
    }
    if (!$uid)
        out(['ok' => true, 'unit_id' => null, 'unit_type' => $unitType, 'drains' => []]);
    if ($unitType === 'INSPECTION') {
        // Tous les drains affectés à l'unité sont affichés, même si le visa n'est pas encore posé.
        $sql = "SELECT DISTINCT d.id,d.code,d.nom,d.arrondissement,d.lineaire_m,d.avancement_pct,d.etat,d.geom_json
        FROM drain d
        LEFT JOIN intervention i ON i.drain_id=d.id AND i.unite_id=?
        WHERE d.unite_inspection_id=? OR i.id IS NOT NULL
        ORDER BY d.nom";
        $q = $pdo->prepare($sql);
        $q->execute([(int) $uid, (int) $uid]);
    } else {
        $sql = "SELECT DISTINCT d.id,d.code,d.nom,d.arrondissement,d.lineaire_m,d.avancement_pct,d.etat,d.geom_json
        FROM drain d JOIN intervention i ON i.drain_id=d.id
        WHERE i.unite_id=? ORDER BY d.nom";
        $q = $pdo->prepare($sql);
        $q->execute([(int) $uid]);
    }
    out(['ok' => true, 'unit_id' => (int) $uid, 'unit_type' => $unitType, 'drains' => $q->fetchAll()]);
}
if ($a === 'unit_context') {
    $u = need(['AGENT']);
    $s = $pdo->prepare("SELECT un.id FROM unite un JOIN agent_unite au ON au.unite_id=un.id WHERE au.utilisateur_id=? AND un.type_unite='ENTRETIEN' AND un.actif=1 ORDER BY un.id LIMIT 1");
    $s->execute([$u['id']]);
    $uid = $s->fetchColumn();
    if (!$uid) {
        $s = $pdo->prepare("SELECT i.unite_id FROM intervention i JOIN intervention_membre im ON im.intervention_id=i.id JOIN unite un ON un.id=i.unite_id WHERE im.utilisateur_id=? AND un.type_unite='ENTRETIEN' AND un.actif=1 ORDER BY i.id DESC LIMIT 1");
        $s->execute([$u['id']]);
        $uid = $s->fetchColumn();
    }
    if (!$uid)
        out(['ok' => true, 'members' => [], 'drains' => [], 'todo' => 0, 'done' => 0]);
    $s = $pdo->prepare("SELECT DISTINCT CONCAT(u.prenom,' ',u.nom) FROM utilisateur u JOIN agent_unite au ON au.utilisateur_id=u.id WHERE au.unite_id=? ORDER BY u.nom");
    $s->execute([$uid]);
    $members = $s->fetchAll(PDO::FETCH_COLUMN);
    // La liste des drains de l'unité ne dépend pas du visa : l'affectation est visible dès que l'intervention porte cette unité.
    $s = $pdo->prepare("SELECT DISTINCT d.id,d.code,d.nom,d.arrondissement,d.lineaire_m,d.avancement_pct,d.etat,d.geom_json FROM drain d JOIN intervention i ON i.drain_id=d.id WHERE i.unite_id=? ORDER BY d.nom");
    $s->execute([$uid]);
    $drains = $s->fetchAll();
    $s = $pdo->prepare("SELECT COUNT(DISTINCT i.id) FROM intervention i JOIN intervention_membre im ON im.intervention_id=i.id WHERE im.utilisateur_id=? AND i.mission_autorisee=1 AND i.statut NOT IN('TERMINEE','ANNULEE')");
    $s->execute([$u['id']]);
    $todo = (int) $s->fetchColumn();
    $s = $pdo->prepare("SELECT COUNT(DISTINCT i.id) FROM intervention i JOIN intervention_membre im ON im.intervention_id=i.id WHERE im.utilisateur_id=? AND i.statut='TERMINEE'");
    $s->execute([$u['id']]);
    $done = (int) $s->fetchColumn();
    out(['ok' => true, 'members' => $members, 'drains' => $drains, 'todo' => $todo, 'done' => $done]);
}
if ($a === 'inspection_context') {
    $u = need(['INSPECTEUR']);
    $s = $pdo->prepare("SELECT un.id FROM unite un JOIN agent_unite au ON au.unite_id=un.id WHERE au.utilisateur_id=? AND un.type_unite='INSPECTION' AND un.actif=1 ORDER BY un.id LIMIT 1");
    $s->execute([$u['id']]);
    $uid = $s->fetchColumn();
    if (!$uid) {
        $s = $pdo->prepare("SELECT i.unite_id FROM intervention i JOIN intervention_membre im ON im.intervention_id=i.id JOIN unite un ON un.id=i.unite_id WHERE im.utilisateur_id=? AND un.type_unite='INSPECTION' AND un.actif=1 ORDER BY i.id DESC LIMIT 1");
        $s->execute([$u['id']]);
        $uid = $s->fetchColumn();
    }
    if (!$uid)
        out(['ok' => true, 'members' => [], 'to_observe' => [], 'observed' => 0]);
    $s = $pdo->prepare("SELECT DISTINCT CONCAT(u.prenom,' ',u.nom) nom FROM utilisateur u JOIN agent_unite au ON au.utilisateur_id=u.id WHERE au.unite_id=? ORDER BY u.nom");
    $s->execute([$uid]);
    $members = $s->fetchAll(PDO::FETCH_COLUMN);
    $s = $pdo->prepare("SELECT DISTINCT d.id,d.code,d.nom,d.arrondissement,d.lineaire_m,d.avancement_pct,d.etat,d.geom_json FROM drain d LEFT JOIN intervention i ON i.drain_id=d.id AND i.unite_id=? WHERE (d.unite_inspection_id=? OR i.id IS NOT NULL) AND NOT EXISTS(SELECT 1 FROM inspection x WHERE x.drain_id=d.id AND x.inspecteur_id=?) ORDER BY d.nom");
    $s->execute([$uid, $uid, $u['id']]);
    $to = $s->fetchAll();
    $s = $pdo->prepare("SELECT COUNT(*) FROM inspection x JOIN drain d ON d.id=x.drain_id WHERE d.unite_inspection_id=? AND x.inspecteur_id=?");
    $s->execute([$uid, $u['id']]);
    out(['ok' => true, 'members' => $members, 'to_observe' => $to, 'observed' => (int) $s->fetchColumn()]);
}
if ($a === 'inspection_save') {
    $u = need(['CHEF_UNITE', 'INSPECTEUR']);
    if ($u['role'] !== 'CHEF_UNITE')
        out(['ok' => false, 'message' => 'Seul le chef d’unité d’inspection peut envoyer un rapport.'], 403);
    $pdo->beginTransaction();
    try {
        $drain = (int) post('drain_id', 0);
        $chk = $pdo->prepare("SELECT 1 FROM drain d LEFT JOIN intervention i ON i.drain_id=d.id AND i.mission_autorisee=1 LEFT JOIN unite ui ON ui.id=COALESCE(d.unite_inspection_id,i.unite_id) LEFT JOIN agent_unite ou ON ou.unite_id=ui.id AND ou.utilisateur_id=? WHERE d.id=? AND ((ui.chef_unite_id=? AND ui.type_unite='INSPECTION') OR ou.utilisateur_id IS NOT NULL) AND NOT EXISTS(SELECT 1 FROM inspection x WHERE x.drain_id=d.id AND x.inspecteur_id=?)");
        $chk->execute([$u['id'], $drain, $u['id']]);
        if (!$chk->fetch())
            throw new Exception('Ce drain n’est pas affecté à votre unité ou a déjà été observé.');
        $s = $pdo->prepare('INSERT INTO inspection(drain_id,inspecteur_id,etat_degradation,criticite_hydraulique,exposition_urbaine,equipement_sensible,reseau_strategique,difficulte_curage,observations) VALUES(?,?,?,?,?,?,?,?,?)');
        $s->execute([$drain, $u['id'], post('etat_degradation', 'BON'), post('criticite_hydraulique', 1), post('exposition_urbaine', 1), post('equipement_sensible', 1), post('reseau_strategique', 1), post('difficulte_curage', 1), post('observations', '')]);
        $map = ['CRITIQUE' => 'SATURATION_TOTAL', 'FORT' => 'SATURATION_PARTIELLE', 'MOYEN' => 'SATURATION_PARTIELLE', 'LEGER' => 'DEBIT_CORRECT', 'BON' => 'DEBIT_CORRECT'];
        $oldDrainSnap = drainAuditSnapshot($drain);
        $pdo->prepare('UPDATE drain SET etat=?,criticite_hydraulique=?,exposition_urbaine=?,equipement_sensible=?,reseau_strategique=?,difficulte_curage=?,observation=? WHERE id=?')->execute([$map[post('etat_degradation', 'BON')] ?? 'A_SURVEILLER', post('criticite_hydraulique', 1), post('exposition_urbaine', 1), post('equipement_sensible', 1), post('reseau_strategique', 1), post('difficulte_curage', 1), post('observations', ''), $drain]);
        $newDrainSnap = drainAuditSnapshot($drain);
        auditDrain($drain, 'INSPECTION', $u['id'], $oldDrainSnap, $newDrainSnap, 'Mise à jour du drain suite à une inspection');
        $iid = (int) post('intervention_id', 0);
        if ($iid) {
            $v = $pdo->prepare('SELECT 1 FROM intervention_membre im JOIN intervention i ON i.id=im.intervention_id WHERE im.intervention_id=? AND im.utilisateur_id=? AND i.mission_autorisee=1');
            $v->execute([$iid, $u['id']]);
            if (!$v->fetch())
                throw new Exception('Intervention non autorisée ou non affectée.');
        }
        $rid = saveReport($u, $iid ?: null, 'INSPECTION', post('titre', 'Rapport inspection'));
        if ($iid) {
            // Un rapport lié à une intervention clôture cette intervention et la place dans l'Archive.
            $pdo->prepare('UPDATE intervention SET archivee=1, statut=? WHERE id=?')->execute(['TERMINEE', $iid]);
            foreach ($pdo->query('SELECT utilisateur_id FROM intervention_membre WHERE intervention_id=' . (int) $iid)->fetchAll(PDO::FETCH_COLUMN) as $uid)
                releaseMemberIfFree($uid);
            notifyRoles(managerRoles(), 'RAPPORT', 'Nouveau rapport reçu : ' . post('titre', 'Rapport d’intervention') . '.', $rid, $u['id']);
        }
        $pdo->commit();
        out(['ok' => true, 'report_id' => $rid]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction())
            $pdo->rollBack();
        out(['ok' => false, 'message' => $e->getMessage()], 400);
    }
}
if ($a === 'submit_report') {
    $u = need(['CHEF_UNITE']);
    $iid = (int) post('intervention_id', 0);
    $i = null;
    if ($iid) {
        $s = $pdo->prepare("SELECT i.* FROM intervention i LEFT JOIN intervention_membre im ON im.intervention_id=i.id AND im.utilisateur_id=? LEFT JOIN unite un ON un.id=i.unite_id WHERE i.id=? AND (im.utilisateur_id IS NOT NULL OR ? IN ('ADMIN','SOUS_DIRECTEUR_OPERATIONS','DIRECTEUR') OR ( ?='CHEF_UNITE' AND un.chef_unite_id=?)) AND i.mission_autorisee=1");
        $s->execute([$u['id'], $iid, $u['role'], $u['role'], $u['id']]);
        $i = $s->fetch();
        if (!$i)
            out(['ok' => false, 'message' => 'Cette intervention n’est pas autorisée ou accessible à cet utilisateur.'], 403);
    }
    try {
        $pdo->beginTransaction();
        $type = post('type_rapport', 'ENTRETIEN');
        if (!in_array($type, ['INSPECTION', 'ENTRETIEN', 'INTERVENTION'], true))
            $type = 'INTERVENTION';
        if ($type === 'INTERVENTION')
            $type = $i && $i['type_intervention'] === 'INSPECTION' ? 'INSPECTION' : 'ENTRETIEN';
        if (!canSubmitUnitReport($u, $iid ?: null, $type))
            throw new Exception('Seul le chef de l’unité concernée peut envoyer ce rapport.');
        $segmentInfo = null;
        if ($iid && $type !== 'INSPECTION') {
            $coordDepart = trim((string)post('coordonnees_depart', ''));
            $coordArrivee = trim((string)post('coordonnees_arrivee', ''));
            if ($coordDepart === '' || $coordArrivee === '')
                throw new Exception('Les coordonnées de début et de fin des travaux sont obligatoires pour une intervention d’entretien.');
            $segmentInfo = saveWorkSegmentForIntervention($iid, (int)$u['id'], $coordDepart, $coordArrivee);
        }
        $title = post('titre', $i ? 'Rapport ' . $i['reference'] : 'Rapport ' . $type);
        $rid = saveReport($u, $iid ?: null, $type, $title);
        if ($i) {
            // Le rapport transmis clôture le cycle de l'intervention : elle quitte la page active et reste consultable dans Archive.
            $pdo->prepare('UPDATE intervention SET archivee=1, statut=? WHERE id=?')->execute(['TERMINEE', $iid]);
            notifyRoles(managerRoles(), 'RAPPORT', 'Nouveau rapport reçu : ' . $title . '.', $rid, $u['id']);
            $m = $pdo->prepare('SELECT utilisateur_id FROM intervention_membre WHERE intervention_id=?');
            $m->execute([$iid]);
            foreach ($m->fetchAll(PDO::FETCH_COLUMN) as $uid)
                releaseMemberIfFree($uid);
        }
        $pdo->commit();
        out(['ok' => true, 'report_id' => $rid, 'work_segment' => $segmentInfo]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction())
            $pdo->rollBack();
        out(['ok' => false, 'message' => 'Envoi du rapport impossible : ' . $e->getMessage()], 400);
    }
}
if ($a === 'my_work') {
    $u = need(['INSPECTEUR', 'AGENT']);
    $s = $pdo->prepare("SELECT i.*,d.nom drain_nom,d.arrondissement,d.geom_json drain_geom,e.nom equipe_nom FROM intervention i JOIN intervention_membre im ON im.intervention_id=i.id JOIN drain d ON d.id=i.drain_id LEFT JOIN equipe e ON e.id=i.equipe_id WHERE im.utilisateur_id=? AND i.mission_autorisee=1 ORDER BY i.date_prevue");
    $s->execute([$u['id']]);
    out($s->fetchAll());
}
if ($a === 'update_progress') {
    $u = need(['AGENT', 'INSPECTEUR']);
    $id = (int) post('id', 0);
    $status = post('status', '');
    $allowed = ['PLANIFIEE', 'EN_COURS', 'TERMINEE', 'EN_RETARD', 'ANNULEE'];
    if (!$id || !in_array($status, $allowed, true))
        out(['ok' => false, 'message' => 'Statut invalide.'], 400);
    $s = $pdo->prepare("SELECT i.id FROM intervention i JOIN intervention_membre im ON im.intervention_id=i.id WHERE i.id=? AND im.utilisateur_id=? AND i.mission_autorisee=1");
    $s->execute([$id, $u['id']]);
    if (!$s->fetch())
        out(['ok' => false, 'message' => 'Mission non autorisée ou non affectée.'], 403);
    $pdo->prepare("UPDATE intervention SET statut=?,date_debut=CASE WHEN ?='EN_COURS' AND date_debut IS NULL THEN NOW() ELSE date_debut END WHERE id=?")->execute([$status, $status, $id]);
    if (in_array($status, ['TERMINEE', 'ANNULEE'], true)) {
        foreach ($pdo->query('SELECT utilisateur_id FROM intervention_membre WHERE intervention_id=' . (int) $id)->fetchAll(PDO::FETCH_COLUMN) as $uid)
            releaseMemberIfFree($uid);
    }
    out(['ok' => true]);
}

if ($a === 'notification_counts') {
    $u = need([]);
    $q=$pdo->prepare("SELECT type,COUNT(*) n FROM notification WHERE utilisateur_id=? AND lu=0 GROUP BY type");
    $q->execute([$u['id']]);
    $map=['ACCREDITATION'=>0,'JOURNAL'=>0,'CORBEILLE'=>0,'RAPPORT'=>0,'UNITE'=>0,'INTERVENTION'=>0];
    foreach($q->fetchAll() as $r) if(isset($map[$r['type']])) $map[$r['type']]=(int)$r['n'];
    out($map);
}
if ($a === 'notification_read') {
    $u=need([]);
    $type=post('type','');
    $ref=post('reference_id',null);
    if (!in_array($type,['ACCREDITATION','JOURNAL','CORBEILLE','RAPPORT','UNITE','INTERVENTION'],true))
        out(['ok'=>false,'message'=>'Type de notification invalide.'],400);
    markNotificationTypeRead($u['id'],$type,$ref!==null && $ref!==''?(int)$ref:null);
    out(['ok'=>true]);
}

if ($a === 'reports') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'CHEF_UNITE', 'AGENT', 'INSPECTEUR']);
    $lvl = (int) str_replace('NIVEAU_', '', $u['niveau_accreditation'] ?? '1');
    if (in_array($u['role'], ['AGENT', 'INSPECTEUR'], true) && $lvl < 2)
        out(['ok' => false, 'message' => 'Cette page est disponible à partir du niveau 2.'], 403);
    $type = trim((string) ($_GET['type_rapport'] ?? $_POST['type_rapport'] ?? ''));
    $qtxt = trim((string) ($_GET['q'] ?? $_POST['q'] ?? ''));
    $where = [];
    $params = [];
    if (in_array($type, ['INSPECTION', 'ENTRETIEN', 'INTERVENTION'], true)) {
        $where[] = 'r.type_rapport=?';
        $params[] = $type;
    }
    if ($qtxt !== '') {
        $where[] = '(r.titre LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ? OR i.reference LIKE ? OR d.nom LIKE ?)';
        for ($z = 0; $z < 5; $z++)
            $params[] = '%' . $qtxt . '%';
    }
    $sql = "SELECT r.*,CONCAT(COALESCE(u.prenom,''),' ',COALESCE(u.nom,'')) auteur_nom,un.nom unite_nom,i.reference,d.nom drain_nom FROM rapport r LEFT JOIN utilisateur u ON u.id=r.auteur_id LEFT JOIN unite un ON un.id=r.unite_id LEFT JOIN intervention i ON i.id=r.intervention_id LEFT JOIN drain d ON d.id=i.drain_id" . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . " ORDER BY r.date_envoi DESC";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    out($st->fetchAll());
}
if ($a === 'report_detail') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'CHEF_UNITE', 'INSPECTEUR', 'AGENT']);
    $lvl = (int) str_replace('NIVEAU_', '', $u['niveau_accreditation'] ?? '1');
    if (in_array($u['role'], ['AGENT', 'INSPECTEUR'], true) && $lvl < 2)
        out(['ok' => false, 'message' => 'La consultation des rapports est disponible à partir du niveau 2.'], 403);
    $rid = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
    $st = $pdo->prepare("SELECT r.*,CONCAT(COALESCE(u.prenom,''),' ',COALESCE(u.nom,'')) auteur_nom,un.nom unite_nom,i.reference,i.type_intervention,i.statut intervention_statut,d.nom drain_nom,d.code drain_code,d.arrondissement FROM rapport r LEFT JOIN utilisateur u ON u.id=r.auteur_id LEFT JOIN unite un ON un.id=r.unite_id LEFT JOIN intervention i ON i.id=r.intervention_id LEFT JOIN drain d ON d.id=i.drain_id WHERE r.id=?");
    $st->execute([$rid]);
    $rep = $st->fetch();
    if (!$rep)
        out(['ok' => false, 'message' => 'Rapport introuvable.'], 404);
    $allowed = in_array($u['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true) || $rep['auteur_id'] == $u['id'];
    if (!$allowed && $u['role'] === 'CHEF_UNITE') {
        $q = $pdo->prepare('SELECT 1 FROM unite WHERE id=? AND chef_unite_id=?');
        $q->execute([$rep['unite_id'], $u['id']]);
        $allowed = (bool) $q->fetchColumn();
    }
    if (!$allowed && $rep['intervention_id']) {
        $st = $pdo->prepare('SELECT 1 FROM intervention_membre WHERE intervention_id=? AND utilisateur_id=?');
        $st->execute([$rep['intervention_id'], $u['id']]);
        $allowed = (bool) $st->fetchColumn();
    }
    if (!$allowed)
        out(['ok' => false, 'message' => 'Accès refusé.'], 403);
    if ($rep['statut'] === 'ENVOYE') {
        $pdo->prepare("UPDATE rapport SET statut='LU' WHERE id=?")->execute([$rid]);
        $rep['statut'] = 'LU';
    }
    markNotificationTypeRead($u['id'], 'RAPPORT', $rid);
    $st = $pdo->prepare('SELECT id,type_fichier,nom_fichier,mime_type,taille_octets,date_ajout FROM rapport_fichier WHERE rapport_id=? ORDER BY date_ajout');
    $st->execute([$rid]);
    $rep['fichiers'] = $st->fetchAll();
    out(['ok' => true, 'report' => $rep]);
}
if ($a === 'report_files') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'INSPECTEUR', 'AGENT']);
    $rid = (int) ($_GET['id'] ?? 0);
    $q = $pdo->prepare('SELECT r.auteur_id,r.intervention_id FROM rapport r WHERE r.id=?');
    $q->execute([$rid]);
    $rep = $q->fetch();
    if (!$rep)
        out(['ok' => false, 'message' => 'Rapport introuvable.'], 404);
    $allowed = in_array($u['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true) || $rep['auteur_id'] == $u['id'];
    if (!$allowed && $u['role'] === 'CHEF_UNITE') {
        $q = $pdo->prepare('SELECT 1 FROM unite WHERE id=? AND chef_unite_id=?');
        $q->execute([$rep['unite_id'], $u['id']]);
        $allowed = (bool) $q->fetchColumn();
    }
    if (!$allowed && $rep['intervention_id']) {
        $q = $pdo->prepare('SELECT 1 FROM intervention_membre WHERE intervention_id=? AND utilisateur_id=?');
        $q->execute([$rep['intervention_id'], $u['id']]);
        $allowed = (bool) $q->fetchColumn();
    }
    if (!$allowed)
        out(['ok' => false, 'message' => 'Accès refusé.'], 403);
    $q = $pdo->prepare('SELECT id,rapport_id,type_fichier,nom_fichier,mime_type,taille_octets,date_ajout FROM rapport_fichier WHERE rapport_id=? ORDER BY date_ajout');
    $q->execute([$rid]);
    out($q->fetchAll());
}
if ($a === 'report_status') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS']);
    $status = post('status', '');
    if (!in_array($status, ['ENVOYE', 'LU', 'TRAITE'], true))
        out(['ok' => false, 'message' => 'Statut de rapport invalide.'], 400);
    $pdo->prepare('UPDATE rapport SET statut=? WHERE id=?')->execute([$status, (int) post('id')]);
    out(['ok' => true]);
}
if ($a === 'materials_manage') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'HSE']);
    out($pdo->query("SELECT * FROM stock ORDER BY designation")->fetchAll());
}
if ($a === 'create_material') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'HSE']);
    $designation = trim(post('designation', ''));
    $cat = post('categorie', 'MATERIEL');
    $unit = trim(post('unite', 'unité'));
    $stock = (float) post('stock_disponible', 0);
    $min = (float) post('seuil_minimum', 0);
    if (!$designation || !$unit || !in_array($cat, ['MATERIEL', 'EPI', 'MATERIAU'], true) || $stock < 0 || $min < 0)
        out(['ok' => false, 'message' => 'Données de matériel invalides.'], 400);
    $q = $pdo->prepare('INSERT INTO stock(designation,categorie,unite,stock_disponible,seuil_minimum) VALUES(?,?,?,?,?)');
    $q->execute([$designation, $cat, $unit, $stock, $min]);
    out(['ok' => true]);
}
if ($a === 'delete_material') {
    need(['HSE']);
    $id = (int) post('id', 0);
    $s = $pdo->prepare('SELECT COUNT(*) FROM intervention_material WHERE stock_id=?');
    $s->execute([$id]);
    if ((int) $s->fetchColumn() > 0)
        out(['ok' => false, 'message' => 'Ce matériel est utilisé par une intervention et ne peut pas être supprimé.'], 409);
    $pdo->prepare('DELETE FROM stock WHERE id=?')->execute([$id]);
    out(['ok' => true]);
}
if ($a === 'settings') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    out($pdo->query('SELECT * FROM parametre_global ORDER BY cle')->fetchAll());
}
if ($a === 'save_settings') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    $data = json_decode(post('settings', '{}'), true);
    if (!is_array($data))
        out(['ok' => false, 'message' => 'Paramètres invalides.'], 400);
    $allowed = ['app_name', 'map_provider', 'map_lat', 'map_lng', 'map_zoom', 'max_images', 'max_video_mb', 'max_report_mb'];
    $s = $pdo->prepare('INSERT INTO parametre_global(cle,valeur,type_param,description) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE valeur=VALUES(valeur),type_param=VALUES(type_param),description=VALUES(description)');
    foreach ($data as $k => $v)
        if (in_array($k, $allowed, true))
            $s->execute([$k, (string) $v, in_array($k, ['map_lat', 'map_lng', 'map_zoom', 'max_images', 'max_video_mb', 'max_report_mb'], true) ? 'NUMBER' : 'TEXT', '']);
    out(['ok' => true]);
}
if ($a === 'units_read') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'CHEF_UNITE', 'AGENT', 'INSPECTEUR']);
    $lvl = (int) str_replace('NIVEAU_', '', $u['niveau_accreditation'] ?? '1');
    if (in_array($u['role'], ['AGENT', 'INSPECTEUR'], true) && $lvl < 3)
        out(['ok' => false, 'message' => 'La consultation des unités est disponible à partir du niveau 3.'], 403);
    $units = $pdo->query("SELECT un.*,CONCAT(COALESCE(cu.prenom,''),' ',COALESCE(cu.nom,'')) chef_nom,COUNT(ou.id) membres FROM unite un LEFT JOIN utilisateur cu ON cu.id=un.chef_unite_id LEFT JOIN agent_unite ou ON ou.unite_id=un.id WHERE un.actif=1 GROUP BY un.id ORDER BY un.nom")->fetchAll();
    out(['units' => $units, 'memberships' => $pdo->query('SELECT id,unite_id,utilisateur_id FROM agent_unite')->fetchAll(), 'workers' => $pdo->query("SELECT id,matricule,nom,prenom,email,role,poste,niveau_accreditation,disponibilite FROM utilisateur WHERE role IN('AGENT','INSPECTEUR') AND statut='ACTIF' ORDER BY nom,prenom")->fetchAll()]);
}
if ($a === 'units') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR', 'CHEF_UNITE']);
    $units = $pdo->query("SELECT un.*,CONCAT(COALESCE(cu.prenom,''),' ',COALESCE(cu.nom,'')) chef_nom,COUNT(ou.id) membres FROM unite un LEFT JOIN utilisateur cu ON cu.id=un.chef_unite_id LEFT JOIN agent_unite ou ON ou.unite_id=un.id WHERE un.actif=1 GROUP BY un.id ORDER BY un.nom")->fetchAll();
    out(['units' => $units, 'workers' => $pdo->query("SELECT id,matricule,nom,prenom,email,role,poste,niveau_accreditation,disponibilite FROM utilisateur WHERE role IN('AGENT','INSPECTEUR') AND statut='ACTIF' ORDER BY nom,prenom")->fetchAll(), 'memberships' => $pdo->query('SELECT id,unite_id,utilisateur_id FROM agent_unite')->fetchAll(), 'readonly' => in_array(currentUser()['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true)]);
}
if ($a === 'create_unit') {
    $u = need(['CHEF_UNITE']);
    $code = trim(post('code', ''));
    $nom = trim(post('nom', ''));
    $type = post('type_unite', '');
    if (!$code || !$nom || !in_array($type, ['ENTRETIEN', 'INSPECTION'], true))
        out(['ok' => false, 'message' => 'Code, nom et type d’unité sont obligatoires.'], 400);
    $q = $pdo->prepare('SELECT id FROM unite WHERE LOWER(code)=LOWER(?) OR LOWER(nom)=LOWER(?) LIMIT 1');
    $q->execute([$code, $nom]);
    if ($q->fetch())
        out(['ok' => false, 'message' => 'Cette unité existe déjà. Le code et le nom doivent être uniques.'], 409);
    $q = $pdo->prepare('SELECT id FROM unite WHERE chef_unite_id=? AND actif=1 LIMIT 1');
    $q->execute([$u['id']]);
    if ($q->fetch())
        out(['ok' => false, 'message' => 'Vous êtes déjà responsable d’une unité active.'], 409);
    $q = $pdo->prepare('INSERT INTO unite(code,nom,type_unite,description,chef_unite_id) VALUES(?,?,?,?,?)');
    $q->execute([$code, $nom, $type, post('description', ''), $u['id']]);
    $newUnitId=(int)$pdo->lastInsertId();
    notifyRoles(managerRoles(), 'UNITE', 'Nouvelle unité créée : ' . $nom . '.', $newUnitId, $u['id']);
    out(['ok' => true, 'id' => $newUnitId]);
}
if ($a === 'set_unit_members') {
    $u = need(['CHEF_UNITE']);
    $uid = (int) post('unite_id', 0);
    $decoded = json_decode(post('members', '[]'), true);
    $members = is_array($decoded) ? array_values(array_unique(array_filter(array_map('intval', $decoded)))) : [];
    $q = $pdo->prepare('SELECT type_unite FROM unite WHERE id=? AND actif=1 AND chef_unite_id=?');
    $q->execute([$uid, $u['id']]);
    if (!$q->fetchColumn())
        out(['ok' => false, 'message' => 'Vous ne pouvez gérer que l’unité dont vous êtes le chef.'], 403);
    if ($members) {
        $place = implode(',', array_fill(0, count($members), '?'));
        $q = $pdo->prepare("SELECT COUNT(*) FROM utilisateur WHERE id IN ($place) AND statut='ACTIF' AND role IN('AGENT','INSPECTEUR')");
        $q->execute($members);
        if ((int) $q->fetchColumn() !== count($members))
            out(['ok' => false, 'message' => 'Un ou plusieurs membres sont invalides ou inactifs.'], 400);
    }
    $pdo->beginTransaction();
    try {
        $pdo->prepare('DELETE FROM agent_unite WHERE unite_id=?')->execute([$uid]);
        $q = $pdo->prepare('INSERT INTO agent_unite(unite_id,utilisateur_id) VALUES(?,?)');
        foreach ($members as $m)
            $q->execute([$uid, $m]);
        $pdo->commit();
        out(['ok' => true]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction())
            $pdo->rollBack();
        out(['ok' => false, 'message' => 'Impossible de modifier les membres de l’unité.'], 400);
    }
}
if ($a === 'update_unit') {
    $u = need(['CHEF_UNITE']);
    $id = (int) post('id', 0);
    $nom = trim(post('nom', ''));
    $code = trim(post('code', ''));
    $desc = trim(post('description', ''));
    if (!$id || !$nom || !$code)
        out(['ok' => false, 'message' => 'ID, code et nom sont obligatoires.'], 400);
    $q = $pdo->prepare('SELECT id FROM unite WHERE id=? AND actif=1 AND chef_unite_id=?');
    $q->execute([$id, $u['id']]);
    if (!$q->fetch())
        out(['ok' => false, 'message' => 'Vous ne pouvez modifier que votre propre unité.'], 403);
    $q = $pdo->prepare('SELECT id FROM unite WHERE id<>? AND (LOWER(code)=LOWER(?) OR LOWER(nom)=LOWER(?)) LIMIT 1');
    $q->execute([$id, $code, $nom]);
    if ($q->fetch())
        out(['ok' => false, 'message' => 'Le code ou le nom existe déjà.'], 409);
    $pdo->prepare('UPDATE unite SET code=?,nom=?,description=? WHERE id=?')->execute([$code, $nom, $desc, $id]);
    out(['ok' => true, 'message' => 'Unité modifiée.', 'id' => $id]);
}
if ($a === 'delete_unit') {
    $u = need(['CHEF_UNITE']);
    $id = (int) post('id', 0);
    $q = $pdo->prepare('SELECT id FROM unite WHERE id=? AND actif=1 AND chef_unite_id=?');
    $q->execute([$id, $u['id']]);
    if (!$q->fetch())
        out(['ok' => false, 'message' => 'Vous ne pouvez archiver que votre propre unité.'], 403);
    $pdo->prepare('UPDATE unite SET actif=0 WHERE id=?')->execute([$id]);
    out(['ok' => true, 'message' => 'Unité archivée.']);
}
if ($a === 'delete_user') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS']);
    $id = (int) post('id', 0);
    if (!$id || $id === $u['id'])
        out(['ok' => false, 'message' => 'Suppression impossible pour ce compte.'], 400);
    $q = $pdo->prepare('SELECT * FROM utilisateur WHERE id=?');
    $q->execute([$id]);
    $target = $q->fetch();
    if (!$target)
        out(['ok' => false, 'message' => 'Utilisateur introuvable.'], 404);
    if ($u['role'] === 'ADMIN') {
        $pdo->prepare("UPDATE utilisateur SET statut='INACTIF',suppression_demande=1,suppression_demande_par=?,suppression_demande_at=NOW() WHERE id=? AND statut<>'SUPPRIME'")->execute([$u['id'], $id]);
        notifyRoles(managerRoles(), 'CORBEILLE', 'Demande de suppression d’un compte : ' . $target['prenom'] . ' ' . $target['nom'] . '.', $id, $u['id']);
        out(['ok' => true, 'pending_confirmation' => true, 'message' => 'Demande de suppression envoyée au Sous-directeur des opérations pour confirmation.']);
    }
    $pdo->prepare("UPDATE utilisateur SET statut='SUPPRIME',suppression_demande=0,suppression_confirmee_par=?,suppression_confirmee_at=NOW() WHERE id=?")->execute([$u['id'], $id]);
    notifyRoles(managerRoles(), 'CORBEILLE', 'Compte placé dans la corbeille : ' . $target['prenom'] . ' ' . $target['nom'] . '.', $id, $u['id']);
    out(['ok' => true, 'message' => 'Compte placé dans la corbeille.']);
}
if ($a === 'confirm_user_deletion') {
    $u = need(['SOUS_DIRECTEUR_OPERATIONS']);
    $id = (int) post('id', 0);
    $q = $pdo->prepare('SELECT id,nom,prenom FROM utilisateur WHERE id=? AND suppression_demande=1');
    $q->execute([$id]);
    $target = $q->fetch();
    if (!$target)
        out(['ok' => false, 'message' => 'Aucune demande de suppression à confirmer.'], 404);
    $pdo->prepare("UPDATE utilisateur SET statut='SUPPRIME',suppression_demande=0,suppression_confirmee_par=?,suppression_confirmee_at=NOW() WHERE id=?")->execute([$u['id'], $id]);
    notifyRoles(managerRoles(), 'CORBEILLE', 'Compte supprimé : ' . $target['prenom'] . ' ' . $target['nom'] . '.', $id, $u['id']);
    out(['ok' => true, 'message' => 'Suppression confirmée : compte placé dans la corbeille.']);
}
if ($a === 'user_trash') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    $rows = $pdo->query("SELECT id,matricule,nom,prenom,email,role,poste,type_compte,suppression_confirmee_par,suppression_confirmee_at FROM utilisateur WHERE statut='SUPPRIME' ORDER BY suppression_confirmee_at DESC,id DESC")->fetchAll();
    out($rows);
}
if ($a === 'restore_user') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS']);
    $id = (int) post('id', 0);
    $q = $pdo->prepare("SELECT id FROM utilisateur WHERE id=? AND statut='SUPPRIME'");
    $q->execute([$id]);
    if (!$q->fetch())
        out(['ok' => false, 'message' => 'Compte supprimé introuvable.'], 404);
    $pdo->prepare("UPDATE utilisateur SET statut='ACTIF',suppression_demande=0,suppression_confirmee_par=NULL,suppression_confirmee_at=NULL WHERE id=?")->execute([$id]);
    out(['ok' => true, 'message' => 'Compte restauré.']);
}
if ($a === 'create_team') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS']);
    $members = json_decode(post('members', '[]'), true);
    if (!is_array($members))
        $members = [];
    $s = $pdo->prepare('INSERT INTO equipe(nom,type_intervention,unite_id,cree_par) VALUES(?,?,?,?)');
    $s->execute([post('nom'), post('type_intervention', 'AUTRE'), post('unite_id') ?: null, $u['id']]);
    $eid = (int) $pdo->lastInsertId();
    $m = $pdo->prepare('INSERT INTO equipe_membre(equipe_id,utilisateur_id) VALUES(?,?) ON DUPLICATE KEY UPDATE utilisateur_id=VALUES(utilisateur_id)');
    foreach (array_unique(array_map('intval', $members)) as $x)
        $m->execute([$eid, $x]);
    out(['ok' => true, 'id' => $eid]);
}
if ($a === 'team_members') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    $s = $pdo->prepare("SELECT u.id,u.matricule,u.nom,u.prenom,u.email,u.disponibilite FROM equipe_membre em JOIN utilisateur u ON u.id=em.utilisateur_id WHERE em.equipe_id=? ORDER BY u.nom");
    $s->execute([(int) ($_GET['id'] ?? 0)]);
    out($s->fetchAll());
}
if ($a === 'users_manage') {
    need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    try {
        $rows = $pdo->query("SELECT id,matricule,nom,prenom,email,role,poste,niveau_accreditation,statut,disponibilite,type_compte,date_creation,suppression_demande,suppression_demande_at FROM utilisateur ORDER BY (statut='SUPPRIME'),statut DESC,nom,prenom")->fetchAll();
        out($rows);
    } catch (Throwable $e) {
        out(['ok' => false, 'message' => 'La base de données n’est pas encore à jour pour la page Accréditations. Exécutez database/migration_v22.sql puis rechargez la page.', 'detail' => $e->getMessage()], 500);
    }
}
if ($a === 'update_user_accreditation') {
    $u = need(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']);
    $id = (int) post('id', 0);
    if ($id === $u['id'] && post('role') != $u['role'])
        out(['ok' => false, 'message' => 'Vous ne pouvez pas modifier votre propre rôle depuis cette page.'], 400);
    $role = post('role', 'AGENT');
    $allowed = ['ADMIN', 'INSPECTEUR', 'AGENT', 'CHEF_UNITE', 'HSE', 'DIRECTEUR', 'SOUS_DIRECTEUR_OPERATIONS'];
    if (!in_array($role, $allowed, true))
        out(['ok' => false, 'message' => 'Rôle invalide.'], 400);
    $q = $pdo->prepare('SELECT type_compte FROM utilisateur WHERE id=?');
    $q->execute([$id]);
    $targetType = $q->fetchColumn();
    if (!$targetType)
        out(['ok' => false, 'message' => 'Utilisateur introuvable.'], 404);
    if ($u['role'] !== 'DIRECTEUR' && $targetType === 'AGENT_2RC')
        out(['ok' => false, 'message' => 'Seul le Directeur peut accréditer un Agent 2RC.'], 403);
    $level = post('niveau_accreditation', 'NIVEAU_1');
    if ($u['role'] !== 'DIRECTEUR') {
        $q = $pdo->prepare('SELECT niveau_accreditation FROM utilisateur WHERE id=?');
        $q->execute([$id]);
        $level = $q->fetchColumn() ?: 'NIVEAU_1';
    }
    $pdo->prepare('UPDATE utilisateur SET role=?,poste=?,niveau_accreditation=?,statut=?,disponibilite=? WHERE id=?')->execute([$role, post('poste', ''), $level, post('statut', 'ACTIF'), post('disponibilite', 'DISPONIBLE'), $id]);
    out(['ok' => true]);
}

out(['ok' => false, 'message' => 'Action inconnue'], 404);