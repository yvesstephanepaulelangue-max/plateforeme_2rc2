<?php
session_start();
if (empty($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['ADMIN','SOUS_DIRECTEUR_OPERATIONS','DIRECTEUR','CHEF_UNITE'], true)) {
    header('Location:login.php'); exit;
}
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>2RC — Archive</title><link rel="stylesheet" href="assets/app.css">
</head>
<body>
<header class="top"><b><small></small></b><button class="btn alt" onclick="logout()">Déconnexion</button></header>
<div class="layout"><?php require __DIR__.'/assets/nav.php'; ?><main>
<div class="head">
 <div><h1>Archive</h1><div class="sub">Interventions retirées du suivi actif après transmission de leur rapport.</div></div>
</div>
<div id="msg" class="notice">Chargement…</div>
<div class="card" style="margin-top:16px"><div class="table"><table>
<thead><tr><th>Référence</th><th>Intervention</th><th>Drain</th><th>Unité</th><th>Statut</th><th>Rapport</th><th>Date d'envoi</th></tr></thead>
<tbody id="body"><tr><td colspan="7">Chargement…</td></tr></tbody>
</table></div></div>
</main></div>
<script src="assets/app.js"></script>
<script>
async function load(){
 const r=await api('archives');
 if(!Array.isArray(r)){ msg.textContent=r?.message||'Impossible de charger les archives.'; return; }
 msg.textContent=r.length ? r.length+' intervention(s) archivée(s).' : 'Aucune intervention archivée.';
 body.innerHTML=r.map(x=>`<tr>
 <td><b>${esc(x.reference||'—')}</b></td>
 <td>${esc(x.type_intervention||'—')}</td>
 <td>${esc(x.drain_code||'')}<br><small>${esc(x.drain_nom||'')}</small></td>
 <td>${esc(x.unite_nom||'—')}</td>
 <td>${badge(x.statut)}</td>
 <td>${x.rapport_titre?esc(x.rapport_titre):'—'}</td>
 <td>${x.rapport_date?new Date(String(x.rapport_date).replace(' ','T')).toLocaleString('fr-FR'):'—'}</td>
 </tr>`).join('')||'<tr><td colspan="7">Aucune archive.</td></tr>';
}
guard(['ADMIN','SOUS_DIRECTEUR_OPERATIONS','DIRECTEUR','CHEF_UNITE']).then(load);
setInterval(load,30000);
</script>
</body></html>
