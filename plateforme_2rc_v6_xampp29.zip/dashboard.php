<?php session_start();
if (empty($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR'], true)) {
    header('Location:login.php');
    exit;
} ?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Tableau de bord</title>
    <link rel="stylesheet" href="assets/app.css">
</head>

<body>
    <header class="top">
        <b><small></small></b><span><?= htmlspecialchars($_SESSION['user']['nom'] . ' ' . $_SESSION['user']['prenom']) ?>
            ·
            <button class="btn alt" onclick="logout()">Déconnexion</button></span>
    </header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <style>
        .nav a:hover {
            transform: translateX(3px);
            background: #F8985F;
            color: var(--navy)
        }
        </style>
        <main>
            <div class="head reveal">
                <div>
                    <h1>Tableau de bord</h1>
                    <div class="sub">Pilotage opérationnel en temps réel.</div>
                </div>
                <div class="notice">Dernière modification : <b id="lastDrainModification">—</b></div>
            </div>
            <div style="display: flex">
                <div class="card reveal delay1"
                    style="display:flex;align-items:center;gap:18px;margin-bottom:16px;overflow:hidden;width:55%">
                    <div>
                        <h3 style="margin:0 0 6px">Centre de pilotage 2RC</h3>
                        <p class="sub" style="margin:0">Suivi des autorisations, des drains prioritaires et des
                            remontées terrain.</p>
                    </div>
                </div>
            </div>

            <div id="k" class="grid kpis"></div>
            <style>
            .kpi:after {
                content: "";
                position: absolute;
                width: 90px;
                height: 90px;
                border-radius: 50%;
                right: -25px;
                top: -25px;
                background: #FFFFFF;
            }
            </style>
            <style>
                .vehicle-editor { display:grid; grid-template-columns:1.1fr 1fr 1fr 1.4fr auto; gap:7px; align-items:center; }
                .vehicle-editor select,.vehicle-editor input { margin:0; padding:7px 8px; font-size:12px; }
                .vehicle-editor .btn { padding:7px 9px; font-size:11px; white-space:nowrap; }
                .veh-status-select.status-DISPONIBLE { background:#dff7e9; color:#16704e; font-weight:800; }
                .veh-status-select.status-MAINTENANCE { background:#ffe9d1; color:#a44d00; font-weight:800; }
                .veh-status-select.status-EN_SERVICE { background:#dcecff; color:#145ea8; font-weight:800; }
                .veh-status-select.status-HORS_SERVICE { background:#ffe1e1; color:#a60000; font-weight:800; }
                .vehicle-read-status { font-weight:800; }
                @media(max-width:1000px){ .vehicle-editor { grid-template-columns:1fr 1fr; } .vehicle-editor .vehicle-save { grid-column:1/-1; } }
            </style>
            </style>
            <div class="grid two" style="margin-top:16px">
                <div class="card reveal delay2">
                    <h3>Véhicules opérationnels</h3>
                    <div class="table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Véhicule</th>
                                    <th>Statut</th>
                                    <th>Unité</th>
                                    <th>Lieu</th>
                                    <?php if ($_SESSION['user']['role'] === 'ADMIN'): ?><th>Action</th><?php endif; ?>
                                </tr>
                            </thead>
                            <tbody id="v"></tbody>
                        </table>
                    </div>
                </div>
                <div class="card reveal delay3">
                    <h3>Flux des rapports</h3>
                    <div id="reportsBox"></div>
                    <div class="notice">Les rapports envoyés depuis l’inspection et l’entretien apparaissent dans
                        <b>Rapports</b> dès leur transmission.
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/app.js"></script>
    <script>
    function vehicleStatusStyle(el) {
        el.className = 'veh-status-select status-' + String(el.value || '').replace(/[^A-Z_]/g,'');
    }
    function vehicleLocationMode(el) {
        const row = el.closest('tr');
        const other = row.querySelector('[data-role="other"]');
        const isOther = el.value === 'AUTRE';

        other.style.display = isOther ? 'block' : 'none';
        other.disabled = !isOther;

        if (!isOther) {
            other.value = '';
        }
    }
    async function saveVehicle(id, btn) {
        const row = btn.closest('tr');
        const loc = row.querySelector('[data-role="location"]').value;
        const other = row.querySelector('[data-role="other"]');
        const fd = new FormData();
        fd.append('id', id);
        fd.append('statut', row.querySelector('[data-role="status"]').value);
        fd.append('unite_id', row.querySelector('[data-role="unit"]').value);
        if (loc === 'AUTRE') {
            const customPlace = String(other.value || '').trim();
            if (!customPlace) {
                other.focus();
                return alert('Veuillez saisir le lieu personnalisé.');
            }
            fd.append('lieu_type','AUTRE');
            fd.append('lieu_autre',customPlace);
        } else {
            fd.append('lieu_type','DRAIN');
            fd.append('drain_id',loc.split(':')[1] || '');
        }
        btn.disabled = true;
        const r = await api('update_vehicle', fd, 'POST');
        btn.disabled = false;
        if (!r.ok) return alert(r.message || 'Modification impossible.');
        toast('Véhicule mis à jour.');
        await load();
    }
    async function load() {
        const r = await api('dashboard');
        if (!r || r.ok === false || !r.interventions || !r.drains) {
            k.innerHTML =
                `<div class="card reveal" style="grid-column:1/-1"><h3>Tableau de bord indisponible</h3><p class="sub">${esc(r?.message || 'Impossible de récupérer les données. Vérifiez MySQL et la structure de la base.')}</p></div>`;
            return;
        }
        const items = [
            ['Interventions', r.interventions.total || 0,
                `En cours : ${r.interventions.encours || 0} · Retard : ${r.interventions.retard || 0}`
            ],
            ['Drains', r.drains.total || 0,
                `Naturels : ${Number(r.drains.lineaire_naturel || 0).toLocaleString('fr-FR')} m · Bétonnés : ${Number(r.drains.lineaire_beton || 0).toLocaleString('fr-FR')} m`
            ],
            ['Linéaire total', Number(r.drains.lineaire_total || 0), 'mètres de drains référencés'],
            ['Réalisé', Number(r.drains.lineaire_realise || 0),
                `Exécuté : ${Number(r.drains.lineaire_execute || 0).toLocaleString('fr-FR')} m ·`
            ],
            ['Avancement global', Number(r.progress || 0), '% moyen des drains'],
            ['Taux de retard', Number(r.retard || 0), '% des interventions'],
            ['Prochains 7 jours', r.interventions.semaine || 0, 'missions planifiées'],
            ['Visas en attente', r.pending_visas || 0, 'les 2 visas sont nécessaires']
        ];
        const progressValue = Number(r.progress || 0);
        const progressClass = progressValue <= 25 ? 'progress-red' : progressValue <= 49 ? 'progress-orange' :
            progressValue <= 79 ? 'progress-yellow' : 'progress-green';
        k.innerHTML = items.map((x, i) => {
            const isProgress = x[0] === 'Avancement global';
            const cls = isProgress ? progressClass : '';
            return `<div class="card kpi reveal delay${Math.min(i + 1, 4)}"><div class="label">${x[0]}</div><div class="value ${cls}" data-target="${x[1]}" data-suffix="${x[0].includes('Avancement') || x[0].includes('retard') ? '%' : ''}">0</div><div class="sub">${x[2]}</div></div>`;
        }).join('');
        document.querySelectorAll('.value[data-target]').forEach(el => animateNumber(el, el.dataset.target, el
            .dataset.suffix));
        document.getElementById('lastDrainModification').textContent = r.last_drain_modification ? new Date(r
            .last_drain_modification.replace(' ', 'T')).toLocaleString('fr-FR', {
            dateStyle: 'short',
            timeStyle: 'medium'
        }) : 'Aucune modification enregistrée';
        const canEditVehicles = <?= json_encode($_SESSION['user']['role'] === 'ADMIN') ?>;
        let vehicleOptions = window.__vehicleOptions || null;
        if (canEditVehicles && !vehicleOptions) {
            const vo = await api('vehicle_options');
            if (vo && vo.ok !== false) vehicleOptions = window.__vehicleOptions = vo;
        }
        const statusLabel = {DISPONIBLE:'Disponible',MAINTENANCE:'Maintenance',EN_SERVICE:'En-service',HORS_SERVICE:'Hors service'};
        const statusClass = s => 'status-' + String(s || '').replace(/[^A-Z_]/g,'');
        const unitOptions = vehicleOptions?.units || [];
        const drainOptions = vehicleOptions?.drains || [];
        const findLocation = (val) => {
            const s = String(val || '');
            const d = drainOptions.find(z => s === ('Drain ' + z.code + ' — ' + z.nom) || s === z.nom);
            return d ? {type:'DRAIN', id:d.id} : {type:'AUTRE', id:0};
        };
        v.innerHTML = (r.vehicules || []).map(x => {
            if (!canEditVehicles) {
                return `<tr><td><b>${esc(x.designation)}</b><br><small>${esc(x.immatriculation)}</small></td><td><span class="badge ${esc(x.statut)}">${esc(statusLabel[x.statut] || x.statut)}</span></td><td>${esc(x.unite || '—')}</td><td>${esc(x.lieu_operation || '—')}</td></tr>`;
            }
            const loc = findLocation(x.lieu_operation);
            const statuses = (vehicleOptions?.statuses || ['DISPONIBLE','MAINTENANCE','EN_SERVICE','HORS_SERVICE']).map(s => `<option value="${s}" ${s===x.statut?'selected':''}>${statusLabel[s] || s}</option>`).join('');
            const units = unitOptions.map(u => `<option value="${u.id}" ${String(u.nom)===String(x.unite)?'selected':''}>${esc(u.nom)}</option>`).join('');
            const drains = drainOptions.map(d => {
                const selected = loc.type==='DRAIN' && Number(loc.id)===Number(d.id);
                return `<option value="DRAIN:${d.id}" ${selected?'selected':''}>Drain ${esc(d.code)} — ${esc(d.nom)}</option>`;
            }).join('');
            const otherValue = loc.type==='AUTRE' ? String(x.lieu_operation || '') : '';
            return `<tr data-vehicle-id="${x.id}">
                <td><b>${esc(x.designation)}</b><br><small>${esc(x.immatriculation)}</small></td>
                <td><select class="veh-status-select ${statusClass(x.statut)}" data-role="status" onchange="vehicleStatusStyle(this)">${statuses}</select></td>
                <td><select data-role="unit">${units || '<option value="">Aucune unité</option>'}</select></td>
                <td>
                    <select data-role="location" onchange="vehicleLocationMode(this)">
                        ${drains}
                        <option value="AUTRE" ${loc.type==='AUTRE'?'selected':''}>Autre</option>
                    </select>
                    <input data-role="other" type="text" placeholder="Autre lieu…" value="${esc(otherValue)}" style="display:${loc.type==='AUTRE'?'block':'none'};margin-top:5px" ${loc.type==='AUTRE'?'':'disabled'}>
                </td>
                <td><button class="btn vehicle-save" onclick="saveVehicle(${x.id},this)">Enregistrer</button></td>
            </tr>`;
        }).join('') || `<tr><td colspan="${canEditVehicles?5:4}">Aucun véhicule.</td></tr>`;
        if (canEditVehicles) {
            document.querySelectorAll('.veh-status-select').forEach(vehicleStatusStyle);
            document.querySelectorAll('[data-role="location"]').forEach(vehicleLocationMode);
        }
        reportsBox.innerHTML =
            `<div class="value">${r.reports?.nouveaux || 0}</div><p class="sub">nouveaux rapports à traiter</p>`;
    }
    guard(['ADMIN', 'SOUS_DIRECTEUR_OPERATIONS', 'DIRECTEUR']).then(load);
    startAutoRefresh(load, 30000)
    </script>
</body>

</html>