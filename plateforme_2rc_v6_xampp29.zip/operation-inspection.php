<?php session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'INSPECTEUR') {
    header('Location:login.php');
    exit;
} ?><!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>2RC — Opérations inspection</title>
    <link rel="stylesheet" href="assets/app.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
</head>

<body>
    <header class="top"><b><small></small></b><button class="btn alt"
            onclick="logout()">Déconnexion</button></header>
    <div class="layout"><?php require __DIR__ . '/assets/nav.php'; ?>
        <main>
            <div class="head">
                <div>
                    <h1>Opérations</h1>
                    <div class="sub">Interventions d’inspection autorisées et affectées à votre unité.</div>
                </div>
            </div>
            <div class="card">
                <div class="table">
                    <table id="my">
                        <thead>
                            <tr>
                                <th>Référence</th>
                                <th>Drain</th>
                                <th>Date début</th>
                                <th>Fin prévue</th>
                                <th>Statut</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="assets/app.js"></script>
    <script>async function load() { let w = await api('my_work'); w = Array.isArray(w) ? w.filter(i => i.type_intervention === 'INSPECTION') : []; document.querySelector('#my tbody').innerHTML = w.map(i => `<tr><td>${esc(i.reference)}</td><td>${esc(i.drain_nom)}</td><td>${esc(i.date_debut || i.date_prevue)}</td><td>${esc(i.date_fin_prevue || '—')}</td><td>${badge(i.statut)}</td></tr>`).join('') || '<tr><td colspan="5">Aucune intervention d’inspection autorisée affectée.</td></tr>' } guard('INSPECTEUR').then(load); startAutoRefresh(load, 2000)</script>
</body>

</html>